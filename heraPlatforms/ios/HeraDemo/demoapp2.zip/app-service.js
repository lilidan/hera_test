	var __wxAppData = __wxAppData || {}; 	var __wxRoute = __wxRoute || ""; 	var __wxRouteBegin = __wxRouteBegin || ""; 	var __wxAppCode__ = __wxAppCode__ || {};	var global = global || {};	var __WXML_GLOBAL__=__WXML_GLOBAL__ || {};	var __wxAppCurrentFile__=__wxAppCurrentFile__||""; 	var Component = Component || function(){};	var definePlugin = definePlugin || function(){};	var requirePlugin = requirePlugin || function(){};	var Behavior = Behavior || function(){};
	/*v0.6vv_20180522_fbi*/global.__wcc_version__='v0.6vv_20180522_fbi';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(path,global){
if(typeof global === 'undefined') global={};
if(typeof __WXML_GLOBAL__ === 'undefined') __WXML_GLOBAL__={};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if("undefined"!==typeof debugInfo)
e.stack += "\n "+" "+" "+" at "+debugInfo[g.opindex][0]+":"+debugInfo[g.opindex][1]+":"+debugInfo[g.opindex][2];
throw e;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
return rev;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
var value = $gdc( raw, "", 2 );
return value;
}
else
{
var value = $gdc( raw, "", 2 );
return value;
}
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
a = _da( node, attrname, opindex, a, o );
node.attr[attrname] = a;
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, c){
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules;
var p_={}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
if ( !__WXML_GLOBAL__.ops_init.$gwx){
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'handleTap']);Z([3,'image-continer']);Z([[2,'==='],[[7],[3,'status']],[1,'normal']]);Z([[2,'==='],[[7],[3,'status']],[1,'loading']]);Z([[2,'==='],[[7],[3,'status']],[1,'error']]);Z([[7],[3,'showGif']]);Z(z[0]);Z([3,'block-class aspect-ratio-box']);Z([3,'aspect-ratio-box-inside']);Z([[2,'!'],[[7],[3,'video']]]);Z([[7],[3,'video']]);Z([[7],[3,'tree']]);Z([1,true]);Z([3,'ztext']);Z([[7],[3,'html']]);Z([3,'index']);Z([3,'item']);Z([[7],[3,'list']]);Z([[7],[3,'index']]);Z([[2,'!'],[[7],[3,'html']]]);Z([[2,'==='],[[6],[[7],[3,'item']],[3,'type']],[1,null]]);Z([[2,'==='],[[6],[[7],[3,'item']],[3,'type']],[1,'image']]);Z([3,'ui-block']);Z([[6],[[7],[3,'item']],[3,'node']]);Z([[7],[3,'previewUrls']]);Z([[2,'==='],[[6],[[7],[3,'item']],[3,'type']],[1,'codeblock']]);Z(z[22]);Z(z[23]);Z([[2,'==='],[[6],[[7],[3,'item']],[3,'type']],[1,'video']]);Z(z[22]);Z(z[23]);Z([[7],[3,'useFullscreenVideo']]);Z([[2,'==='],[[6],[[7],[3,'item']],[3,'type']],[1,'gif']]);Z(z[22]);Z(z[23]);Z(z[0]);Z([[6],[[7],[3,'recommand']],[3,'image']]);Z([[7],[3,'shown']]);Z([[7],[3,'mount']]);Z(z[10]);Z([[7],[3,'videoId']]);Z([[6],[[6],[[7],[3,'video']],[3,'cover_info']],[3,'thumbnail']]);Z(z[12]);Z([[7],[3,'errorType']]);Z([3,'root']);Z([[2,'==='],[[7],[3,'errorType']],[1,'unauthorized']]);Z([[2,'==='],[[7],[3,'errorType']],[1,'notFound']]);Z([[7],[3,'currentNav']]);Z([3,'handleTabScrollPositionRestored']);Z([3,'handleSearchIconTap']);Z([3,'handleTabChange']);Z([[7],[3,'searchIconOpacity']]);Z([3,'handleTopToastRef']);Z([3,'35px']);Z([3,'内容已更新']);Z([3,'handleSubscribe']);Z([[7],[3,'showSubscription']]);Z([[7],[3,'isSubscriptionButtonVisible']]);Z([3,'handleChangeTapBySwipe']);Z([3,'handlePageTouchEnd']);Z([[12],[[7],[3,'cx']],[[5],[[5],[[5],[1,'Index']],[1,'withSubscription']],[[7],[3,'showSubscription']]]]);Z(z[47]);Z([3,'350']);Z([[6],[[7],[3,'hotList']],[3,'length']]);Z([3,'onListScroll']);Z([3,'swiper-list']);Z([[2,'==='],[[7],[3,'currentNav']],[[6],[[7],[3,'navIdentifiers']],[3,'hot']]]);Z([3,'hotItem']);Z([[7],[3,'hotList']]);Z([[6],[[7],[3,'hotItem']],[3,'id']]);Z([3,'handleHotItemTap']);Z([[6],[[7],[3,'hotItem']],[3,'type']]);Z([[6],[[7],[3,'hotItem']],[3,'urltoken']]);Z(z[12]);Z(z[18]);Z([[7],[3,'hotItem']]);Z([[6],[[7],[3,'recommendList']],[3,'length']]);Z(z[64]);Z([3,'handleScrollBottom']);Z(z[65]);Z([[2,'==='],[[7],[3,'currentNav']],[[6],[[7],[3,'navIdentifiers']],[3,'recommendation']]]);Z([3,'200']);Z(z[16]);Z([[7],[3,'recommendList']]);Z([[6],[[7],[3,'item']],[3,'id']]);Z([[7],[3,'item']]);Z(z[0]);Z([3,'HotItem--wrapper']);Z([3,'u-one-px-border HotItem']);Z([[6],[[7],[3,'item']],[3,'excerpt']]);Z([[6],[[7],[3,'item']],[3,'image']]);Z(z[0]);Z([3,'RecommendItem u-thinBorder']);Z([[6],[[7],[3,'item']],[3,'type']]);Z([[6],[[7],[3,'item']],[3,'urltoken']]);Z(z[89]);Z([3,'RecommendItem-content RecommendItem-imageFlexContainer']);Z(z[89]);Z(z[90]);Z([[7],[3,'searchText']]);Z([[2,'!'],[[7],[3,'searchText']]]);Z([3,'RecommendArea']);Z([3,'TopSearchWords']);Z([[7],[3,'presetWord']]);Z([3,'topWord']);Z([[7],[3,'topSearchWords']]);Z(z[18]);Z([3,'handleRecommendWordTap']);Z([3,'TopSearchWords-item']);Z([[6],[[7],[3,'topWord']],[3,'query']]);Z(z[104]);Z([[2,'<'],[[7],[3,'index']],[1,3]]);Z([[2,'>'],[[6],[[7],[3,'historySearchWords']],[3,'length']],[1,0]]);Z([3,'HistorySearchWords']);Z([3,'historyWord']);Z([[7],[3,'historySearchWords']]);Z(z[18]);Z([[2,'<'],[[7],[3,'index']],[1,10]]);Z([[2,'>'],[[6],[[7],[3,'historySearchWords']],[3,'length']],[1,1]]);Z([[2,'&&'],[[7],[3,'searchText']],[[7],[3,'isSearchInputFocus']]]);Z([[2,'&&'],[[2,'&&'],[[7],[3,'isLoadingResult']],[[7],[3,'searchText']]],[[2,'!'],[[6],[[7],[3,'result']],[3,'data']]]]);Z([[2,'&&'],[[2,'!'],[[7],[3,'isLoadingResult']]],[[2,'!'],[[7],[3,'isSearchInputFocus']]]]);Z([3,'Search-resultContainer']);Z([[2,'>'],[[6],[[6],[[7],[3,'result']],[3,'data']],[3,'length']],[1,0]]);Z([3,'resultItem']);Z([[6],[[7],[3,'result']],[3,'data']]);Z([[6],[[7],[3,'resultItem']],[3,'id']]);Z([3,'Search-resultItem']);Z([[6],[[6],[[6],[[7],[3,'resultItem']],[3,'highlight']],[3,'title']],[3,'length']]);Z([[2,'?:'],[[2,'<'],[[6],[[6],[[6],[[6],[[7],[3,'resultItem']],[3,'object']],[3,'thumbnail_info']],[3,'thumbnails']],[3,'length']],[1,3]],[1,'ResultItem-descriptionArea'],[1,'ResultItem-descriptionArea ResultItem-descriptionArea--column']]);Z([[6],[[6],[[6],[[7],[3,'resultItem']],[3,'highlight']],[3,'description']],[3,'length']]);Z([[2,'&&'],[[2,'>'],[[6],[[6],[[6],[[6],[[7],[3,'resultItem']],[3,'object']],[3,'thumbnail_info']],[3,'thumbnails']],[3,'length']],[1,0]],[[2,'<'],[[6],[[6],[[6],[[6],[[7],[3,'resultItem']],[3,'object']],[3,'thumbnail_info']],[3,'thumbnails']],[3,'length']],[1,3]]]);Z([[2,'>='],[[6],[[6],[[6],[[6],[[7],[3,'resultItem']],[3,'object']],[3,'thumbnail_info']],[3,'thumbnails']],[3,'length']],[1,3]]);Z([3,'img']);Z([[6],[[6],[[6],[[7],[3,'resultItem']],[3,'object']],[3,'thumbnail_info']],[3,'thumbnails']]);Z(z[111]);Z([[2,'==='],[[6],[[6],[[7],[3,'resultItem']],[3,'object']],[3,'type']],[1,'question']]);Z([[2,'==='],[[6],[[6],[[7],[3,'resultItem']],[3,'object']],[3,'type']],[1,'article']]);Z([[2,'!'],[[6],[[6],[[7],[3,'result']],[3,'paging']],[3,'is_end']]]);Z([[2,'==='],[[6],[[6],[[7],[3,'result']],[3,'data']],[3,'length']],[1,0]]);Z([3,'abstractComment']);Z([[2,'&&'],[[7],[3,'abstractComments']],[[2,'>'],[[6],[[7],[3,'abstractComments']],[3,'length']],[1,0]]]);Z([3,'comment']);Z([[7],[3,'abstractComments']]);Z([[6],[[7],[3,'comment']],[3,'id']]);Z([[7],[3,'comment']]);Z([3,'comment-nameArea']);Z([[6],[[7],[3,'comment']],[3,'reply_to_author']]);Z(z[147]);Z([3,'loadComments']);Z([[2,'?:'],[[6],[[7],[3,'commentsData']],[3,'featured_counts']],[1,'commentPanel-content'],[1,'commentPanel-content commentPanel-content--withPadding']]);Z([1,200]);Z([[6],[[7],[3,'commentsData']],[3,'featured_counts']]);Z(z[142]);Z([[7],[3,'featuredComments']]);Z(z[144]);Z([3,'commentPanel-commentItem']);Z(z[145]);Z([[2,'>'],[[6],[[6],[[7],[3,'comment']],[3,'child_comments']],[3,'length']],[1,0]]);Z([3,'childComment']);Z([[6],[[7],[3,'comment']],[3,'child_comments']]);Z([[6],[[7],[3,'childComment']],[3,'id']]);Z([[7],[3,'childComment']]);Z(z[152]);Z(z[142]);Z([[7],[3,'commonComments']]);Z(z[144]);Z([3,'comment-item']);Z(z[145]);Z(z[158]);Z(z[159]);Z(z[160]);Z(z[161]);Z(z[162]);Z([3,'HotRecommand']);Z([[2,'&&'],[[7],[3,'recommands']],[[2,'>'],[[6],[[7],[3,'recommands']],[3,'length']],[1,0]]]);Z([3,'recommand']);Z([[7],[3,'recommands']]);Z([[6],[[7],[3,'recommand']],[3,'url_token']]);Z([[7],[3,'recommand']]);Z([[7],[3,'end']]);Z([[7],[3,'loading']]);Z([a,[[2,'?:'],[[7],[3,'isToolBarShown']],[1,'toolBar'],[1,'toolBar ToolBar--hide']],[3,' '],[[2,'?:'],[[2,'&&'],[[2,'!'],[[7],[3,'isToolBarShown']]],[[7],[3,'isIphoneX']]],[1,'ToolBar--hideIphoneX'],[1,'']]]);Z([[2,'==='],[[7],[3,'type']],[1,'answer']]);Z([[2,'==='],[[7],[3,'type']],[1,'article']]);Z([[7],[3,'answer']]);Z([3,'page']);Z([[7],[3,'showTitleOnNavigationBar']]);Z([3,'main']);Z([[6],[[6],[[7],[3,'answer']],[3,'author']],[3,'headline']]);Z([3,'content']);Z([[2,'&&'],[[7],[3,'shouldShowVideoOnly']],[[7],[3,'videoId']]]);Z([3,'handleVideoLoadMore']);Z(z[40]);Z([[2,'!'],[[7],[3,'shouldShowVideoOnly']]]);Z([3,'richtext']);Z([[6],[[7],[3,'answer']],[3,'content']]);Z(z[194]);Z(z[185]);Z([3,'openCommentPanel']);Z([[6],[[7],[3,'answer']],[3,'comment_count']]);Z([[7],[3,'entryId']]);Z([3,'answer']);Z([[2,'!'],[[7],[3,'hasNext']]]);Z(z[181]);Z(z[177]);Z(z[185]);Z(z[199]);Z(z[200]);Z(z[201]);Z([[7],[3,'isToolBarShown']]);Z(z[202]);Z([[6],[[7],[3,'answer']],[3,'voteup_count']]);Z([[6],[[6],[[7],[3,'answer']],[3,'relationship']],[3,'voting']]);Z([[7],[3,'showCommentPanel']]);Z([3,'closeCommentPanel']);Z(z[201]);Z(z[202]);Z([a,[3,'answer/'],z[201]]);Z([[7],[3,'post']]);Z(z[186]);Z([[6],[[7],[3,'post']],[3,'image_url']]);Z(z[188]);Z([[6],[[6],[[7],[3,'post']],[3,'author']],[3,'headline']]);Z(z[190]);Z(z[191]);Z(z[192]);Z(z[40]);Z(z[194]);Z(z[195]);Z([[6],[[7],[3,'post']],[3,'content']]);Z(z[194]);Z(z[219]);Z(z[199]);Z([[6],[[7],[3,'post']],[3,'comment_count']]);Z(z[201]);Z(z[210]);Z([3,'article']);Z([[6],[[7],[3,'post']],[3,'voteup_count']]);Z([[6],[[7],[3,'post']],[3,'voting']]);Z(z[214]);Z(z[215]);Z(z[201]);Z(z[237]);Z([a,[[2,'?:'],[[7],[3,'isPromotion']],[1,'promotion'],[1,'articles']],[3,'/'],z[201]]);Z(z[186]);Z([[7],[3,'question']]);Z([[6],[[7],[3,'question']],[3,'detail']]);Z([[6],[[7],[3,'question']],[3,'excerpt']]);Z([[6],[[7],[3,'question']],[3,'thumbnail_info']]);Z([[2,'&&'],[[7],[3,'question']],[[7],[3,'answers']]]);Z(z[202]);Z([[7],[3,'answers']]);Z([[6],[[7],[3,'answer']],[3,'id']]);Z([3,'handleAnswerItemClick']);Z(z[202]);Z([[7],[3,'openType']]);Z([a,[3,'/zhihu/answer?id\x3d'],z[253],[3,'\x26source\x3dquestion']]);Z([[6],[[7],[3,'answer']],[3,'thumbnail_info']]);Z([3,'answer-thumbnails']);Z(z[246]);Z(z[201]);Z([3,'question']);Z(z[248]);Z([[6],[[7],[3,'question']],[3,'title']]);Z([a,[3,'question/'],z[201]]);Z([3,'summary']);Z([[2,'!'],[[7],[3,'expanded']]]);Z(z[0]);Z([3,'excerpt']);Z([3,'excerptBefore']);Z([[7],[3,'canExpand']]);Z([3,'button']);Z([3,'handleExcerptMeasure']);Z([[7],[3,'detail']]);Z([[2,'>'],[[6],[[7],[3,'info']],[3,'count']],[1,0]]);Z([3,'thumbnails thumbnails-class']);Z([[2,'==='],[[6],[[6],[[6],[[7],[3,'info']],[3,'thumbnails']],[1,0]],[3,'type']],[1,'image']]);Z([[2,'==='],[[6],[[6],[[6],[[7],[3,'info']],[3,'thumbnails']],[1,0]],[3,'type']],[1,'video']]);Z([3,'stopPropagation']);Z([[6],[[6],[[6],[[7],[3,'info']],[3,'thumbnails']],[1,0]],[3,'attached_info']]);Z([[6],[[6],[[6],[[7],[3,'info']],[3,'thumbnails']],[1,0]],[3,'url']]);})(z);__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
}
var nv_require=function(){var nnm={"p_./assets/cx.68d766.wxs":np_0,"p_./assets/date.7fb565.wxs":np_1,"p_./assets/desc.50f081.wxs":np_2,"p_./assets/formatDateRelative.861987.wxs":np_3,"p_./assets/formatNumber.dcfc79.wxs":np_4,"p_./assets/fromNow.4e1ce3.wxs":np_5,"p_./assets/getUrl.baad23.wxs":np_6,"p_./assets/img.065e87.wxs":np_7,"p_./assets/number.a72fe9.wxs":np_8,"p_./assets/urlUtils.9e9247.wxs":np_9,};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);throw e;}
}}}()
f_['./assets/cx.68d766.wxs'] = nv_require("p_./assets/cx.68d766.wxs");
function np_0(){var nv_module={nv_exports:{}};nv_module.nv_exports = (function (){arguments.nv_length=arguments.length;var nv_classes = [];var nv_length = arguments.nv_length;for(var nv_i = 0;nv_i < nv_length;nv_i++){var nv_arg = arguments[((nt_0=(nv_i),null==nt_0?undefined:'Number'===nt_0.nv_constructor?nt_0:"nv_"+nt_0))];var nv_nextArg = arguments[((nt_1=(nv_i + 1),null==nt_1?undefined:'Number'===nt_1.nv_constructor?nt_1:"nv_"+nt_1))];if (typeof nv_arg !== 'string' || nv_arg === '')continue;;if (nv_i === nv_length - 1)nv_classes.nv_push(nv_arg);;if (!!nv_nextArg || nv_nextArg === ''){nv_classes.nv_push(nv_arg)}};return(nv_classes.nv_join(' '))});return nv_module.nv_exports;}

f_['./assets/date.7fb565.wxs'] = nv_require("p_./assets/date.7fb565.wxs");
function np_1(){var nv_module={nv_exports:{}};function nv_isInvalid(nv_date){return(nv_date.nv_toString() === 'Invalid Date')};function nv_parseInputTime(nv_any){var nv_then;if (typeof nv_any === 'number'){nv_then = nv_getDate(nv_any * 1000)} else {nv_then = nv_getDate(nv_any)};return(nv_isInvalid(nv_then) ? '':nv_then)};function nv_pad(nv_num){var nv_str = nv_num.nv_toString();return(nv_str.nv_length === 1 ? ('0' + nv_str):nv_str)};function nv_toDateString(nv_any){var nv_then = nv_parseInputTime(nv_any);if (!nv_then){return('')};var nv_today = nv_getDate();nv_today.nv_setHours(0,0,0,0);var nv_currentMonth = nv_then.nv_getMonth() + 1;var nv_currentDate = nv_then.nv_getDate();if (nv_today.nv_getFullYear() === nv_then.nv_getFullYear()){return(nv_pad(nv_currentMonth) + '/' + nv_pad(nv_currentDate))};return(nv_then.nv_getFullYear().nv_toString().nv_slice(-2) + '/' + nv_pad(nv_currentMonth) + '/' + nv_pad(nv_currentDate))};function nv_toSmartDateTimeString(nv_any){var nv_then = nv_parseInputTime(nv_any);if (!nv_then){return('')};var nv_ts = nv_then.nv_getTime();var nv_oneDay = 24 * 3600 * 1000;var nv_today = nv_getDate();nv_today.nv_setHours(0,0,0,0);var nv_midnight = nv_today.nv_valueOf();if (nv_ts > nv_midnight){return(nv_pad(nv_then.nv_getHours()) + ':' + nv_pad(nv_then.nv_getMinutes()))} else if (nv_ts > nv_midnight - nv_oneDay){return('昨天 ' + nv_pad(nv_then.nv_getHours()) + ':' + nv_pad(nv_then.nv_getMinutes()))} else if (nv_ts > nv_midnight - nv_oneDay * 2){return('前天 ' + nv_pad(nv_then.nv_getHours()) + ':' + nv_pad(nv_then.nv_getMinutes()))};return(nv_toDateString(nv_any))};nv_module.nv_exports.nv_toSmartDateTimeString = nv_toSmartDateTimeString;return nv_module.nv_exports;}

f_['./assets/desc.50f081.wxs'] = nv_require("p_./assets/desc.50f081.wxs");
function np_2(){var nv_module={nv_exports:{}};nv_module.nv_exports = (function (nv_type,nv_name,nv_hot,nv_value){var nv_descMap = ({nv_question:'回答',nv_answer:'赞同',nv_article:'赞',});var nv_leftText = nv_type === 'answer' ? nv_name + '的回答':nv_hot;var nv_rightText = nv_value + ' ' + nv_descMap[((nt_0=(nv_type),null==nt_0?undefined:'Number'===nt_0.nv_constructor?nt_0:"nv_"+nt_0))];return(nv_leftText + (nv_leftText ? ' · ':'') + nv_rightText)});return nv_module.nv_exports;}

f_['./assets/formatDateRelative.861987.wxs'] = nv_require("p_./assets/formatDateRelative.861987.wxs");
function np_3(){var nv_module={nv_exports:{}};var nv_defaults = ({nv_hasYear:true,nv_separator:'-',});function nv_pad(nv_n){return(nv_n < 10 ? '0' + nv_n:nv_n)};function nv_getLocalDateString(nv_timestamp){arguments.nv_length=arguments.length;var nv_options = arguments.nv_length > 1 && arguments[(1)] !== undefined ? arguments[(1)]:nv_defaults;if (!nv_timestamp){return('')};var nv_time = nv_getDate(nv_timestamp);var nv_year = nv_time.nv_getFullYear();var nv_month = nv_time.nv_getMonth() + 1;var nv_date = nv_time.nv_getDate();var nv_hasYear = nv_options.nv_hasYear;var nv_separator = nv_options.nv_separator;var nv_dateString = '' + nv_pad(nv_month) + nv_separator + nv_pad(nv_date);if (nv_hasYear){return('' + nv_year + nv_separator + nv_dateString)} else {return(nv_dateString)}};function nv_formatDateRelative(nv_timestamp){return(nv_getLocalDateString(nv_timestamp))};nv_module.nv_exports = nv_formatDateRelative;return nv_module.nv_exports;}

f_['./assets/formatNumber.dcfc79.wxs'] = nv_require("p_./assets/formatNumber.dcfc79.wxs");
function np_4(){var nv_module={nv_exports:{}};function nv_formatNumber(nv_number){return(typeof nv_number === 'number' ? nv_number.nv_toLocaleString():nv_number)};nv_module.nv_exports = nv_formatNumber;return nv_module.nv_exports;}

f_['./assets/fromNow.4e1ce3.wxs'] = nv_require("p_./assets/fromNow.4e1ce3.wxs");
function np_5(){var nv_module={nv_exports:{}};var nv_fromNow = (function (nv_past,nv_now,nv_maxUnit){nv_past = nv_getDate(nv_past);nv_now = nv_now ? nv_getDate(nv_now):nv_getDate();var nv_delta = (nv_now - nv_past) / 1000;if (nv_delta < 0){nv_delta = -nv_delta;if (nv_delta < 60){return(Math.nv_ceil(nv_delta) + ' 秒后')};nv_delta = nv_parseInt(nv_delta / 60,10);if (nv_delta < 60){return(nv_delta + ' 分钟后')};nv_delta = nv_parseInt(nv_delta / 60,10);if (nv_delta < 24 || nv_maxUnit === 'hour'){return(nv_delta + ' 小时后')};var nv_nowDate = nv_getDate(nv_now);var nv_pastDate = nv_getDate(nv_past);nv_delta = nv_parseInt((nv_pastDate - nv_nowDate) / 86400000,10);return(nv_delta + ' 天后')} else if (nv_delta < 60){return('刚刚')};nv_delta = nv_parseInt(nv_delta / 60,10);if (nv_delta < 60){return(nv_delta + ' 分钟前')};nv_delta = nv_parseInt(nv_delta / 60,10);if (nv_delta < 24){return(nv_delta + ' 小时前')};var nv_yearGap = nv_now.nv_getFullYear() - nv_past.nv_getFullYear();var nv_monthGap = nv_now.nv_getMonth() - nv_past.nv_getMonth();var nv_dayGap = nv_now.nv_getDate() - nv_past.nv_getDate();var nv_daysInCurrentMonth = (function (nv_date){return(nv_getDate(nv_date.nv_getFullYear(),nv_date.nv_getMonth() + 1,0).nv_getDate())});if (nv_yearGap === 0 && nv_monthGap === 0){return(nv_dayGap + ' 天前')};if ((nv_yearGap === 0 && nv_monthGap === 1) || (nv_yearGap === 1 && nv_monthGap === -11)){if (nv_dayGap < 0){return(nv_daysInCurrentMonth(nv_past) + nv_dayGap + ' 天前')};return('1 月前')};if (nv_yearGap < 2){if (nv_yearGap === 1 && nv_monthGap >= 0){return('1 年前')};return(nv_yearGap * 12 + nv_monthGap) + ' 月前'};return(nv_yearGap + ' 年前')});nv_module.nv_exports = nv_fromNow;return nv_module.nv_exports;}

f_['./assets/getUrl.baad23.wxs'] = nv_require("p_./assets/getUrl.baad23.wxs");
function np_6(){var nv_module={nv_exports:{}};nv_module.nv_exports.nv_getTitleUrl = (function (nv_searchResult){if (['answer','question'].nv_indexOf(nv_searchResult.nv_object.nv_type) !== -1){var nv_object = nv_searchResult.nv_object;return('/zhihu/question?id\x3d' + (nv_object.nv_question ? nv_object.nv_question.nv_id:nv_object.nv_id) + '\x26source\x3dsearch')};if (nv_searchResult.nv_object.nv_type === 'article'){return('/zhihu/article?id\x3d' + nv_searchResult.nv_object.nv_id + '\x26source\x3dsearch')}});nv_module.nv_exports.nv_getDescriptionUrl = (function (nv_searchResult){return('/zhihu/' + nv_searchResult.nv_object.nv_type + '?id\x3d' + nv_searchResult.nv_object.nv_id + '\x26source\x3dsearch')});return nv_module.nv_exports;}

f_['./assets/img.065e87.wxs'] = nv_require("p_./assets/img.065e87.wxs");
function np_7(){var nv_module={nv_exports:{}};function nv_nullOrLatter(nv_fn){return((function (nv_next,nv_prev){if (nv_next === '')return('');;if (!nv_next)return(nv_prev);;return(nv_fn(nv_next,nv_prev))}))};function nv_getSize(nv_size){return('_' + nv_size)};var nv_getReplaceSize = nv_nullOrLatter(nv_getSize);function nv_getQuality(nv_quality){return(nv_quality + '/')};var nv_getReplaceQuality = nv_nullOrLatter(nv_getQuality);nv_module.nv_exports.nv_imgUrl = (function (){arguments.nv_length=arguments.length;var nv_url = arguments.nv_length > 0 && arguments[(0)] !== undefined ? arguments[(0)]:'';var nv_options = arguments.nv_length > 1 && arguments[(1)] !== undefined ? arguments[(1)]:({});var nv_quality;var nv_size;var nv_extension;var nv_IMAGE_REG = nv_getRegExp('([a-z|:|/|\x5c.|\x5cd]+)(.com\x5c/)(\x5cd+\x5c/)?([^_.]+)?(_[^.]+)?\x5c.?(\x5cw+)?$');if (typeof nv_options === 'string'){nv_size = nv_options} else {nv_size = nv_options.nv_size;nv_quality = nv_options.nv_quality;nv_extension = nv_options.nv_extension};return(nv_url.nv_replace(nv_IMAGE_REG,(function (nv__,nv_m1,nv_m2,nv_m3,nv_m4,nv_m5,nv_m6){return([nv_m1,nv_m2,nv_getReplaceQuality(nv_quality,nv_m3),nv_m4,nv_getReplaceSize(nv_size,nv_m5),nv_extension ? '.' + nv_extension:(nv_m6 && ('.' + nv_m6))].nv_join(''))})))});return nv_module.nv_exports;}

f_['./assets/number.a72fe9.wxs'] = nv_require("p_./assets/number.a72fe9.wxs");
function np_8(){var nv_module={nv_exports:{}};function nv_removeZero(nv_numStr){var nv_index = nv_numStr.nv_indexOf('.0');return(nv_index === nv_numStr.nv_length - 2 ? nv_numStr.nv_slice(0,nv_index):nv_numStr)};function nv_niceNumber(nv_num){if (typeof nv_num !== 'number'){return('')};if (nv_num < 1000){return(nv_num.nv_toString())};if (nv_num < 10000){return(nv_removeZero((nv_num / 1000).nv_toFixed(1)) + 'K')};if (nv_num < 1000000){return(Math.nv_floor(nv_num / 1000) + 'K')};if (nv_num < 1000000000){return(Math.nv_floor(nv_num / 1000000) + 'M')};return(Math.nv_floor(nv_num / 1000000000) + 'G')};nv_module.nv_exports.nv_niceNumber = nv_niceNumber;return nv_module.nv_exports;}

f_['./assets/urlUtils.9e9247.wxs'] = nv_require("p_./assets/urlUtils.9e9247.wxs");
function np_9(){var nv_module={nv_exports:{}};function nv_encode(nv_para){return(nv_encodeURIComponent(nv_para))};nv_module.nv_exports.nv_encode = nv_encode;return nv_module.nv_exports;}

f_['./components/HotRecommandsItem.wxml']={};
f_['./components/HotRecommandsItem.wxml']['img'] =f_['./assets/img.065e87.wxs'] || nv_require("p_./assets/img.065e87.wxs");
f_['./components/HotRecommandsItem.wxml']['img']();
f_['./components/HotRecommandsItem.wxml']['desc'] =f_['./assets/desc.50f081.wxs'] || nv_require("p_./assets/desc.50f081.wxs");
f_['./components/HotRecommandsItem.wxml']['desc']();

f_['./pages/index/index.wxml']={};
f_['./pages/index/index.wxml']['cx'] =f_['./assets/cx.68d766.wxs'] || nv_require("p_./assets/cx.68d766.wxs");
f_['./pages/index/index.wxml']['cx']();

f_['./pages/index/uiHotItem.wxml']={};
f_['./pages/index/uiHotItem.wxml']['cx'] =f_['./assets/cx.68d766.wxs'] || nv_require("p_./assets/cx.68d766.wxs");
f_['./pages/index/uiHotItem.wxml']['cx']();

f_['./pages/index/uiRecommendItem.wxml']={};
f_['./pages/index/uiRecommendItem.wxml']['formatNumber'] =f_['./assets/formatNumber.dcfc79.wxs'] || nv_require("p_./assets/formatNumber.dcfc79.wxs");
f_['./pages/index/uiRecommendItem.wxml']['formatNumber']();

f_['./pages/index/uiSubscription.wxml']={};
f_['./pages/index/uiSubscription.wxml']['cx'] =f_['./assets/cx.68d766.wxs'] || nv_require("p_./assets/cx.68d766.wxs");
f_['./pages/index/uiSubscription.wxml']['cx']();

f_['./pages/search/index.wxml']={};
f_['./pages/search/index.wxml']['url'] =f_['./assets/getUrl.baad23.wxs'] || nv_require("p_./assets/getUrl.baad23.wxs");
f_['./pages/search/index.wxml']['url']();

f_['./zhihu/AbstractComment.wxml']={};
f_['./zhihu/AbstractComment.wxml']['formatNumber'] =f_['./assets/formatNumber.dcfc79.wxs'] || nv_require("p_./assets/formatNumber.dcfc79.wxs");
f_['./zhihu/AbstractComment.wxml']['formatNumber']();

f_['./zhihu/CommentItem.wxml']={};
f_['./zhihu/CommentItem.wxml']['date'] =f_['./assets/date.7fb565.wxs'] || nv_require("p_./assets/date.7fb565.wxs");
f_['./zhihu/CommentItem.wxml']['date']();
f_['./zhihu/CommentItem.wxml']['img'] =f_['./assets/img.065e87.wxs'] || nv_require("p_./assets/img.065e87.wxs");
f_['./zhihu/CommentItem.wxml']['img']();

f_['./zhihu/CommentPanel.wxml']={};
f_['./zhihu/CommentPanel.wxml']['formatNumber'] =f_['./assets/formatNumber.dcfc79.wxs'] || nv_require("p_./assets/formatNumber.dcfc79.wxs");
f_['./zhihu/CommentPanel.wxml']['formatNumber']();

f_['./zhihu/ToolBar.wxml']={};
f_['./zhihu/ToolBar.wxml']['number'] =f_['./assets/number.a72fe9.wxs'] || nv_require("p_./assets/number.a72fe9.wxs");
f_['./zhihu/ToolBar.wxml']['number']();

f_['./zhihu/answer.wxml']={};
f_['./zhihu/answer.wxml']['formatDateRelative'] =f_['./assets/formatDateRelative.861987.wxs'] || nv_require("p_./assets/formatDateRelative.861987.wxs");
f_['./zhihu/answer.wxml']['formatDateRelative']();
f_['./zhihu/answer.wxml']['img'] =f_['./assets/img.065e87.wxs'] || nv_require("p_./assets/img.065e87.wxs");
f_['./zhihu/answer.wxml']['img']();
f_['./zhihu/answer.wxml']['formatNumber'] =f_['./assets/formatNumber.dcfc79.wxs'] || nv_require("p_./assets/formatNumber.dcfc79.wxs");
f_['./zhihu/answer.wxml']['formatNumber']();

f_['./zhihu/article.wxml']={};
f_['./zhihu/article.wxml']['fromNow'] =f_['./assets/fromNow.4e1ce3.wxs'] || nv_require("p_./assets/fromNow.4e1ce3.wxs");
f_['./zhihu/article.wxml']['fromNow']();
f_['./zhihu/article.wxml']['img'] =f_['./assets/img.065e87.wxs'] || nv_require("p_./assets/img.065e87.wxs");
f_['./zhihu/article.wxml']['img']();

f_['./zhihu/question.wxml']={};
f_['./zhihu/question.wxml']['fromNow'] =f_['./assets/fromNow.4e1ce3.wxs'] || nv_require("p_./assets/fromNow.4e1ce3.wxs");
f_['./zhihu/question.wxml']['fromNow']();
f_['./zhihu/question.wxml']['formatNumber'] =f_['./assets/formatNumber.dcfc79.wxs'] || nv_require("p_./assets/formatNumber.dcfc79.wxs");
f_['./zhihu/question.wxml']['formatNumber']();
f_['./zhihu/question.wxml']['img'] =f_['./assets/img.065e87.wxs'] || nv_require("p_./assets/img.065e87.wxs");
f_['./zhihu/question.wxml']['img']();

f_['./zhihu/uiFooter.wxml']={};
f_['./zhihu/uiFooter.wxml']['urlUtils'] =f_['./assets/urlUtils.9e9247.wxs'] || nv_require("p_./assets/urlUtils.9e9247.wxs");
f_['./zhihu/uiFooter.wxml']['urlUtils']();

var x=['./_/_node_modules_/@wxa/ztext/lib/ui-codeblock.wxml','./_/_node_modules_/@wxa/ztext/lib/ui-gif.wxml','./_/_node_modules_/@wxa/ztext/lib/ui-image.wxml','./_/_node_modules_/@wxa/ztext/lib/ui-video.wxml','./_/_node_modules_/@wxa/ztext/lib/ztext-auto.wxml','./_/_node_modules_/@wxa/ztext/lib/ztext.wxml','./components/HotRecommandsItem.wxml','./components/OffscreenMeasure.wxml','./components/OpenInApp.wxml','./components/SafeAreaInset.wxml','./components/Spinner.wxml','./components/TabNav.wxml','./components/TopToast.wxml','./components/VideoThumbnail.wxml','./pages/error/index.wxml','./pages/index/index.wxml','./pages/index/uiHotItem.wxml','./pages/index/uiRecommendItem.wxml','./pages/index/uiSubscription.wxml','./pages/search/index.wxml','./zhihu/AbstractComment.wxml','./zhihu/CommentItem.wxml','./zhihu/CommentPanel.wxml','./zhihu/HotRecommand.wxml','./zhihu/ToolBar.wxml','./zhihu/answer.wxml','./zhihu/article.wxml','./zhihu/question.wxml','./zhihu/uiFooter.wxml','./zhihu/uiSummary.wxml','./zhihu/uiThumbnailInfo.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var xC=_m('view',['bind:tap',0,'class',1],[],e,s,gg)
var oD=_v()
_(xC,oD)
if(_o(2,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(xC,fE)
if(_o(3,e,s,gg)){fE.wxVkey=1
}
var cF=_v()
_(xC,cF)
if(_o(4,e,s,gg)){cF.wxVkey=1
}
var hG=_v()
_(xC,hG)
if(_o(5,e,s,gg)){hG.wxVkey=1
}
oD.wxXCkey=1
fE.wxXCkey=1
cF.wxXCkey=1
hG.wxXCkey=1
_(r,xC)
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
d_[x[3]]={}
var m3=function(e,s,r,gg){
var oJ=_m('view',['bind:tap',6,'class',1],[],e,s,gg)
var lK=_n('view')
_r(lK,'class',8,e,s,gg)
var aL=_v()
_(lK,aL)
if(_o(9,e,s,gg)){aL.wxVkey=1
}
var tM=_v()
_(lK,tM)
if(_o(10,e,s,gg)){tM.wxVkey=1
}
aL.wxXCkey=1
tM.wxXCkey=1
_(oJ,lK)
_(r,oJ)
return r
}
e_[x[3]]={f:m3,j:[],i:[],ti:[],ic:[]}
d_[x[4]]={}
var m4=function(e,s,r,gg){
var bO=_m('ztext',['tree',11,'useFullscreenVideo',1],[],e,s,gg)
_(r,bO)
return r
}
e_[x[4]]={f:m4,j:[],i:[],ti:[],ic:[]}
d_[x[5]]={}
var m5=function(e,s,r,gg){
var xQ=_n('view')
_r(xQ,'class',13,e,s,gg)
var oR=_v()
_(xQ,oR)
if(_o(14,e,s,gg)){oR.wxVkey=1
}
var fS=_v()
_(xQ,fS)
var cT=function(oV,hU,cW,gg){
var lY=_v()
_(cW,lY)
if(_o(19,oV,hU,gg)){lY.wxVkey=1
var aZ=_v()
_(lY,aZ)
if(_o(20,oV,hU,gg)){aZ.wxVkey=1
}
else if(_o(21,oV,hU,gg)){aZ.wxVkey=2
var t1=_m('ui-image',['blockClass',22,'node',1,'previewUrls',2],[],oV,hU,gg)
_(aZ,t1)
}
else if(_o(25,oV,hU,gg)){aZ.wxVkey=3
var e2=_m('ui-codeblock',['blockClass',26,'node',1],[],oV,hU,gg)
_(aZ,e2)
}
else if(_o(28,oV,hU,gg)){aZ.wxVkey=4
var b3=_m('ui-video',['blockClass',29,'node',1,'useFullscreenVideo',2],[],oV,hU,gg)
_(aZ,b3)
}
else if(_o(32,oV,hU,gg)){aZ.wxVkey=5
var o4=_m('ui-gif',['blockClass',33,'node',1],[],oV,hU,gg)
_(aZ,o4)
}
aZ.wxXCkey=1
aZ.wxXCkey=3
aZ.wxXCkey=3
aZ.wxXCkey=3
aZ.wxXCkey=3
}
lY.wxXCkey=1
lY.wxXCkey=3
return cW
}
fS.wxXCkey=4
_2(17,cT,e,s,gg,fS,'item','index','{{index}}')
oR.wxXCkey=1
_(r,xQ)
return r
}
e_[x[5]]={f:m5,j:[],i:[],ti:[],ic:[]}
d_[x[6]]={}
var m6=function(e,s,r,gg){
var o6=_n('view')
_r(o6,'bindtap',35,e,s,gg)
var f7=_v()
_(o6,f7)
if(_o(36,e,s,gg)){f7.wxVkey=1
}
f7.wxXCkey=1
_(r,o6)
return r
}
e_[x[6]]={f:m6,j:[],i:[],ti:[],ic:[]}
d_[x[7]]={}
var m7=function(e,s,r,gg){
var h9=_n('slot')
_(r,h9)
return r
}
e_[x[7]]={f:m7,j:[],i:[],ti:[],ic:[]}
d_[x[8]]={}
var m8=function(e,s,r,gg){
var cAB=_v()
_(r,cAB)
if(_o(37,e,s,gg)){cAB.wxVkey=1
}
cAB.wxXCkey=1
return r
}
e_[x[8]]={f:m8,j:[],i:[],ti:[],ic:[]}
d_[x[9]]={}
var m9=function(e,s,r,gg){
return r
}
e_[x[9]]={f:m9,j:[],i:[],ti:[],ic:[]}
d_[x[10]]={}
var m10=function(e,s,r,gg){
return r
}
e_[x[10]]={f:m10,j:[],i:[],ti:[],ic:[]}
d_[x[11]]={}
var m11=function(e,s,r,gg){
return r
}
e_[x[11]]={f:m11,j:[],i:[],ti:[],ic:[]}
d_[x[12]]={}
var m12=function(e,s,r,gg){
var eFB=_v()
_(r,eFB)
if(_o(38,e,s,gg)){eFB.wxVkey=1
}
eFB.wxXCkey=1
return r
}
e_[x[12]]={f:m12,j:[],i:[],ti:[],ic:[]}
d_[x[13]]={}
var m13=function(e,s,r,gg){
var oHB=_v()
_(r,oHB)
if(_o(39,e,s,gg)){oHB.wxVkey=1
var xIB=_m('ui-video',['lensId',40,'poster',1,'useFullscreenVideo',2],[],e,s,gg)
_(oHB,xIB)
}
oHB.wxXCkey=1
oHB.wxXCkey=3
return r
}
e_[x[13]]={f:m13,j:[],i:[],ti:[],ic:[]}
d_[x[14]]={}
var m14=function(e,s,r,gg){
var fKB=_v()
_(r,fKB)
if(_o(43,e,s,gg)){fKB.wxVkey=1
var cLB=_n('view')
_r(cLB,'class',44,e,s,gg)
var hMB=_v()
_(cLB,hMB)
if(_o(45,e,s,gg)){hMB.wxVkey=1
}
var oNB=_v()
_(cLB,oNB)
if(_o(46,e,s,gg)){oNB.wxVkey=1
}
hMB.wxXCkey=1
oNB.wxXCkey=1
_(fKB,cLB)
}
fKB.wxXCkey=1
return r
}
e_[x[14]]={f:m14,j:[],i:[],ti:[],ic:[]}
d_[x[15]]={}
var m15=function(e,s,r,gg){
var oPB=_m('TabNav',['activeNav',47,'bind:scrollpositionrestored',1,'bind:searchIconTap',2,'bind:tabchange',3,'searchIconOpacity',4],[],e,s,gg)
_(r,oPB)
var lQB=_m('TopToast',['bind:onref',52,'offset',1,'text',2],[],e,s,gg)
_(r,lQB)
var aRB=_m('Subscription',['bind:subcribe',55,'isVisible',1,'showButton',2],[],e,s,gg)
_(r,aRB)
var tSB=_m('swiper',['bindchange',58,'bindtouchend',1,'class',2,'current',3,'duration',4],[],e,s,gg)
var eTB=_v()
_(tSB,eTB)
if(_o(63,e,s,gg)){eTB.wxVkey=1
var oVB=_m('scroll-view',['scrollY',-1,'bindscroll',64,'class',1,'enableBackToTop',2],[],e,s,gg)
var xWB=_v()
_(oVB,xWB)
var oXB=function(cZB,fYB,h1B,gg){
var c3B=_m('form',['bind:submit',70,'data-type',1,'data-urltoken',2,'reportSubmit',3],[],cZB,fYB,gg)
var o4B=_m('HotItem',['index',74,'item',1],[],cZB,fYB,gg)
_(c3B,o4B)
_(h1B,c3B)
return h1B
}
xWB.wxXCkey=4
_2(68,oXB,e,s,gg,xWB,'hotItem','index','{{hotItem.id}}')
_(eTB,oVB)
}
var bUB=_v()
_(tSB,bUB)
if(_o(76,e,s,gg)){bUB.wxVkey=1
var l5B=_m('scroll-view',['scrollY',-1,'bindscroll',77,'bindscrolltolower',1,'class',2,'enableBackToTop',3,'lowerThreshold',4],[],e,s,gg)
var a6B=_v()
_(l5B,a6B)
var t7B=function(b9B,e8B,o0B,gg){
var oBC=_n('RecommendItem')
_r(oBC,'item',85,b9B,e8B,gg)
_(o0B,oBC)
return o0B
}
a6B.wxXCkey=4
_2(83,t7B,e,s,gg,a6B,'item','index','{{item.id}}')
_(bUB,l5B)
}
eTB.wxXCkey=1
eTB.wxXCkey=3
bUB.wxXCkey=1
bUB.wxXCkey=3
_(r,tSB)
return r
}
e_[x[15]]={f:m15,j:[],i:[],ti:[],ic:[]}
d_[x[16]]={}
var m16=function(e,s,r,gg){
var cDC=_m('view',['bindtap',86,'class',1],[],e,s,gg)
var hEC=_n('view')
_r(hEC,'class',88,e,s,gg)
var oFC=_v()
_(hEC,oFC)
if(_o(89,e,s,gg)){oFC.wxVkey=1
}
var cGC=_v()
_(hEC,cGC)
if(_o(90,e,s,gg)){cGC.wxVkey=1
}
oFC.wxXCkey=1
cGC.wxXCkey=1
_(cDC,hEC)
_(r,cDC)
return r
}
e_[x[16]]={f:m16,j:[],i:[],ti:[],ic:[]}
d_[x[17]]={}
var m17=function(e,s,r,gg){
var lIC=_m('view',['bindtap',91,'class',1,'data-type',2,'data-urltoken',3],[],e,s,gg)
var aJC=_v()
_(lIC,aJC)
if(_o(95,e,s,gg)){aJC.wxVkey=1
var tKC=_n('view')
_r(tKC,'class',96,e,s,gg)
var eLC=_v()
_(tKC,eLC)
if(_o(97,e,s,gg)){eLC.wxVkey=1
}
var bMC=_v()
_(tKC,bMC)
if(_o(98,e,s,gg)){bMC.wxVkey=1
}
eLC.wxXCkey=1
bMC.wxXCkey=1
_(aJC,tKC)
}
aJC.wxXCkey=1
_(r,lIC)
return r
}
e_[x[17]]={f:m17,j:[],i:[],ti:[],ic:[]}
d_[x[18]]={}
var m18=function(e,s,r,gg){
return r
}
e_[x[18]]={f:m18,j:[],i:[],ti:[],ic:[]}
d_[x[19]]={}
var m19=function(e,s,r,gg){
var oPC=_v()
_(r,oPC)
if(_o(99,e,s,gg)){oPC.wxVkey=1
}
var fQC=_v()
_(r,fQC)
if(_o(100,e,s,gg)){fQC.wxVkey=1
var cUC=_n('view')
_r(cUC,'class',101,e,s,gg)
var lWC=_n('view')
_r(lWC,'class',102,e,s,gg)
var aXC=_v()
_(lWC,aXC)
if(_o(103,e,s,gg)){aXC.wxVkey=1
}
var tYC=_v()
_(lWC,tYC)
var eZC=function(o2C,b1C,x3C,gg){
var f5C=_m('view',['bindtap',107,'class',1,'data-query',2,'data-type',3],[],o2C,b1C,gg)
var c6C=_v()
_(f5C,c6C)
if(_o(111,o2C,b1C,gg)){c6C.wxVkey=1
}
c6C.wxXCkey=1
_(x3C,f5C)
return x3C
}
tYC.wxXCkey=2
_2(105,eZC,e,s,gg,tYC,'topWord','index','{{index}}')
aXC.wxXCkey=1
_(cUC,lWC)
var oVC=_v()
_(cUC,oVC)
if(_o(112,e,s,gg)){oVC.wxVkey=1
var h7C=_n('view')
_r(h7C,'class',113,e,s,gg)
var c9C=_v()
_(h7C,c9C)
var o0C=function(aBD,lAD,tCD,gg){
var bED=_v()
_(tCD,bED)
if(_o(117,aBD,lAD,gg)){bED.wxVkey=1
}
bED.wxXCkey=1
return tCD
}
c9C.wxXCkey=2
_2(115,o0C,e,s,gg,c9C,'historyWord','index','{{index}}')
var o8C=_v()
_(h7C,o8C)
if(_o(118,e,s,gg)){o8C.wxVkey=1
}
o8C.wxXCkey=1
_(oVC,h7C)
}
oVC.wxXCkey=1
_(fQC,cUC)
}
var cRC=_v()
_(r,cRC)
if(_o(119,e,s,gg)){cRC.wxVkey=1
}
var hSC=_v()
_(r,hSC)
if(_o(120,e,s,gg)){hSC.wxVkey=1
var oFD=_n('Spinner')
_(hSC,oFD)
}
var oTC=_v()
_(r,oTC)
if(_o(121,e,s,gg)){oTC.wxVkey=1
var xGD=_n('view')
_r(xGD,'class',122,e,s,gg)
var oHD=_v()
_(xGD,oHD)
if(_o(123,e,s,gg)){oHD.wxVkey=1
var hKD=_v()
_(oHD,hKD)
var oLD=function(oND,cMD,lOD,gg){
var tQD=_n('view')
_r(tQD,'class',127,oND,cMD,gg)
var eRD=_v()
_(tQD,eRD)
if(_o(128,oND,cMD,gg)){eRD.wxVkey=1
}
var xUD=_n('view')
_r(xUD,'class',129,oND,cMD,gg)
var oVD=_v()
_(xUD,oVD)
if(_o(130,oND,cMD,gg)){oVD.wxVkey=1
}
var fWD=_v()
_(xUD,fWD)
if(_o(131,oND,cMD,gg)){fWD.wxVkey=1
}
var cXD=_v()
_(xUD,cXD)
if(_o(132,oND,cMD,gg)){cXD.wxVkey=1
var hYD=_v()
_(cXD,hYD)
var oZD=function(o2D,c1D,l3D,gg){
var t5D=_v()
_(l3D,t5D)
if(_o(135,o2D,c1D,gg)){t5D.wxVkey=1
}
t5D.wxXCkey=1
return l3D
}
hYD.wxXCkey=2
_2(134,oZD,oND,cMD,gg,hYD,'img','index','')
}
oVD.wxXCkey=1
fWD.wxXCkey=1
cXD.wxXCkey=1
_(tQD,xUD)
var bSD=_v()
_(tQD,bSD)
if(_o(136,oND,cMD,gg)){bSD.wxVkey=1
}
var oTD=_v()
_(tQD,oTD)
if(_o(137,oND,cMD,gg)){oTD.wxVkey=1
}
eRD.wxXCkey=1
bSD.wxXCkey=1
oTD.wxXCkey=1
_(lOD,tQD)
return lOD
}
hKD.wxXCkey=2
_2(125,oLD,e,s,gg,hKD,'resultItem','index','{{resultItem.id}}')
var cJD=_v()
_(oHD,cJD)
if(_o(138,e,s,gg)){cJD.wxVkey=1
var e6D=_n('Spinner')
_(cJD,e6D)
}
cJD.wxXCkey=1
cJD.wxXCkey=3
}
var fID=_v()
_(xGD,fID)
if(_o(139,e,s,gg)){fID.wxVkey=1
}
oHD.wxXCkey=1
oHD.wxXCkey=3
fID.wxXCkey=1
_(oTC,xGD)
}
oPC.wxXCkey=1
fQC.wxXCkey=1
cRC.wxXCkey=1
hSC.wxXCkey=1
hSC.wxXCkey=3
oTC.wxXCkey=1
oTC.wxXCkey=3
return r
}
e_[x[19]]={f:m19,j:[],i:[],ti:[],ic:[]}
d_[x[20]]={}
var m20=function(e,s,r,gg){
var o8D=_n('view')
_r(o8D,'class',140,e,s,gg)
var x9D=_v()
_(o8D,x9D)
if(_o(141,e,s,gg)){x9D.wxVkey=1
var o0D=_v()
_(x9D,o0D)
var fAE=function(hCE,cBE,oDE,gg){
var oFE=_n('CommentItem')
_r(oFE,'comment',145,hCE,cBE,gg)
_(oDE,oFE)
return oDE
}
o0D.wxXCkey=4
_2(143,fAE,e,s,gg,o0D,'comment','index','{{comment.id}}')
}
else{x9D.wxVkey=2
}
var lGE=_n('SafeAreaInset')
_(o8D,lGE)
x9D.wxXCkey=1
x9D.wxXCkey=3
_(r,o8D)
return r
}
e_[x[20]]={f:m20,j:[],i:[],ti:[],ic:[]}
d_[x[21]]={}
var m21=function(e,s,r,gg){
var tIE=_n('view')
_r(tIE,'class',146,e,s,gg)
var eJE=_v()
_(tIE,eJE)
if(_o(147,e,s,gg)){eJE.wxVkey=1
}
var bKE=_v()
_(tIE,bKE)
if(_o(148,e,s,gg)){bKE.wxVkey=1
}
eJE.wxXCkey=1
bKE.wxXCkey=1
_(r,tIE)
return r
}
e_[x[21]]={f:m21,j:[],i:[],ti:[],ic:[]}
d_[x[22]]={}
var m22=function(e,s,r,gg){
var xME=_m('scroll-view',['scrollY',-1,'bindscrolltolower',149,'class',1,'lowerThreshold',2],[],e,s,gg)
var oNE=_v()
_(xME,oNE)
if(_o(152,e,s,gg)){oNE.wxVkey=1
}
var cPE=_v()
_(xME,cPE)
var hQE=function(cSE,oRE,oTE,gg){
var aVE=_n('view')
_r(aVE,'class',156,cSE,oRE,gg)
var eXE=_n('CommentItem')
_r(eXE,'comment',157,cSE,oRE,gg)
_(aVE,eXE)
var tWE=_v()
_(aVE,tWE)
if(_o(158,cSE,oRE,gg)){tWE.wxVkey=1
var bYE=_v()
_(tWE,bYE)
var oZE=function(o2E,x1E,f3E,gg){
var h5E=_n('CommentItem')
_r(h5E,'comment',162,o2E,x1E,gg)
_(f3E,h5E)
return f3E
}
bYE.wxXCkey=4
_2(160,oZE,cSE,oRE,gg,bYE,'childComment','index','{{childComment.id}}')
}
tWE.wxXCkey=1
tWE.wxXCkey=3
_(oTE,aVE)
return oTE
}
cPE.wxXCkey=4
_2(154,hQE,e,s,gg,cPE,'comment','index','{{comment.id}}')
var fOE=_v()
_(xME,fOE)
if(_o(163,e,s,gg)){fOE.wxVkey=1
}
var o6E=_v()
_(xME,o6E)
var c7E=function(l9E,o8E,a0E,gg){
var eBF=_n('view')
_r(eBF,'class',167,l9E,o8E,gg)
var oDF=_n('CommentItem')
_r(oDF,'comment',168,l9E,o8E,gg)
_(eBF,oDF)
var bCF=_v()
_(eBF,bCF)
if(_o(169,l9E,o8E,gg)){bCF.wxVkey=1
var xEF=_v()
_(bCF,xEF)
var oFF=function(cHF,fGF,hIF,gg){
var cKF=_n('CommentItem')
_r(cKF,'comment',173,cHF,fGF,gg)
_(hIF,cKF)
return hIF
}
xEF.wxXCkey=4
_2(171,oFF,l9E,o8E,gg,xEF,'childComment','index','{{childComment.id}}')
}
bCF.wxXCkey=1
bCF.wxXCkey=3
_(a0E,eBF)
return a0E
}
o6E.wxXCkey=4
_2(165,c7E,e,s,gg,o6E,'comment','index','{{comment.id}}')
oNE.wxXCkey=1
fOE.wxXCkey=1
_(r,xME)
return r
}
e_[x[22]]={f:m22,j:[],i:[],ti:[],ic:[]}
d_[x[23]]={}
var m23=function(e,s,r,gg){
var lMF=_n('view')
_r(lMF,'class',174,e,s,gg)
var aNF=_v()
_(lMF,aNF)
if(_o(175,e,s,gg)){aNF.wxVkey=1
var bQF=_v()
_(aNF,bQF)
var oRF=function(oTF,xSF,fUF,gg){
var hWF=_n('HotRecommandsItem')
_r(hWF,'recommand',179,oTF,xSF,gg)
_(fUF,hWF)
return fUF
}
bQF.wxXCkey=4
_2(177,oRF,e,s,gg,bQF,'recommand','index','{{recommand.url_token}}')
}
var tOF=_v()
_(lMF,tOF)
if(_o(180,e,s,gg)){tOF.wxVkey=1
}
var ePF=_v()
_(lMF,ePF)
if(_o(181,e,s,gg)){ePF.wxVkey=1
var oXF=_n('Spinner')
_(ePF,oXF)
}
var cYF=_n('SafeAreaInset')
_(lMF,cYF)
aNF.wxXCkey=1
aNF.wxXCkey=3
tOF.wxXCkey=1
ePF.wxXCkey=1
ePF.wxXCkey=3
_(r,lMF)
return r
}
e_[x[23]]={f:m23,j:[],i:[],ti:[],ic:[]}
d_[x[24]]={}
var m24=function(e,s,r,gg){
var l1F=_n('view')
_r(l1F,'class',182,e,s,gg)
var a2F=_v()
_(l1F,a2F)
if(_o(183,e,s,gg)){a2F.wxVkey=1
}
var t3F=_v()
_(l1F,t3F)
if(_o(184,e,s,gg)){t3F.wxVkey=1
}
var e4F=_n('SafeAreaInset')
_(l1F,e4F)
a2F.wxXCkey=1
t3F.wxXCkey=1
_(r,l1F)
return r
}
e_[x[24]]={f:m24,j:[],i:[],ti:[],ic:[]}
d_[x[25]]={}
var m25=function(e,s,r,gg){
var o6F=_v()
_(r,o6F)
if(_o(185,e,s,gg)){o6F.wxVkey=1
var x7F=_n('view')
_r(x7F,'class',186,e,s,gg)
var o8F=_v()
_(x7F,o8F)
if(_o(187,e,s,gg)){o8F.wxVkey=1
}
var oBG=_n('view')
_r(oBG,'class',188,e,s,gg)
var cCG=_v()
_(oBG,cCG)
if(_o(189,e,s,gg)){cCG.wxVkey=1
}
var oDG=_n('view')
_r(oDG,'class',190,e,s,gg)
var lEG=_v()
_(oDG,lEG)
if(_o(191,e,s,gg)){lEG.wxVkey=1
var eHG=_m('ui-video',['bind:expand',192,'videoId',1],[],e,s,gg)
_(lEG,eHG)
}
var aFG=_v()
_(oDG,aFG)
if(_o(194,e,s,gg)){aFG.wxVkey=1
var bIG=_m('ztext-auto',['class',195,'html',1],[],e,s,gg)
_(aFG,bIG)
}
var tGG=_v()
_(oDG,tGG)
if(_o(197,e,s,gg)){tGG.wxVkey=1
}
var oJG=_n('SafeAreaInset')
_(oDG,oJG)
lEG.wxXCkey=1
lEG.wxXCkey=3
aFG.wxXCkey=1
aFG.wxXCkey=3
tGG.wxXCkey=1
_(oBG,oDG)
cCG.wxXCkey=1
_(x7F,oBG)
var f9F=_v()
_(x7F,f9F)
if(_o(198,e,s,gg)){f9F.wxVkey=1
var xKG=_m('AbstractComment',['bindopenCommentPanel',199,'commentCount',1,'entryId',2,'entryType',3],[],e,s,gg)
_(f9F,xKG)
}
var oLG=_m('HotRecommand',['end',203,'loading',1,'recommands',2],[],e,s,gg)
_(x7F,oLG)
var c0F=_v()
_(x7F,c0F)
if(_o(206,e,s,gg)){c0F.wxVkey=1
var fMG=_m('ToolBar',['bindopenCommentPanel',207,'commentCount',1,'entryId',2,'isToolBarShown',3,'type',4,'voteupCount',5,'voting',6],[],e,s,gg)
_(c0F,fMG)
}
var hAG=_v()
_(x7F,hAG)
if(_o(214,e,s,gg)){hAG.wxVkey=1
var cNG=_m('CommentPanel',['bindcloseCommentPanel',215,'entryId',1,'entryType',2],[],e,s,gg)
_(hAG,cNG)
}
var hOG=_n('OpenInApp')
_r(hOG,'url',218,e,s,gg)
_(x7F,hOG)
o8F.wxXCkey=1
f9F.wxXCkey=1
f9F.wxXCkey=3
c0F.wxXCkey=1
c0F.wxXCkey=3
hAG.wxXCkey=1
hAG.wxXCkey=3
_(o6F,x7F)
}
o6F.wxXCkey=1
o6F.wxXCkey=3
return r
}
e_[x[25]]={f:m25,j:[],i:[],ti:[],ic:[]}
d_[x[26]]={}
var m26=function(e,s,r,gg){
var cQG=_v()
_(r,cQG)
if(_o(219,e,s,gg)){cQG.wxVkey=1
var oRG=_n('view')
_r(oRG,'class',220,e,s,gg)
var lSG=_v()
_(oRG,lSG)
if(_o(221,e,s,gg)){lSG.wxVkey=1
}
var eVG=_n('view')
_r(eVG,'class',222,e,s,gg)
var bWG=_v()
_(eVG,bWG)
if(_o(223,e,s,gg)){bWG.wxVkey=1
}
var oXG=_n('view')
_r(oXG,'class',224,e,s,gg)
var xYG=_v()
_(oXG,xYG)
if(_o(225,e,s,gg)){xYG.wxVkey=1
var c2G=_m('ui-video',['bind:expand',226,'videoId',1],[],e,s,gg)
_(xYG,c2G)
}
var oZG=_v()
_(oXG,oZG)
if(_o(228,e,s,gg)){oZG.wxVkey=1
var h3G=_m('ztext-auto',['class',229,'html',1],[],e,s,gg)
_(oZG,h3G)
}
var f1G=_v()
_(oXG,f1G)
if(_o(231,e,s,gg)){f1G.wxVkey=1
}
var o4G=_n('SafeAreaInset')
_(oXG,o4G)
xYG.wxXCkey=1
xYG.wxXCkey=3
oZG.wxXCkey=1
oZG.wxXCkey=3
f1G.wxXCkey=1
_(eVG,oXG)
bWG.wxXCkey=1
_(oRG,eVG)
var aTG=_v()
_(oRG,aTG)
if(_o(232,e,s,gg)){aTG.wxVkey=1
var c5G=_m('ToolBar',['bindopenCommentPanel',233,'commentCount',1,'entryId',2,'isToolBarShown',3,'type',4,'voteupCount',5,'voting',6],[],e,s,gg)
_(aTG,c5G)
}
var tUG=_v()
_(oRG,tUG)
if(_o(240,e,s,gg)){tUG.wxVkey=1
var o6G=_m('CommentPanel',['bindcloseCommentPanel',241,'entryId',1,'entryType',2],[],e,s,gg)
_(tUG,o6G)
}
var l7G=_n('OpenInApp')
_r(l7G,'url',244,e,s,gg)
_(oRG,l7G)
lSG.wxXCkey=1
aTG.wxXCkey=1
aTG.wxXCkey=3
tUG.wxXCkey=1
tUG.wxXCkey=3
_(cQG,oRG)
}
cQG.wxXCkey=1
cQG.wxXCkey=3
return r
}
e_[x[26]]={f:m26,j:[],i:[],ti:[],ic:[]}
d_[x[27]]={}
var m27=function(e,s,r,gg){
var t9G=_n('view')
_r(t9G,'class',245,e,s,gg)
var e0G=_v()
_(t9G,e0G)
if(_o(246,e,s,gg)){e0G.wxVkey=1
var xCH=_m('uiSummary',['detail',247,'excerpt',1],[],e,s,gg)
var oDH=_n('uiThumbnailInfo')
_r(oDH,'info',249,e,s,gg)
_(xCH,oDH)
_(e0G,xCH)
}
var bAH=_v()
_(t9G,bAH)
if(_o(250,e,s,gg)){bAH.wxVkey=1
var fEH=_v()
_(bAH,fEH)
var cFH=function(oHH,hGH,cIH,gg){
var lKH=_m('navigator',['bindtap',254,'class',1,'openType',2,'url',3],[],oHH,hGH,gg)
var aLH=_m('uiThumbnailInfo',['info',258,'thumbnailsClass',1],[],oHH,hGH,gg)
_(lKH,aLH)
_(cIH,lKH)
return cIH
}
fEH.wxXCkey=4
_2(252,cFH,e,s,gg,fEH,'answer','index','{{answer.id}}')
}
var oBH=_v()
_(t9G,oBH)
if(_o(260,e,s,gg)){oBH.wxVkey=1
var tMH=_m('uiFooter',['entryId',261,'entryType',1,'excerpt',2,'title',3],[],e,s,gg)
_(oBH,tMH)
}
var eNH=_n('OpenInApp')
_r(eNH,'url',265,e,s,gg)
_(t9G,eNH)
e0G.wxXCkey=1
e0G.wxXCkey=3
bAH.wxXCkey=1
bAH.wxXCkey=3
oBH.wxXCkey=1
oBH.wxXCkey=3
_(r,t9G)
return r
}
e_[x[27]]={f:m27,j:[],i:[],ti:[],ic:[]}
d_[x[28]]={}
var m28=function(e,s,r,gg){
var oPH=_n('SafeAreaInset')
_(r,oPH)
return r
}
e_[x[28]]={f:m28,j:[],i:[],ti:[],ic:[]}
d_[x[29]]={}
var m29=function(e,s,r,gg){
var oRH=_n('view')
_r(oRH,'class',266,e,s,gg)
var fSH=_v()
_(oRH,fSH)
if(_o(267,e,s,gg)){fSH.wxVkey=1
var cTH=_m('view',['bind:tap',268,'class',1],[],e,s,gg)
var oVH=_n('slot')
_r(oVH,'name',270,e,s,gg)
_(cTH,oVH)
var hUH=_v()
_(cTH,hUH)
if(_o(271,e,s,gg)){hUH.wxVkey=1
var cWH=_n('slot')
_r(cWH,'name',272,e,s,gg)
_(hUH,cWH)
}
var oXH=_n('OffscreenMeasure')
_r(oXH,'bind:measure',273,e,s,gg)
_(cTH,oXH)
hUH.wxXCkey=1
_(fSH,cTH)
}
else{fSH.wxVkey=2
var lYH=_n('ztext-auto')
_r(lYH,'html',274,e,s,gg)
_(fSH,lYH)
}
fSH.wxXCkey=1
fSH.wxXCkey=3
fSH.wxXCkey=3
_(r,oRH)
return r
}
e_[x[29]]={f:m29,j:[],i:[],ti:[],ic:[]}
d_[x[30]]={}
var m30=function(e,s,r,gg){
var t1H=_v()
_(r,t1H)
if(_o(275,e,s,gg)){t1H.wxVkey=1
var e2H=_n('view')
_r(e2H,'class',276,e,s,gg)
var b3H=_v()
_(e2H,b3H)
if(_o(277,e,s,gg)){b3H.wxVkey=1
}
else if(_o(278,e,s,gg)){b3H.wxVkey=2
var o4H=_m('ui-video',['catch:tap',279,'lensId',1,'poster',2],[],e,s,gg)
_(b3H,o4H)
}
b3H.wxXCkey=1
b3H.wxXCkey=3
_(t1H,e2H)
}
t1H.wxXCkey=1
t1H.wxXCkey=3
return r
}
e_[x[30]]={f:m30,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
}catch(err){
console.log(err)
}
return root;
}
}
}
	__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ui-codeblock.json'] = {
  "component": true
};
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ui-codeblock.wxml'] = $gwx( './_/_node_modules_/@wxa/ztext/lib/ui-codeblock.wxml' );
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ui-gif.json'] = {
  "component": true
};
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ui-gif.wxml'] = $gwx( './_/_node_modules_/@wxa/ztext/lib/ui-gif.wxml' );
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ui-image.json'] = {
  "component": true
};
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ui-image.wxml'] = $gwx( './_/_node_modules_/@wxa/ztext/lib/ui-image.wxml' );
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ui-video.json'] = {
  "component": true
};
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ui-video.wxml'] = $gwx( './_/_node_modules_/@wxa/ztext/lib/ui-video.wxml' );
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ztext-auto.json'] = {"component":true,"usingComponents":{"ztext":"/_/_node_modules_/@wxa/ztext/lib/ztext"}};
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ztext-auto.wxml'] = $gwx( './_/_node_modules_/@wxa/ztext/lib/ztext-auto.wxml' );
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ztext.json'] = {"component":true,"usingComponents":{"ui-codeblock":"/_/_node_modules_/@wxa/ztext/lib/ui-codeblock","ui-gif":"/_/_node_modules_/@wxa/ztext/lib/ui-gif","ui-image":"/_/_node_modules_/@wxa/ztext/lib/ui-image","ui-video":"/_/_node_modules_/@wxa/ztext/lib/ui-video"}};
		__wxAppCode__['_/_node_modules_/@wxa/ztext/lib/ztext.wxml'] = $gwx( './_/_node_modules_/@wxa/ztext/lib/ztext.wxml' );
		__wxAppCode__['components/HotRecommandsItem.json'] = {
  "component": true
};
		__wxAppCode__['components/HotRecommandsItem.wxml'] = $gwx( './components/HotRecommandsItem.wxml' );
		__wxAppCode__['components/OffscreenMeasure.json'] = {
  "component": true
};
		__wxAppCode__['components/OffscreenMeasure.wxml'] = $gwx( './components/OffscreenMeasure.wxml' );
		__wxAppCode__['components/OpenInApp.json'] = {
  "component": true
};
		__wxAppCode__['components/OpenInApp.wxml'] = $gwx( './components/OpenInApp.wxml' );
		__wxAppCode__['components/SafeAreaInset.json'] = {
  "component": true
};
		__wxAppCode__['components/SafeAreaInset.wxml'] = $gwx( './components/SafeAreaInset.wxml' );
		__wxAppCode__['components/Spinner.json'] = {
  "component": true
};
		__wxAppCode__['components/Spinner.wxml'] = $gwx( './components/Spinner.wxml' );
		__wxAppCode__['components/TabNav.json'] = {
  "component": true
};
		__wxAppCode__['components/TabNav.wxml'] = $gwx( './components/TabNav.wxml' );
		__wxAppCode__['components/TopToast.json'] = {
  "component": true
};
		__wxAppCode__['components/TopToast.wxml'] = $gwx( './components/TopToast.wxml' );
		__wxAppCode__['components/VideoThumbnail.json'] = {"component":true,"usingComponents":{"ui-video":"/_/_node_modules_/@wxa/ztext/lib/ui-video"}};
		__wxAppCode__['components/VideoThumbnail.wxml'] = $gwx( './components/VideoThumbnail.wxml' );
		__wxAppCode__['pages/index/index.json'] = {"enablePullDownRefresh":true,"usingComponents":{"TabNav":"/components/TabNav","TopToast":"/components/TopToast","Subscription":"/pages/index/uiSubscription","HotItem":"/pages/index/uiHotItem","RecommendItem":"/pages/index/uiRecommendItem"}};
		__wxAppCode__['pages/index/index.wxml'] = $gwx( './pages/index/index.wxml' );
		__wxAppCode__['pages/index/uiHotItem.json'] = {
  "component": true
};
		__wxAppCode__['pages/index/uiHotItem.wxml'] = $gwx( './pages/index/uiHotItem.wxml' );
		__wxAppCode__['pages/index/uiRecommendItem.json'] = {
  "component": true
};
		__wxAppCode__['pages/index/uiRecommendItem.wxml'] = $gwx( './pages/index/uiRecommendItem.wxml' );
		__wxAppCode__['pages/index/uiSubscription.json'] = {
  "component": true
};
		__wxAppCode__['pages/index/uiSubscription.wxml'] = $gwx( './pages/index/uiSubscription.wxml' );
		__wxAppCode__['pages/search/index.json'] = {"usingComponents":{"Spinner":"/components/Spinner"},"onReachBottomDistance":1000};
		__wxAppCode__['pages/search/index.wxml'] = $gwx( './pages/search/index.wxml' );
		__wxAppCode__['zhihu/AbstractComment.json'] = {"component":true,"usingComponents":{"SafeAreaInset":"/components/SafeAreaInset","CommentItem":"/zhihu/CommentItem"}};
		__wxAppCode__['zhihu/AbstractComment.wxml'] = $gwx( './zhihu/AbstractComment.wxml' );
		__wxAppCode__['zhihu/CommentItem.json'] = {
  "component": true
};
		__wxAppCode__['zhihu/CommentItem.wxml'] = $gwx( './zhihu/CommentItem.wxml' );
		__wxAppCode__['zhihu/CommentPanel.json'] = {"component":true,"usingComponents":{"SafeAreaInset":"/components/SafeAreaInset","CommentItem":"/zhihu/CommentItem"}};
		__wxAppCode__['zhihu/CommentPanel.wxml'] = $gwx( './zhihu/CommentPanel.wxml' );
		__wxAppCode__['zhihu/HotRecommand.json'] = {"component":true,"usingComponents":{"SafeAreaInset":"/components/SafeAreaInset","Spinner":"/components/Spinner","HotRecommandsItem":"/components/HotRecommandsItem"}};
		__wxAppCode__['zhihu/HotRecommand.wxml'] = $gwx( './zhihu/HotRecommand.wxml' );
		__wxAppCode__['zhihu/ToolBar.json'] = {"component":true,"usingComponents":{"SafeAreaInset":"/components/SafeAreaInset"}};
		__wxAppCode__['zhihu/ToolBar.wxml'] = $gwx( './zhihu/ToolBar.wxml' );
		__wxAppCode__['zhihu/answer.json'] = {"navigationBarTitleText":"回答","backgroundColor":"#fafafa","onReachBottomDistance":2,"usingComponents":{"ztext-auto":"/_/_node_modules_/@wxa/ztext/lib/ztext-auto","SafeAreaInset":"/components/SafeAreaInset","OpenInApp":"/components/OpenInApp","AbstractComment":"/zhihu/AbstractComment","HotRecommand":"/zhihu/HotRecommand","ToolBar":"/zhihu/ToolBar","ui-video":"/components/VideoThumbnail","CommentPanel":"/zhihu/CommentPanel"}};
		__wxAppCode__['zhihu/answer.wxml'] = $gwx( './zhihu/answer.wxml' );
		__wxAppCode__['zhihu/article.json'] = {"navigationBarTitleText":"文章","onReachBottomDistance":2,"usingComponents":{"ztext-auto":"/_/_node_modules_/@wxa/ztext/lib/ztext-auto","ui-video":"/components/VideoThumbnail","ToolBar":"/zhihu/ToolBar","SafeAreaInset":"/components/SafeAreaInset","OpenInApp":"/components/OpenInApp","CommentPanel":"/zhihu/CommentPanel"}};
		__wxAppCode__['zhihu/article.wxml'] = $gwx( './zhihu/article.wxml' );
		__wxAppCode__['zhihu/question.json'] = {"navigationBarTitleText":"问题","usingComponents":{"ztext":"/_/_node_modules_/@wxa/ztext/lib/ztext","ztext-auto":"/_/_node_modules_/@wxa/ztext/lib/ztext-auto","uiFooter":"/zhihu/uiFooter","uiSummary":"/zhihu/uiSummary","uiThumbnailInfo":"/zhihu/uiThumbnailInfo","OpenInApp":"/components/OpenInApp"}};
		__wxAppCode__['zhihu/question.wxml'] = $gwx( './zhihu/question.wxml' );
		__wxAppCode__['zhihu/uiFooter.json'] = {"component":true,"usingComponents":{"SafeAreaInset":"/components/SafeAreaInset"}};
		__wxAppCode__['zhihu/uiFooter.wxml'] = $gwx( './zhihu/uiFooter.wxml' );
		__wxAppCode__['zhihu/uiSummary.json'] = {"component":true,"usingComponents":{"ztext-auto":"/_/_node_modules_/@wxa/ztext/lib/ztext-auto","OffscreenMeasure":"/components/OffscreenMeasure"}};
		__wxAppCode__['zhihu/uiSummary.wxml'] = $gwx( './zhihu/uiSummary.wxml' );
		__wxAppCode__['zhihu/uiThumbnailInfo.json'] = {"component":true,"usingComponents":{"ui-video":"/_/_node_modules_/@wxa/ztext/lib/ui-video"}};
		__wxAppCode__['zhihu/uiThumbnailInfo.wxml'] = $gwx( './zhihu/uiThumbnailInfo.wxml' );
	
	define("common.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(t){var e=wx.webpackJsonp;wx.webpackJsonp=function(r,o,n){for(var a,c,u,l=0,h=[];l<r.length;l++)c=r[l],s[c]&&h.push(s[c][0]),s[c]=0;for(a in o)Object.prototype.hasOwnProperty.call(o,a)&&(t[a]=o[a]);for(e&&e(r,o,n);h.length;)h.shift()();if(n)for(l=0;l<n.length;l++)u=i(i.s=n[l]);return u};var r={},s={32:0};function i(e){if(r[e])return r[e].exports;var s=r[e]={i:e,l:!1,exports:{}};return t[e].call(s.exports,s,s.exports,i),s.l=!0,s.exports}i.m=t,i.c=r,i.d=function(t,e,r){i.o(t,e)||Object.defineProperty(t,e,{configurable:!1,enumerable:!0,get:r})},i.n=function(t){var e=t&&t.__esModule?function(){return t.default}:function(){return t};return i.d(e,"a",e),e},i.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},i.p="/",i.oe=function(t){throw console.error(t),t}}([function(t,e,r){"use strict";var s=this&&this.__assign||Object.assign||function(t){for(var e,r=1,s=arguments.length;r<s;r++)for(var i in e=arguments[r])Object.prototype.hasOwnProperty.call(e,i)&&(t[i]=e[i]);return t};Object.defineProperty(e,"__esModule",{value:!0});var i=r(1),o=r(6),n=r(3),a="oauth c3cef7c66a1843f8b3a9e6a1e3160e20",c={header:{"Weapp-Alias":"a45c26964c9246caab21aa471ec101be","Weapp-Client-Alias":"c51ae4e5c08949309c10a0389cbb6705"}};e.default=function(t,e){void 0===e&&(e={});var r=function(t){return void 0===t&&(t=""),t.startsWith("http")||t.startsWith("//")?t:""+i.default.dataBaseUrl+t}(t),u=function(){var t=n.getAuthorizationToken(),u={Authorization:t?"bearer "+t:a,"Weapp-Session":wx.getStorageSync("sessionKey"),"X-Weapp-Version":i.default.currentVersion};return o.default(s({url:r},e,c,{header:s({},c.header,u,e.header)}))};return u().catch(function(t){if(401!==t.statusCode||e.shouldOverrideAuthFailure)throw t;return n.setAuthorizationToken(""),new Promise(function(t,e){getApp().authRequired().then(function(){u().then(t,e)},function(){return e({statusCode:401})})})})}},function(t,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var s={apiHost:"https://api.zhihu.com",apiBasePath:"/wx-minapp-push/hot-list",apiBaseUrl:"https://api.zhihu.com/wx-minapp-push/hot-list",dataBaseUrl:"https://www.zhihu.com",webviewBaseUrl:"https://www.zhihu.com/wechat/hotlist",appVersion:"100",currentVersion:"3.2.0"};e.default=s},function(t,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var s=9;e.getOpenType=function(){return getCurrentPages().length<s?"navigate":"redirect"},e.default=function(t){getCurrentPages().length<s?wx.navigateTo(t):wx.redirectTo(t)}},function(t,e,r){"use strict";var s=this&&this.__assign||Object.assign||function(t){for(var e,r=1,s=arguments.length;r<s;r++)for(var i in e=arguments[r])Object.prototype.hasOwnProperty.call(e,i)&&(t[i]=e[i]);return t};Object.defineProperty(e,"__esModule",{value:!0});var i,o=r(1),n=r(0),a=r(45),c=864e3;function u(){return new Promise(function(t,e){wx.getUserInfo({withCredentials:!0,success:t,fail:e})})}!function(t){t[t.LOGGED_IN=0]="LOGGED_IN",t[t.NEED_REFRESH=1]="NEED_REFRESH",t[t.NOT_LOGGED_IN=2]="NOT_LOGGED_IN"}(i=e.LOGIN_STATUS||(e.LOGIN_STATUS={})),e.getSessionKey=function(){return new Promise(function(t,e){wx.login({success:function(r){n.default(o.default.apiHost+"/wx-minapp-account/session",{method:"POST",data:{wx_code:r.code}}).then(function(e){var r=e.data;wx.setStorageSync("sessionKey",r.session_key),t(r.session_key)}).catch(e)},fail:e})})},e.getSessionKeyOnce=a.once(e.getSessionKey),e.getWxUserInfo=u,wx.removeStorageSync("Authorization"),wx.removeStorageSync("Authorization2");var l="Authorization3",h="loginExpiresAt",p="loginRefreshTicket";function _(t){wx.setStorageSync(l,t)}e.setAuthorizationToken=_,e.getAuthorizationStatus=function(){var t=Number(wx.getStorageSync(h)||0),e=Date.now()/1e3,r=wx.getStorageSync(l);return t&&t-e<c?{status:i.NEED_REFRESH,token:wx.getStorageSync(p)}:r?{status:i.LOGGED_IN,token:r}:{status:i.NOT_LOGGED_IN}},e.getAuthorizationToken=function(){return wx.getStorageSync(l)},e.saveLoggedInData=function(t){_(t.login_ticket),wx.setStorageSync(p,t.refresh_ticket),wx.setStorageSync(h,String(t.expires_at))},e.loginZhihu=function(t,r){return n.default(o.default.apiHost+"/wx-minapp-account/login",{method:"POST",data:{user_encrypted_data:t.encryptedData,user_iv:t.iv,login_type:r,refresh_ticket:t.refresh_ticket},shouldOverrideAuthFailure:!0}).then(function(t){var r=t.data;e.saveLoggedInData(r)}).catch(function(e){throw console.error("login failed",e),t})},e.loginZhihuOnce=a.once(e.loginZhihu),function(t){t.refresh="refresh_ticket",t.login="wx-minapp"}(e.LoginType||(e.LoginType={})),e.getAuthorization=function(t){return u().then(function(r){return e.loginZhihuOnce(s({},r,{refresh_ticket:String(wx.getStorageSync(p))}),t)})},e.isLoggedIn=function(){return!!wx.getStorageSync(l)},e.createZhihuAccount=function(t){return n.default(o.default.apiHost+"/wx-minapp-account/bind",{method:"POST",data:{user_encrypted_data:t.encryptedData,user_iv:t.iv}}).then(function(t){var r=t.data;return e.saveLoggedInData(r)})},e.createZhihuAccountOnce=a.once(e.createZhihuAccount)},function(t,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),function(t){t[t.hot=0]="hot",t[t.recommendation=1]="recommendation"}(e.NavIdentifier||(e.NavIdentifier={})),function(t){t[t.DISCOVER=1001]="DISCOVER",t[t.TOP_SEARCH_RESULT=1005]="TOP_SEARCH_RESULT",t[t.DISCOVER_SEARCH_RESULT=1006]="DISCOVER_SEARCH_RESULT",t[t.MESSAGE_CARD=1007]="MESSAGE_CARD",t[t.GROUP_MESSAGE_CARD=1008]="GROUP_MESSAGE_CARD",t[t.SCAN_QRCODE=1011]="SCAN_QRCODE",t[t.PRESS_QRCODE=1012]="PRESS_QRCODE",t[t.ALBUM_QRCODE=1013]="ALBUM_QRCODE",t[t.TEMPLATE_MESSAGE=1014]="TEMPLATE_MESSAGE",t[t.STAGING_ENTRANCE=1017]="STAGING_ENTRANCE",t[t.WECHAT_WALLET=1019]="WECHAT_WALLET",t[t.PUBLIC_ACCOUNT_RELATED=1020]="PUBLIC_ACCOUNT_RELATED",t[t.CHAT_TOP=1022]="CHAT_TOP",t[t.DESKTOP=1023]="DESKTOP",t[t.MINIAPP_PROFIE=1024]="MINIAPP_PROFIE",t[t.SCAN_BARCODE=1025]="SCAN_BARCODE",t[t.NEARBY_APP=1026]="NEARBY_APP",t[t.USED_TOP_NAV=1027]="USED_TOP_NAV",t[t.COUPON_PANEL=1028]="COUPON_PANEL",t[t.COUPON_PAGE=1029]="COUPON_PAGE",t[t.TESTING=1030]="TESTING",t[t.PRESS_BARCODE=1031]="PRESS_BARCODE",t[t.ALBUM_BARCODE=1032]="ALBUM_BARCODE",t[t.PAY_SUCCESS=1034]="PAY_SUCCESS",t[t.PUBLIC_ACCOUNT_MENU=1035]="PUBLIC_ACCOUNT_MENU",t[t.THIRD_PARTY_APP_SHARE_CARD=1036]="THIRD_PARTY_APP_SHARE_CARD",t[t.THIRD_PARTY_MINIAPP=1037]="THIRD_PARTY_MINIAPP",t[t.BACK_FROM_MINIAPP=1038]="BACK_FROM_MINIAPP",t[t.TV_SHAKE=1039]="TV_SHAKE",t[t.SEARCH_FRIEND_RESULT=1042]="SEARCH_FRIEND_RESULT",t[t.PUBLIC_ACCOUNT_TEMPLATE_MESSAGE=1043]="PUBLIC_ACCOUNT_TEMPLATE_MESSAGE",t[t.MINIAPP_SHARE_CARD=1044]="MINIAPP_SHARE_CARD",t[t.SCAN_MINIAPP_CODE=1047]="SCAN_MINIAPP_CODE",t[t.PRESS_MINIAPP_CODE=1048]="PRESS_MINIAPP_CODE",t[t.ALBUM_MINIAPP_CODE=1049]="ALBUM_MINIAPP_CODE",t[t.COUPON_STORE_LIST=1052]="COUPON_STORE_LIST",t[t.SEARCH_SEARCH_RESULT=1053]="SEARCH_SEARCH_RESULT",t[t.TOP_SEARCH_SHORTCUT=1054]="TOP_SEARCH_SHORTCUT",t[t.MUSIC_PLAYER=1056]="MUSIC_PLAYER",t[t.BANKCARD_DETAIL=1057]="BANKCARD_DETAIL",t[t.PUBLIC_ACCOUNT_ARTICLE=1058]="PUBLIC_ACCOUNT_ARTICLE",t[t.BIND_INVITATION=1059]="BIND_INVITATION",t[t.WECHAT_WIFI=1064]="WECHAT_WIFI",t[t.PUBLIC_ACCOUNT_ARTICLE_AD=1067]="PUBLIC_ACCOUNT_ARTICLE_AD",t[t.NEARBY_MINIAPP_AD=1068]="NEARBY_MINIAPP_AD",t[t.BANKCARD_LIST=1071]="BANKCARD_LIST",t[t.QRCODE_RECEIVE_MONEY=1072]="QRCODE_RECEIVE_MONEY",t[t.CUSTOMER_MESSAGE=1073]="CUSTOMER_MESSAGE",t[t.PUBLIC_ACCOUNT_MESSAGE=1074]="PUBLIC_ACCOUNT_MESSAGE",t[t.WECHAT_WIFI_SUCCESS=1078]="WECHAT_WIFI_SUCCESS",t[t.PULL_DOWN_PANEL=1089]="PULL_DOWN_PANEL",t[t.LONG_PRESS_HOME=1090]="LONG_PRESS_HOME",t[t.CITY_SERVICE=1092]="CITY_SERVICE"}(e.WechatScene||(e.WechatScene={}))},function(t,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var s=r(1),i=r(6);e.encodeScene=function(t,e){return t+"/"+e},e.decodeScene=function(t){void 0===t&&(t="");var e=decodeURIComponent(t).split("/");return{type:e[0],id:e[1]}},e.getShareImage=function(t,r){return i.default({url:s.default.apiBaseUrl+"/share-image",method:"GET",query:{page:"zhihu/"+t,scene:e.encodeScene(t,r),type:t,id:r,template:(o=Math.floor(4*Math.random())+1,String(o))}}).then(function(t){var e=t.data.image_urls;if(!e||!e.friend)throw new Error("no res data");return e});var o};var o={p:"这篇文章",answer:"这个回答",question:"这个问题"};e.getShareAppMessage=function(t,e,r){void 0===r&&(r={});var s=r.imageUrl,i=(getApp().globalData.userInfo||{}).nickName,n=void 0===i?void 0:i,a=o[t]||"小程序",c={title:"",path:"/zhihu/"+t+"?id="+e+"&isShared=1"};return n&&a&&(c.title=n+" 和你分享了"+a),s&&(c.imageUrl=s),c}},function(t,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=function(t){var e=t.url,r=t.method,s=void 0===r?"GET":r,i=t.data,o=t.query,n=t.header,a=o?function(t){var e=Object.keys(t);return e.length?e.reduce(function(r,s,i){var o=i===e.length-1?"":"&";return""+r+encodeURIComponent(s)+"="+encodeURIComponent(String(t[s]))+o},"?"):""}(o):"";return new Promise(function(t,r){wx.request({url:""+e+a,method:s,data:i,header:n,success:function(e){var s;(s=e.statusCode)>=200&&s<300?t(e):r(e)},fail:function(t){r(t)}})})}},function(t,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var s=r(0);var i=r(1).default.apiHost+"/search/preset_words",o=function(t){return s.default(i+"?w="+encodeURIComponent(JSON.stringify(t)))};function n(t){return wx.setStorageSync("searchPresetWords",JSON.stringify(t)),t}function a(){return JSON.parse(wx.getStorageSync("searchPresetWords"))}function c(t){void 0===t&&(t=[]);var e=t.filter(function(t){return t.valid&&Date.now()/1e3<t.end_ts});if(!e||0===e.length)return"";var r,s,i,o,n=e.find(function(t){return 10===t.weight});return n||e[(r=e.map(function(t){return t.weight}),s=Math.random()*r.reduce(function(t,e){return t+e},0),i=0,o=0,r.some(function(t,e){return(o+=t)>s&&(i=e,!0)}),i)]}e.getLocalPresetWords=a,e.getPresetWord=function(){return new Promise(function(t,e){var r;try{r=a()}catch(t){}var s=c(r||[]);r?s?t(s):o(r.map(function(t){return{id:t.id,valid:t.valid}})).then(function(t){return n(t.data.preset_words.words)}).then(function(e){return t(c(e))}).catch(e):o([]).then(function(t){return n(t.data.preset_words.words)}).then(function(e){return t(c(e))}).catch(e)})},e.markPresetWordInvalid=function(t){var e=a();e.find(function(e){return e.id===t}).valid=0,n(e)},e.selectPresetWords=c},function(t,e,r){"use strict";function s(t){return(s="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i={pre:"div",figure:"div",figcaption:"div",u:"span"},o=function(){for(var t=arguments.length,e=new Array(t),r=0;r<t;r++)e[r]=arguments[r];return e.reduce(function(t,e){var r=s(e);return"string"===r||"number"===r?t.push(e):null!==e&&"object"===r&&t.push.apply(t,function(t){if(Array.isArray(t)){for(var e=0,r=new Array(t.length);e<t.length;e++)r[e]=t[e];return r}return Array.from(t)}(Object.keys(e).filter(function(t){return e[t]}))),t},[]).join(" ")},n=function t(e){return Array.isArray(e)?e.map(t):"object"===s(e)?{name:i[e.tag]||e.tag,attrs:function(t){var e=t.attrs||{},r=o(t.tag,e.class),s={};if("img"===t.tag&&e)if(e.eeimg)s={class:"eeimg eeimg-"+("1"===e.eeimg?"inline":"block")};else{e.src.startsWith("data:image")&&e["data-actualsrc"]&&(s={src:e["data-actualsrc"]});var i=e["data-size"];i&&(s.class=r+" size-"+i)}return Object.assign({},e,{class:r},s)}(e),children:t(e.content)}:"string"==typeof e?e.startsWith("\x3c!--")&&e.endsWith("--\x3e")?{type:"text",text:""}:{type:"text",text:e}:null};e.default=n},function(t,e,r){"use strict";var s=r(63),i=r(72),o=r(74),n={lowerCaseTags:!1,lowerCaseAttributeNames:!1},a=[{name:"!doctype",start:"<",end:">"}];function c(t,e){var r=[],i=[];r.last=function(){return this[this.length-1]};var c=new s({onprocessinginstruction:function(t,s){for(var o=[].concat(a,e.directives||[]),n=r.last(),c=0;c<o.length;c++){var u=o[c],l=u.start+s+u.end;if(t.toLowerCase()===u.name){if(!n)return void i.push(l);n.content||(n.content=[]),n.content.push(l)}}},oncomment:function(t){var e="\x3c!--"+t+"--\x3e",s=r.last();s?(s.content||(s.content=[]),s.content.push(e)):i.push(e)},onopentag:function(t,e){var s={tag:t};Object.keys(e).length&&(s.attrs=function(t){var e={};return Object.keys(t).forEach(function(r){var s={};s[r]=t[r].replace(/&quot;/g,'"'),o(e,s)}),e}(e)),r.push(s)},onclosetag:function(){var t=r.pop();if(r.length){var e=r.last();Array.isArray(e.content)||(e.content=[]),e.content.push(t)}else i.push(t)},ontext:function(t){var e=r.last();e?(e.content||(e.content=[]),e.content.push(t)):i.push(t)}},e||n);return c.write(t),c.end(),i}t.exports=function(){var t;function e(e){return c(e,o(n,t))}return 1===arguments.length&&i(arguments[0])?(t=arguments[0],e):(t=arguments[1],e(arguments[0]))},t.exports.defaultOptions=n,t.exports.defaultDirectives=a},function(t,e,r){"use strict";var s=this&&this.__assign||Object.assign||function(t){for(var e,r=1,s=arguments.length;r<s;r++)for(var i in e=arguments[r])Object.prototype.hasOwnProperty.call(e,i)&&(t[i]=e[i]);return t};Object.defineProperty(e,"__esModule",{value:!0}),e.param=function(t){return void 0===t&&(t={}),Object.keys(t).map(function(e){var r=t[e];return void 0!==r&&null!==r&&e+"="+encodeURIComponent(r)}).filter(Boolean).join("&")},e.getQuery=function(t){if(!t)return{};var e=(t.match(/\?([^#]+)/)||[])[1],r=void 0===e?"":e;return r?r.split("&").reduce(function(t,e){var r=e.split("="),s=r[0],i=r[1];return t[s]=decodeURIComponent(i),t},{}):{}},e.addQuery=function(t,r){void 0===r&&(r={});var i=e.param(s({},e.getQuery(t),r));return i?/\?([^#]+)/.test(t)?t.replace(/\?([^#]+)/,"?"+i):/(#[\w]+)$/.test(t)?t.replace(/(#[\w]+)$/,"?"+i+"$1"):t+"?"+i:t}},,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,function(t,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.once=function(t){var e;return function(){for(var r=[],s=0;s<arguments.length;s++)r[s]=arguments[s];return null!==e&&void 0!==e||(e=t.apply(void 0,r)),e}}},,,,,,,,,,,,,,,,,,function(t,e,r){var s=r(64),i={input:!0,option:!0,optgroup:!0,select:!0,button:!0,datalist:!0,textarea:!0},o={tr:{tr:!0,th:!0,td:!0},th:{th:!0},td:{thead:!0,th:!0,td:!0},body:{head:!0,link:!0,script:!0},li:{li:!0},p:{p:!0},h1:{p:!0},h2:{p:!0},h3:{p:!0},h4:{p:!0},h5:{p:!0},h6:{p:!0},select:i,input:i,output:i,button:i,datalist:i,textarea:i,option:{option:!0},optgroup:{optgroup:!0}},n={__proto__:null,area:!0,base:!0,basefont:!0,br:!0,col:!0,command:!0,embed:!0,frame:!0,hr:!0,img:!0,input:!0,isindex:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0,path:!0,circle:!0,ellipse:!0,line:!0,rect:!0,use:!0,stop:!0,polyline:!0,polygon:!0},a=/\s|\//;function c(t,e){this._options=e||{},this._cbs=t||{},this._tagname="",this._attribname="",this._attribvalue="",this._attribs=null,this._stack=[],this.startIndex=0,this.endIndex=null,this._lowerCaseTagNames="lowerCaseTags"in this._options?!!this._options.lowerCaseTags:!this._options.xmlMode,this._lowerCaseAttributeNames="lowerCaseAttributeNames"in this._options?!!this._options.lowerCaseAttributeNames:!this._options.xmlMode,this._options.Tokenizer&&(s=this._options.Tokenizer),this._tokenizer=new s(this._options,this),this._cbs.onparserinit&&this._cbs.onparserinit(this)}r(70)(c,r(71).EventEmitter),c.prototype._updatePosition=function(t){null===this.endIndex?this._tokenizer._sectionStart<=t?this.startIndex=0:this.startIndex=this._tokenizer._sectionStart-t:this.startIndex=this.endIndex+1,this.endIndex=this._tokenizer.getAbsoluteIndex()},c.prototype.ontext=function(t){this._updatePosition(1),this.endIndex--,this._cbs.ontext&&this._cbs.ontext(t)},c.prototype.onopentagname=function(t){if(this._lowerCaseTagNames&&(t=t.toLowerCase()),this._tagname=t,!this._options.xmlMode&&t in o)for(var e;(e=this._stack[this._stack.length-1])in o[t];this.onclosetag(e));!this._options.xmlMode&&t in n||this._stack.push(t),this._cbs.onopentagname&&this._cbs.onopentagname(t),this._cbs.onopentag&&(this._attribs={})},c.prototype.onopentagend=function(){this._updatePosition(1),this._attribs&&(this._cbs.onopentag&&this._cbs.onopentag(this._tagname,this._attribs),this._attribs=null),!this._options.xmlMode&&this._cbs.onclosetag&&this._tagname in n&&this._cbs.onclosetag(this._tagname),this._tagname=""},c.prototype.onclosetag=function(t){if(this._updatePosition(1),this._lowerCaseTagNames&&(t=t.toLowerCase()),!this._stack.length||t in n&&!this._options.xmlMode)this._options.xmlMode||"br"!==t&&"p"!==t||(this.onopentagname(t),this._closeCurrentTag());else{var e=this._stack.lastIndexOf(t);if(-1!==e)if(this._cbs.onclosetag)for(e=this._stack.length-e;e--;)this._cbs.onclosetag(this._stack.pop());else this._stack.length=e;else"p"!==t||this._options.xmlMode||(this.onopentagname(t),this._closeCurrentTag())}},c.prototype.onselfclosingtag=function(){this._options.xmlMode||this._options.recognizeSelfClosing?this._closeCurrentTag():this.onopentagend()},c.prototype._closeCurrentTag=function(){var t=this._tagname;this.onopentagend(),this._stack[this._stack.length-1]===t&&(this._cbs.onclosetag&&this._cbs.onclosetag(t),this._stack.pop())},c.prototype.onattribname=function(t){this._lowerCaseAttributeNames&&(t=t.toLowerCase()),this._attribname=t},c.prototype.onattribdata=function(t){this._attribvalue+=t},c.prototype.onattribend=function(){this._cbs.onattribute&&this._cbs.onattribute(this._attribname,this._attribvalue),this._attribs&&!Object.prototype.hasOwnProperty.call(this._attribs,this._attribname)&&(this._attribs[this._attribname]=this._attribvalue),this._attribname="",this._attribvalue=""},c.prototype._getInstructionName=function(t){var e=t.search(a),r=e<0?t:t.substr(0,e);return this._lowerCaseTagNames&&(r=r.toLowerCase()),r},c.prototype.ondeclaration=function(t){if(this._cbs.onprocessinginstruction){var e=this._getInstructionName(t);this._cbs.onprocessinginstruction("!"+e,"!"+t)}},c.prototype.onprocessinginstruction=function(t){if(this._cbs.onprocessinginstruction){var e=this._getInstructionName(t);this._cbs.onprocessinginstruction("?"+e,"?"+t)}},c.prototype.oncomment=function(t){this._updatePosition(4),this._cbs.oncomment&&this._cbs.oncomment(t),this._cbs.oncommentend&&this._cbs.oncommentend()},c.prototype.oncdata=function(t){this._updatePosition(1),this._options.xmlMode||this._options.recognizeCDATA?(this._cbs.oncdatastart&&this._cbs.oncdatastart(),this._cbs.ontext&&this._cbs.ontext(t),this._cbs.oncdataend&&this._cbs.oncdataend()):this.oncomment("[CDATA["+t+"]]")},c.prototype.onerror=function(t){this._cbs.onerror&&this._cbs.onerror(t)},c.prototype.onend=function(){if(this._cbs.onclosetag)for(var t=this._stack.length;t>0;this._cbs.onclosetag(this._stack[--t]));this._cbs.onend&&this._cbs.onend()},c.prototype.reset=function(){this._cbs.onreset&&this._cbs.onreset(),this._tokenizer.reset(),this._tagname="",this._attribname="",this._attribs=null,this._stack=[],this._cbs.onparserinit&&this._cbs.onparserinit(this)},c.prototype.parseComplete=function(t){this.reset(),this.end(t)},c.prototype.write=function(t){this._tokenizer.write(t)},c.prototype.end=function(t){this._tokenizer.end(t)},c.prototype.pause=function(){this._tokenizer.pause()},c.prototype.resume=function(){this._tokenizer.resume()},c.prototype.parseChunk=c.prototype.write,c.prototype.done=c.prototype.end,t.exports=c},function(t,e,r){t.exports=bt;var s,i,o=r(65),n=r(67),a=r(68),c=r(69),u=0,l=u++,h=u++,p=u++,_=u++,f=u++,d=u++,g=u++,m=u++,b=u++,y=u++,S=u++,v=u++,E=u++,A=u++,w=u++,x=u++,C=u++,T=u++,q=u++,N=u++,L=u++,I=u++,O=u++,D=u++,R=u++,P=u++,k=u++,U=u++,B=u++,M=u++,V=u++,G=u++,H=u++,j=u++,z=u++,W=u++,F=u++,Y=u++,Q=u++,K=u++,Z=u++,J=u++,X=u++,$=u++,tt=u++,et=u++,rt=u++,st=u++,it=u++,ot=u++,nt=u++,at=u++,ct=u++,ut=u++,lt=u++,ht=0,pt=ht++,_t=ht++,ft=ht++;function dt(t){return" "===t||"\n"===t||"\t"===t||"\f"===t||"\r"===t}function gt(t,e,r){var s=t.toLowerCase();return t===s?function(t){t===s?this._state=e:(this._state=r,this._index--)}:function(i){i===s||i===t?this._state=e:(this._state=r,this._index--)}}function mt(t,e){var r=t.toLowerCase();return function(s){s===r||s===t?this._state=e:(this._state=p,this._index--)}}function bt(t,e){this._state=l,this._buffer="",this._sectionStart=0,this._index=0,this._bufferOffset=0,this._baseState=l,this._special=pt,this._cbs=e,this._running=!0,this._ended=!1,this._xmlMode=!(!t||!t.xmlMode),this._decodeEntities=!(!t||!t.decodeEntities)}bt.prototype._stateText=function(t){"<"===t?(this._index>this._sectionStart&&this._cbs.ontext(this._getSection()),this._state=h,this._sectionStart=this._index):this._decodeEntities&&this._special===pt&&"&"===t&&(this._index>this._sectionStart&&this._cbs.ontext(this._getSection()),this._baseState=l,this._state=nt,this._sectionStart=this._index)},bt.prototype._stateBeforeTagName=function(t){"/"===t?this._state=f:"<"===t?(this._cbs.ontext(this._getSection()),this._sectionStart=this._index):">"===t||this._special!==pt||dt(t)?this._state=l:"!"===t?(this._state=w,this._sectionStart=this._index+1):"?"===t?(this._state=C,this._sectionStart=this._index+1):(this._state=this._xmlMode||"s"!==t&&"S"!==t?p:V,this._sectionStart=this._index)},bt.prototype._stateInTagName=function(t){("/"===t||">"===t||dt(t))&&(this._emitToken("onopentagname"),this._state=m,this._index--)},bt.prototype._stateBeforeCloseingTagName=function(t){dt(t)||(">"===t?this._state=l:this._special!==pt?"s"===t||"S"===t?this._state=G:(this._state=l,this._index--):(this._state=d,this._sectionStart=this._index))},bt.prototype._stateInCloseingTagName=function(t){(">"===t||dt(t))&&(this._emitToken("onclosetag"),this._state=g,this._index--)},bt.prototype._stateAfterCloseingTagName=function(t){">"===t&&(this._state=l,this._sectionStart=this._index+1)},bt.prototype._stateBeforeAttributeName=function(t){">"===t?(this._cbs.onopentagend(),this._state=l,this._sectionStart=this._index+1):"/"===t?this._state=_:dt(t)||(this._state=b,this._sectionStart=this._index)},bt.prototype._stateInSelfClosingTag=function(t){">"===t?(this._cbs.onselfclosingtag(),this._state=l,this._sectionStart=this._index+1):dt(t)||(this._state=m,this._index--)},bt.prototype._stateInAttributeName=function(t){("="===t||"/"===t||">"===t||dt(t))&&(this._cbs.onattribname(this._getSection()),this._sectionStart=-1,this._state=y,this._index--)},bt.prototype._stateAfterAttributeName=function(t){"="===t?this._state=S:"/"===t||">"===t?(this._cbs.onattribend(),this._state=m,this._index--):dt(t)||(this._cbs.onattribend(),this._state=b,this._sectionStart=this._index)},bt.prototype._stateBeforeAttributeValue=function(t){'"'===t?(this._state=v,this._sectionStart=this._index+1):"'"===t?(this._state=E,this._sectionStart=this._index+1):dt(t)||(this._state=A,this._sectionStart=this._index,this._index--)},bt.prototype._stateInAttributeValueDoubleQuotes=function(t){'"'===t?(this._emitToken("onattribdata"),this._cbs.onattribend(),this._state=m):this._decodeEntities&&"&"===t&&(this._emitToken("onattribdata"),this._baseState=this._state,this._state=nt,this._sectionStart=this._index)},bt.prototype._stateInAttributeValueSingleQuotes=function(t){"'"===t?(this._emitToken("onattribdata"),this._cbs.onattribend(),this._state=m):this._decodeEntities&&"&"===t&&(this._emitToken("onattribdata"),this._baseState=this._state,this._state=nt,this._sectionStart=this._index)},bt.prototype._stateInAttributeValueNoQuotes=function(t){dt(t)||">"===t?(this._emitToken("onattribdata"),this._cbs.onattribend(),this._state=m,this._index--):this._decodeEntities&&"&"===t&&(this._emitToken("onattribdata"),this._baseState=this._state,this._state=nt,this._sectionStart=this._index)},bt.prototype._stateBeforeDeclaration=function(t){this._state="["===t?I:"-"===t?T:x},bt.prototype._stateInDeclaration=function(t){">"===t&&(this._cbs.ondeclaration(this._getSection()),this._state=l,this._sectionStart=this._index+1)},bt.prototype._stateInProcessingInstruction=function(t){">"===t&&(this._cbs.onprocessinginstruction(this._getSection()),this._state=l,this._sectionStart=this._index+1)},bt.prototype._stateBeforeComment=function(t){"-"===t?(this._state=q,this._sectionStart=this._index+1):this._state=x},bt.prototype._stateInComment=function(t){"-"===t&&(this._state=N)},bt.prototype._stateAfterComment1=function(t){this._state="-"===t?L:q},bt.prototype._stateAfterComment2=function(t){">"===t?(this._cbs.oncomment(this._buffer.substring(this._sectionStart,this._index-2)),this._state=l,this._sectionStart=this._index+1):"-"!==t&&(this._state=q)},bt.prototype._stateBeforeCdata1=gt("C",O,x),bt.prototype._stateBeforeCdata2=gt("D",D,x),bt.prototype._stateBeforeCdata3=gt("A",R,x),bt.prototype._stateBeforeCdata4=gt("T",P,x),bt.prototype._stateBeforeCdata5=gt("A",k,x),bt.prototype._stateBeforeCdata6=function(t){"["===t?(this._state=U,this._sectionStart=this._index+1):(this._state=x,this._index--)},bt.prototype._stateInCdata=function(t){"]"===t&&(this._state=B)},bt.prototype._stateAfterCdata1=(s="]",i=M,function(t){t===s&&(this._state=i)}),bt.prototype._stateAfterCdata2=function(t){">"===t?(this._cbs.oncdata(this._buffer.substring(this._sectionStart,this._index-2)),this._state=l,this._sectionStart=this._index+1):"]"!==t&&(this._state=U)},bt.prototype._stateBeforeSpecial=function(t){"c"===t||"C"===t?this._state=H:"t"===t||"T"===t?this._state=X:(this._state=p,this._index--)},bt.prototype._stateBeforeSpecialEnd=function(t){this._special!==_t||"c"!==t&&"C"!==t?this._special!==ft||"t"!==t&&"T"!==t?this._state=l:this._state=rt:this._state=Y},bt.prototype._stateBeforeScript1=mt("R",j),bt.prototype._stateBeforeScript2=mt("I",z),bt.prototype._stateBeforeScript3=mt("P",W),bt.prototype._stateBeforeScript4=mt("T",F),bt.prototype._stateBeforeScript5=function(t){("/"===t||">"===t||dt(t))&&(this._special=_t),this._state=p,this._index--},bt.prototype._stateAfterScript1=gt("R",Q,l),bt.prototype._stateAfterScript2=gt("I",K,l),bt.prototype._stateAfterScript3=gt("P",Z,l),bt.prototype._stateAfterScript4=gt("T",J,l),bt.prototype._stateAfterScript5=function(t){">"===t||dt(t)?(this._special=pt,this._state=d,this._sectionStart=this._index-6,this._index--):this._state=l},bt.prototype._stateBeforeStyle1=mt("Y",$),bt.prototype._stateBeforeStyle2=mt("L",tt),bt.prototype._stateBeforeStyle3=mt("E",et),bt.prototype._stateBeforeStyle4=function(t){("/"===t||">"===t||dt(t))&&(this._special=ft),this._state=p,this._index--},bt.prototype._stateAfterStyle1=gt("Y",st,l),bt.prototype._stateAfterStyle2=gt("L",it,l),bt.prototype._stateAfterStyle3=gt("E",ot,l),bt.prototype._stateAfterStyle4=function(t){">"===t||dt(t)?(this._special=pt,this._state=d,this._sectionStart=this._index-5,this._index--):this._state=l},bt.prototype._stateBeforeEntity=gt("#",at,ct),bt.prototype._stateBeforeNumericEntity=gt("X",lt,ut),bt.prototype._parseNamedEntityStrict=function(){if(this._sectionStart+1<this._index){var t=this._buffer.substring(this._sectionStart+1,this._index),e=this._xmlMode?c:n;e.hasOwnProperty(t)&&(this._emitPartial(e[t]),this._sectionStart=this._index+1)}},bt.prototype._parseLegacyEntity=function(){var t=this._sectionStart+1,e=this._index-t;for(e>6&&(e=6);e>=2;){var r=this._buffer.substr(t,e);if(a.hasOwnProperty(r))return this._emitPartial(a[r]),void(this._sectionStart+=e+1);e--}},bt.prototype._stateInNamedEntity=function(t){";"===t?(this._parseNamedEntityStrict(),this._sectionStart+1<this._index&&!this._xmlMode&&this._parseLegacyEntity(),this._state=this._baseState):(t<"a"||t>"z")&&(t<"A"||t>"Z")&&(t<"0"||t>"9")&&(this._xmlMode||this._sectionStart+1===this._index||(this._baseState!==l?"="!==t&&this._parseNamedEntityStrict():this._parseLegacyEntity()),this._state=this._baseState,this._index--)},bt.prototype._decodeNumericEntity=function(t,e){var r=this._sectionStart+t;if(r!==this._index){var s=this._buffer.substring(r,this._index),i=parseInt(s,e);this._emitPartial(o(i)),this._sectionStart=this._index}else this._sectionStart--;this._state=this._baseState},bt.prototype._stateInNumericEntity=function(t){";"===t?(this._decodeNumericEntity(2,10),this._sectionStart++):(t<"0"||t>"9")&&(this._xmlMode?this._state=this._baseState:this._decodeNumericEntity(2,10),this._index--)},bt.prototype._stateInHexEntity=function(t){";"===t?(this._decodeNumericEntity(3,16),this._sectionStart++):(t<"a"||t>"f")&&(t<"A"||t>"F")&&(t<"0"||t>"9")&&(this._xmlMode?this._state=this._baseState:this._decodeNumericEntity(3,16),this._index--)},bt.prototype._cleanup=function(){this._sectionStart<0?(this._buffer="",this._bufferOffset+=this._index,this._index=0):this._running&&(this._state===l?(this._sectionStart!==this._index&&this._cbs.ontext(this._buffer.substr(this._sectionStart)),this._buffer="",this._bufferOffset+=this._index,this._index=0):this._sectionStart===this._index?(this._buffer="",this._bufferOffset+=this._index,this._index=0):(this._buffer=this._buffer.substr(this._sectionStart),this._index-=this._sectionStart,this._bufferOffset+=this._sectionStart),this._sectionStart=0)},bt.prototype.write=function(t){this._ended&&this._cbs.onerror(Error(".write() after done!")),this._buffer+=t,this._parse()},bt.prototype._parse=function(){for(;this._index<this._buffer.length&&this._running;){var t=this._buffer.charAt(this._index);this._state===l?this._stateText(t):this._state===h?this._stateBeforeTagName(t):this._state===p?this._stateInTagName(t):this._state===f?this._stateBeforeCloseingTagName(t):this._state===d?this._stateInCloseingTagName(t):this._state===g?this._stateAfterCloseingTagName(t):this._state===_?this._stateInSelfClosingTag(t):this._state===m?this._stateBeforeAttributeName(t):this._state===b?this._stateInAttributeName(t):this._state===y?this._stateAfterAttributeName(t):this._state===S?this._stateBeforeAttributeValue(t):this._state===v?this._stateInAttributeValueDoubleQuotes(t):this._state===E?this._stateInAttributeValueSingleQuotes(t):this._state===A?this._stateInAttributeValueNoQuotes(t):this._state===w?this._stateBeforeDeclaration(t):this._state===x?this._stateInDeclaration(t):this._state===C?this._stateInProcessingInstruction(t):this._state===T?this._stateBeforeComment(t):this._state===q?this._stateInComment(t):this._state===N?this._stateAfterComment1(t):this._state===L?this._stateAfterComment2(t):this._state===I?this._stateBeforeCdata1(t):this._state===O?this._stateBeforeCdata2(t):this._state===D?this._stateBeforeCdata3(t):this._state===R?this._stateBeforeCdata4(t):this._state===P?this._stateBeforeCdata5(t):this._state===k?this._stateBeforeCdata6(t):this._state===U?this._stateInCdata(t):this._state===B?this._stateAfterCdata1(t):this._state===M?this._stateAfterCdata2(t):this._state===V?this._stateBeforeSpecial(t):this._state===G?this._stateBeforeSpecialEnd(t):this._state===H?this._stateBeforeScript1(t):this._state===j?this._stateBeforeScript2(t):this._state===z?this._stateBeforeScript3(t):this._state===W?this._stateBeforeScript4(t):this._state===F?this._stateBeforeScript5(t):this._state===Y?this._stateAfterScript1(t):this._state===Q?this._stateAfterScript2(t):this._state===K?this._stateAfterScript3(t):this._state===Z?this._stateAfterScript4(t):this._state===J?this._stateAfterScript5(t):this._state===X?this._stateBeforeStyle1(t):this._state===$?this._stateBeforeStyle2(t):this._state===tt?this._stateBeforeStyle3(t):this._state===et?this._stateBeforeStyle4(t):this._state===rt?this._stateAfterStyle1(t):this._state===st?this._stateAfterStyle2(t):this._state===it?this._stateAfterStyle3(t):this._state===ot?this._stateAfterStyle4(t):this._state===nt?this._stateBeforeEntity(t):this._state===at?this._stateBeforeNumericEntity(t):this._state===ct?this._stateInNamedEntity(t):this._state===ut?this._stateInNumericEntity(t):this._state===lt?this._stateInHexEntity(t):this._cbs.onerror(Error("unknown _state"),this._state),this._index++}this._cleanup()},bt.prototype.pause=function(){this._running=!1},bt.prototype.resume=function(){this._running=!0,this._index<this._buffer.length&&this._parse(),this._ended&&this._finish()},bt.prototype.end=function(t){this._ended&&this._cbs.onerror(Error(".end() after done!")),t&&this.write(t),this._ended=!0,this._running&&this._finish()},bt.prototype._finish=function(){this._sectionStart<this._index&&this._handleTrailingData(),this._cbs.onend()},bt.prototype._handleTrailingData=function(){var t=this._buffer.substr(this._sectionStart);this._state===U||this._state===B||this._state===M?this._cbs.oncdata(t):this._state===q||this._state===N||this._state===L?this._cbs.oncomment(t):this._state!==ct||this._xmlMode?this._state!==ut||this._xmlMode?this._state!==lt||this._xmlMode?this._state!==p&&this._state!==m&&this._state!==S&&this._state!==y&&this._state!==b&&this._state!==E&&this._state!==v&&this._state!==A&&this._state!==d&&this._cbs.ontext(t):(this._decodeNumericEntity(3,16),this._sectionStart<this._index&&(this._state=this._baseState,this._handleTrailingData())):(this._decodeNumericEntity(2,10),this._sectionStart<this._index&&(this._state=this._baseState,this._handleTrailingData())):(this._parseLegacyEntity(),this._sectionStart<this._index&&(this._state=this._baseState,this._handleTrailingData()))},bt.prototype.reset=function(){bt.call(this,{xmlMode:this._xmlMode,decodeEntities:this._decodeEntities},this._cbs)},bt.prototype.getAbsoluteIndex=function(){return this._bufferOffset+this._index},bt.prototype._getSection=function(){return this._buffer.substring(this._sectionStart,this._index)},bt.prototype._emitToken=function(t){this._cbs[t](this._getSection()),this._sectionStart=-1},bt.prototype._emitPartial=function(t){this._baseState!==l?this._cbs.onattribdata(t):this._cbs.ontext(t)}},function(t,e,r){var s=r(66);t.exports=function(t){if(t>=55296&&t<=57343||t>1114111)return"�";t in s&&(t=s[t]);var e="";t>65535&&(t-=65536,e+=String.fromCharCode(t>>>10&1023|55296),t=56320|1023&t);return e+=String.fromCharCode(t)}},function(t,e){t.exports={0:65533,128:8364,130:8218,131:402,132:8222,133:8230,134:8224,135:8225,136:710,137:8240,138:352,139:8249,140:338,142:381,145:8216,146:8217,147:8220,148:8221,149:8226,150:8211,151:8212,152:732,153:8482,154:353,155:8250,156:339,158:382,159:376}},function(t,e){t.exports={Aacute:"Á",aacute:"á",Abreve:"Ă",abreve:"ă",ac:"∾",acd:"∿",acE:"∾̳",Acirc:"Â",acirc:"â",acute:"´",Acy:"А",acy:"а",AElig:"Æ",aelig:"æ",af:"⁡",Afr:"𝔄",afr:"𝔞",Agrave:"À",agrave:"à",alefsym:"ℵ",aleph:"ℵ",Alpha:"Α",alpha:"α",Amacr:"Ā",amacr:"ā",amalg:"⨿",amp:"&",AMP:"&",andand:"⩕",And:"⩓",and:"∧",andd:"⩜",andslope:"⩘",andv:"⩚",ang:"∠",ange:"⦤",angle:"∠",angmsdaa:"⦨",angmsdab:"⦩",angmsdac:"⦪",angmsdad:"⦫",angmsdae:"⦬",angmsdaf:"⦭",angmsdag:"⦮",angmsdah:"⦯",angmsd:"∡",angrt:"∟",angrtvb:"⊾",angrtvbd:"⦝",angsph:"∢",angst:"Å",angzarr:"⍼",Aogon:"Ą",aogon:"ą",Aopf:"𝔸",aopf:"𝕒",apacir:"⩯",ap:"≈",apE:"⩰",ape:"≊",apid:"≋",apos:"'",ApplyFunction:"⁡",approx:"≈",approxeq:"≊",Aring:"Å",aring:"å",Ascr:"𝒜",ascr:"𝒶",Assign:"≔",ast:"*",asymp:"≈",asympeq:"≍",Atilde:"Ã",atilde:"ã",Auml:"Ä",auml:"ä",awconint:"∳",awint:"⨑",backcong:"≌",backepsilon:"϶",backprime:"‵",backsim:"∽",backsimeq:"⋍",Backslash:"∖",Barv:"⫧",barvee:"⊽",barwed:"⌅",Barwed:"⌆",barwedge:"⌅",bbrk:"⎵",bbrktbrk:"⎶",bcong:"≌",Bcy:"Б",bcy:"б",bdquo:"„",becaus:"∵",because:"∵",Because:"∵",bemptyv:"⦰",bepsi:"϶",bernou:"ℬ",Bernoullis:"ℬ",Beta:"Β",beta:"β",beth:"ℶ",between:"≬",Bfr:"𝔅",bfr:"𝔟",bigcap:"⋂",bigcirc:"◯",bigcup:"⋃",bigodot:"⨀",bigoplus:"⨁",bigotimes:"⨂",bigsqcup:"⨆",bigstar:"★",bigtriangledown:"▽",bigtriangleup:"△",biguplus:"⨄",bigvee:"⋁",bigwedge:"⋀",bkarow:"⤍",blacklozenge:"⧫",blacksquare:"▪",blacktriangle:"▴",blacktriangledown:"▾",blacktriangleleft:"◂",blacktriangleright:"▸",blank:"␣",blk12:"▒",blk14:"░",blk34:"▓",block:"█",bne:"=⃥",bnequiv:"≡⃥",bNot:"⫭",bnot:"⌐",Bopf:"𝔹",bopf:"𝕓",bot:"⊥",bottom:"⊥",bowtie:"⋈",boxbox:"⧉",boxdl:"┐",boxdL:"╕",boxDl:"╖",boxDL:"╗",boxdr:"┌",boxdR:"╒",boxDr:"╓",boxDR:"╔",boxh:"─",boxH:"═",boxhd:"┬",boxHd:"╤",boxhD:"╥",boxHD:"╦",boxhu:"┴",boxHu:"╧",boxhU:"╨",boxHU:"╩",boxminus:"⊟",boxplus:"⊞",boxtimes:"⊠",boxul:"┘",boxuL:"╛",boxUl:"╜",boxUL:"╝",boxur:"└",boxuR:"╘",boxUr:"╙",boxUR:"╚",boxv:"│",boxV:"║",boxvh:"┼",boxvH:"╪",boxVh:"╫",boxVH:"╬",boxvl:"┤",boxvL:"╡",boxVl:"╢",boxVL:"╣",boxvr:"├",boxvR:"╞",boxVr:"╟",boxVR:"╠",bprime:"‵",breve:"˘",Breve:"˘",brvbar:"¦",bscr:"𝒷",Bscr:"ℬ",bsemi:"⁏",bsim:"∽",bsime:"⋍",bsolb:"⧅",bsol:"\\",bsolhsub:"⟈",bull:"•",bullet:"•",bump:"≎",bumpE:"⪮",bumpe:"≏",Bumpeq:"≎",bumpeq:"≏",Cacute:"Ć",cacute:"ć",capand:"⩄",capbrcup:"⩉",capcap:"⩋",cap:"∩",Cap:"⋒",capcup:"⩇",capdot:"⩀",CapitalDifferentialD:"ⅅ",caps:"∩︀",caret:"⁁",caron:"ˇ",Cayleys:"ℭ",ccaps:"⩍",Ccaron:"Č",ccaron:"č",Ccedil:"Ç",ccedil:"ç",Ccirc:"Ĉ",ccirc:"ĉ",Cconint:"∰",ccups:"⩌",ccupssm:"⩐",Cdot:"Ċ",cdot:"ċ",cedil:"¸",Cedilla:"¸",cemptyv:"⦲",cent:"¢",centerdot:"·",CenterDot:"·",cfr:"𝔠",Cfr:"ℭ",CHcy:"Ч",chcy:"ч",check:"✓",checkmark:"✓",Chi:"Χ",chi:"χ",circ:"ˆ",circeq:"≗",circlearrowleft:"↺",circlearrowright:"↻",circledast:"⊛",circledcirc:"⊚",circleddash:"⊝",CircleDot:"⊙",circledR:"®",circledS:"Ⓢ",CircleMinus:"⊖",CirclePlus:"⊕",CircleTimes:"⊗",cir:"○",cirE:"⧃",cire:"≗",cirfnint:"⨐",cirmid:"⫯",cirscir:"⧂",ClockwiseContourIntegral:"∲",CloseCurlyDoubleQuote:"”",CloseCurlyQuote:"’",clubs:"♣",clubsuit:"♣",colon:":",Colon:"∷",Colone:"⩴",colone:"≔",coloneq:"≔",comma:",",commat:"@",comp:"∁",compfn:"∘",complement:"∁",complexes:"ℂ",cong:"≅",congdot:"⩭",Congruent:"≡",conint:"∮",Conint:"∯",ContourIntegral:"∮",copf:"𝕔",Copf:"ℂ",coprod:"∐",Coproduct:"∐",copy:"©",COPY:"©",copysr:"℗",CounterClockwiseContourIntegral:"∳",crarr:"↵",cross:"✗",Cross:"⨯",Cscr:"𝒞",cscr:"𝒸",csub:"⫏",csube:"⫑",csup:"⫐",csupe:"⫒",ctdot:"⋯",cudarrl:"⤸",cudarrr:"⤵",cuepr:"⋞",cuesc:"⋟",cularr:"↶",cularrp:"⤽",cupbrcap:"⩈",cupcap:"⩆",CupCap:"≍",cup:"∪",Cup:"⋓",cupcup:"⩊",cupdot:"⊍",cupor:"⩅",cups:"∪︀",curarr:"↷",curarrm:"⤼",curlyeqprec:"⋞",curlyeqsucc:"⋟",curlyvee:"⋎",curlywedge:"⋏",curren:"¤",curvearrowleft:"↶",curvearrowright:"↷",cuvee:"⋎",cuwed:"⋏",cwconint:"∲",cwint:"∱",cylcty:"⌭",dagger:"†",Dagger:"‡",daleth:"ℸ",darr:"↓",Darr:"↡",dArr:"⇓",dash:"‐",Dashv:"⫤",dashv:"⊣",dbkarow:"⤏",dblac:"˝",Dcaron:"Ď",dcaron:"ď",Dcy:"Д",dcy:"д",ddagger:"‡",ddarr:"⇊",DD:"ⅅ",dd:"ⅆ",DDotrahd:"⤑",ddotseq:"⩷",deg:"°",Del:"∇",Delta:"Δ",delta:"δ",demptyv:"⦱",dfisht:"⥿",Dfr:"𝔇",dfr:"𝔡",dHar:"⥥",dharl:"⇃",dharr:"⇂",DiacriticalAcute:"´",DiacriticalDot:"˙",DiacriticalDoubleAcute:"˝",DiacriticalGrave:"`",DiacriticalTilde:"˜",diam:"⋄",diamond:"⋄",Diamond:"⋄",diamondsuit:"♦",diams:"♦",die:"¨",DifferentialD:"ⅆ",digamma:"ϝ",disin:"⋲",div:"÷",divide:"÷",divideontimes:"⋇",divonx:"⋇",DJcy:"Ђ",djcy:"ђ",dlcorn:"⌞",dlcrop:"⌍",dollar:"$",Dopf:"𝔻",dopf:"𝕕",Dot:"¨",dot:"˙",DotDot:"⃜",doteq:"≐",doteqdot:"≑",DotEqual:"≐",dotminus:"∸",dotplus:"∔",dotsquare:"⊡",doublebarwedge:"⌆",DoubleContourIntegral:"∯",DoubleDot:"¨",DoubleDownArrow:"⇓",DoubleLeftArrow:"⇐",DoubleLeftRightArrow:"⇔",DoubleLeftTee:"⫤",DoubleLongLeftArrow:"⟸",DoubleLongLeftRightArrow:"⟺",DoubleLongRightArrow:"⟹",DoubleRightArrow:"⇒",DoubleRightTee:"⊨",DoubleUpArrow:"⇑",DoubleUpDownArrow:"⇕",DoubleVerticalBar:"∥",DownArrowBar:"⤓",downarrow:"↓",DownArrow:"↓",Downarrow:"⇓",DownArrowUpArrow:"⇵",DownBreve:"̑",downdownarrows:"⇊",downharpoonleft:"⇃",downharpoonright:"⇂",DownLeftRightVector:"⥐",DownLeftTeeVector:"⥞",DownLeftVectorBar:"⥖",DownLeftVector:"↽",DownRightTeeVector:"⥟",DownRightVectorBar:"⥗",DownRightVector:"⇁",DownTeeArrow:"↧",DownTee:"⊤",drbkarow:"⤐",drcorn:"⌟",drcrop:"⌌",Dscr:"𝒟",dscr:"𝒹",DScy:"Ѕ",dscy:"ѕ",dsol:"⧶",Dstrok:"Đ",dstrok:"đ",dtdot:"⋱",dtri:"▿",dtrif:"▾",duarr:"⇵",duhar:"⥯",dwangle:"⦦",DZcy:"Џ",dzcy:"џ",dzigrarr:"⟿",Eacute:"É",eacute:"é",easter:"⩮",Ecaron:"Ě",ecaron:"ě",Ecirc:"Ê",ecirc:"ê",ecir:"≖",ecolon:"≕",Ecy:"Э",ecy:"э",eDDot:"⩷",Edot:"Ė",edot:"ė",eDot:"≑",ee:"ⅇ",efDot:"≒",Efr:"𝔈",efr:"𝔢",eg:"⪚",Egrave:"È",egrave:"è",egs:"⪖",egsdot:"⪘",el:"⪙",Element:"∈",elinters:"⏧",ell:"ℓ",els:"⪕",elsdot:"⪗",Emacr:"Ē",emacr:"ē",empty:"∅",emptyset:"∅",EmptySmallSquare:"◻",emptyv:"∅",EmptyVerySmallSquare:"▫",emsp13:" ",emsp14:" ",emsp:" ",ENG:"Ŋ",eng:"ŋ",ensp:" ",Eogon:"Ę",eogon:"ę",Eopf:"𝔼",eopf:"𝕖",epar:"⋕",eparsl:"⧣",eplus:"⩱",epsi:"ε",Epsilon:"Ε",epsilon:"ε",epsiv:"ϵ",eqcirc:"≖",eqcolon:"≕",eqsim:"≂",eqslantgtr:"⪖",eqslantless:"⪕",Equal:"⩵",equals:"=",EqualTilde:"≂",equest:"≟",Equilibrium:"⇌",equiv:"≡",equivDD:"⩸",eqvparsl:"⧥",erarr:"⥱",erDot:"≓",escr:"ℯ",Escr:"ℰ",esdot:"≐",Esim:"⩳",esim:"≂",Eta:"Η",eta:"η",ETH:"Ð",eth:"ð",Euml:"Ë",euml:"ë",euro:"€",excl:"!",exist:"∃",Exists:"∃",expectation:"ℰ",exponentiale:"ⅇ",ExponentialE:"ⅇ",fallingdotseq:"≒",Fcy:"Ф",fcy:"ф",female:"♀",ffilig:"ﬃ",fflig:"ﬀ",ffllig:"ﬄ",Ffr:"𝔉",ffr:"𝔣",filig:"ﬁ",FilledSmallSquare:"◼",FilledVerySmallSquare:"▪",fjlig:"fj",flat:"♭",fllig:"ﬂ",fltns:"▱",fnof:"ƒ",Fopf:"𝔽",fopf:"𝕗",forall:"∀",ForAll:"∀",fork:"⋔",forkv:"⫙",Fouriertrf:"ℱ",fpartint:"⨍",frac12:"½",frac13:"⅓",frac14:"¼",frac15:"⅕",frac16:"⅙",frac18:"⅛",frac23:"⅔",frac25:"⅖",frac34:"¾",frac35:"⅗",frac38:"⅜",frac45:"⅘",frac56:"⅚",frac58:"⅝",frac78:"⅞",frasl:"⁄",frown:"⌢",fscr:"𝒻",Fscr:"ℱ",gacute:"ǵ",Gamma:"Γ",gamma:"γ",Gammad:"Ϝ",gammad:"ϝ",gap:"⪆",Gbreve:"Ğ",gbreve:"ğ",Gcedil:"Ģ",Gcirc:"Ĝ",gcirc:"ĝ",Gcy:"Г",gcy:"г",Gdot:"Ġ",gdot:"ġ",ge:"≥",gE:"≧",gEl:"⪌",gel:"⋛",geq:"≥",geqq:"≧",geqslant:"⩾",gescc:"⪩",ges:"⩾",gesdot:"⪀",gesdoto:"⪂",gesdotol:"⪄",gesl:"⋛︀",gesles:"⪔",Gfr:"𝔊",gfr:"𝔤",gg:"≫",Gg:"⋙",ggg:"⋙",gimel:"ℷ",GJcy:"Ѓ",gjcy:"ѓ",gla:"⪥",gl:"≷",glE:"⪒",glj:"⪤",gnap:"⪊",gnapprox:"⪊",gne:"⪈",gnE:"≩",gneq:"⪈",gneqq:"≩",gnsim:"⋧",Gopf:"𝔾",gopf:"𝕘",grave:"`",GreaterEqual:"≥",GreaterEqualLess:"⋛",GreaterFullEqual:"≧",GreaterGreater:"⪢",GreaterLess:"≷",GreaterSlantEqual:"⩾",GreaterTilde:"≳",Gscr:"𝒢",gscr:"ℊ",gsim:"≳",gsime:"⪎",gsiml:"⪐",gtcc:"⪧",gtcir:"⩺",gt:">",GT:">",Gt:"≫",gtdot:"⋗",gtlPar:"⦕",gtquest:"⩼",gtrapprox:"⪆",gtrarr:"⥸",gtrdot:"⋗",gtreqless:"⋛",gtreqqless:"⪌",gtrless:"≷",gtrsim:"≳",gvertneqq:"≩︀",gvnE:"≩︀",Hacek:"ˇ",hairsp:" ",half:"½",hamilt:"ℋ",HARDcy:"Ъ",hardcy:"ъ",harrcir:"⥈",harr:"↔",hArr:"⇔",harrw:"↭",Hat:"^",hbar:"ℏ",Hcirc:"Ĥ",hcirc:"ĥ",hearts:"♥",heartsuit:"♥",hellip:"…",hercon:"⊹",hfr:"𝔥",Hfr:"ℌ",HilbertSpace:"ℋ",hksearow:"⤥",hkswarow:"⤦",hoarr:"⇿",homtht:"∻",hookleftarrow:"↩",hookrightarrow:"↪",hopf:"𝕙",Hopf:"ℍ",horbar:"―",HorizontalLine:"─",hscr:"𝒽",Hscr:"ℋ",hslash:"ℏ",Hstrok:"Ħ",hstrok:"ħ",HumpDownHump:"≎",HumpEqual:"≏",hybull:"⁃",hyphen:"‐",Iacute:"Í",iacute:"í",ic:"⁣",Icirc:"Î",icirc:"î",Icy:"И",icy:"и",Idot:"İ",IEcy:"Е",iecy:"е",iexcl:"¡",iff:"⇔",ifr:"𝔦",Ifr:"ℑ",Igrave:"Ì",igrave:"ì",ii:"ⅈ",iiiint:"⨌",iiint:"∭",iinfin:"⧜",iiota:"℩",IJlig:"Ĳ",ijlig:"ĳ",Imacr:"Ī",imacr:"ī",image:"ℑ",ImaginaryI:"ⅈ",imagline:"ℐ",imagpart:"ℑ",imath:"ı",Im:"ℑ",imof:"⊷",imped:"Ƶ",Implies:"⇒",incare:"℅",in:"∈",infin:"∞",infintie:"⧝",inodot:"ı",intcal:"⊺",int:"∫",Int:"∬",integers:"ℤ",Integral:"∫",intercal:"⊺",Intersection:"⋂",intlarhk:"⨗",intprod:"⨼",InvisibleComma:"⁣",InvisibleTimes:"⁢",IOcy:"Ё",iocy:"ё",Iogon:"Į",iogon:"į",Iopf:"𝕀",iopf:"𝕚",Iota:"Ι",iota:"ι",iprod:"⨼",iquest:"¿",iscr:"𝒾",Iscr:"ℐ",isin:"∈",isindot:"⋵",isinE:"⋹",isins:"⋴",isinsv:"⋳",isinv:"∈",it:"⁢",Itilde:"Ĩ",itilde:"ĩ",Iukcy:"І",iukcy:"і",Iuml:"Ï",iuml:"ï",Jcirc:"Ĵ",jcirc:"ĵ",Jcy:"Й",jcy:"й",Jfr:"𝔍",jfr:"𝔧",jmath:"ȷ",Jopf:"𝕁",jopf:"𝕛",Jscr:"𝒥",jscr:"𝒿",Jsercy:"Ј",jsercy:"ј",Jukcy:"Є",jukcy:"є",Kappa:"Κ",kappa:"κ",kappav:"ϰ",Kcedil:"Ķ",kcedil:"ķ",Kcy:"К",kcy:"к",Kfr:"𝔎",kfr:"𝔨",kgreen:"ĸ",KHcy:"Х",khcy:"х",KJcy:"Ќ",kjcy:"ќ",Kopf:"𝕂",kopf:"𝕜",Kscr:"𝒦",kscr:"𝓀",lAarr:"⇚",Lacute:"Ĺ",lacute:"ĺ",laemptyv:"⦴",lagran:"ℒ",Lambda:"Λ",lambda:"λ",lang:"⟨",Lang:"⟪",langd:"⦑",langle:"⟨",lap:"⪅",Laplacetrf:"ℒ",laquo:"«",larrb:"⇤",larrbfs:"⤟",larr:"←",Larr:"↞",lArr:"⇐",larrfs:"⤝",larrhk:"↩",larrlp:"↫",larrpl:"⤹",larrsim:"⥳",larrtl:"↢",latail:"⤙",lAtail:"⤛",lat:"⪫",late:"⪭",lates:"⪭︀",lbarr:"⤌",lBarr:"⤎",lbbrk:"❲",lbrace:"{",lbrack:"[",lbrke:"⦋",lbrksld:"⦏",lbrkslu:"⦍",Lcaron:"Ľ",lcaron:"ľ",Lcedil:"Ļ",lcedil:"ļ",lceil:"⌈",lcub:"{",Lcy:"Л",lcy:"л",ldca:"⤶",ldquo:"“",ldquor:"„",ldrdhar:"⥧",ldrushar:"⥋",ldsh:"↲",le:"≤",lE:"≦",LeftAngleBracket:"⟨",LeftArrowBar:"⇤",leftarrow:"←",LeftArrow:"←",Leftarrow:"⇐",LeftArrowRightArrow:"⇆",leftarrowtail:"↢",LeftCeiling:"⌈",LeftDoubleBracket:"⟦",LeftDownTeeVector:"⥡",LeftDownVectorBar:"⥙",LeftDownVector:"⇃",LeftFloor:"⌊",leftharpoondown:"↽",leftharpoonup:"↼",leftleftarrows:"⇇",leftrightarrow:"↔",LeftRightArrow:"↔",Leftrightarrow:"⇔",leftrightarrows:"⇆",leftrightharpoons:"⇋",leftrightsquigarrow:"↭",LeftRightVector:"⥎",LeftTeeArrow:"↤",LeftTee:"⊣",LeftTeeVector:"⥚",leftthreetimes:"⋋",LeftTriangleBar:"⧏",LeftTriangle:"⊲",LeftTriangleEqual:"⊴",LeftUpDownVector:"⥑",LeftUpTeeVector:"⥠",LeftUpVectorBar:"⥘",LeftUpVector:"↿",LeftVectorBar:"⥒",LeftVector:"↼",lEg:"⪋",leg:"⋚",leq:"≤",leqq:"≦",leqslant:"⩽",lescc:"⪨",les:"⩽",lesdot:"⩿",lesdoto:"⪁",lesdotor:"⪃",lesg:"⋚︀",lesges:"⪓",lessapprox:"⪅",lessdot:"⋖",lesseqgtr:"⋚",lesseqqgtr:"⪋",LessEqualGreater:"⋚",LessFullEqual:"≦",LessGreater:"≶",lessgtr:"≶",LessLess:"⪡",lesssim:"≲",LessSlantEqual:"⩽",LessTilde:"≲",lfisht:"⥼",lfloor:"⌊",Lfr:"𝔏",lfr:"𝔩",lg:"≶",lgE:"⪑",lHar:"⥢",lhard:"↽",lharu:"↼",lharul:"⥪",lhblk:"▄",LJcy:"Љ",ljcy:"љ",llarr:"⇇",ll:"≪",Ll:"⋘",llcorner:"⌞",Lleftarrow:"⇚",llhard:"⥫",lltri:"◺",Lmidot:"Ŀ",lmidot:"ŀ",lmoustache:"⎰",lmoust:"⎰",lnap:"⪉",lnapprox:"⪉",lne:"⪇",lnE:"≨",lneq:"⪇",lneqq:"≨",lnsim:"⋦",loang:"⟬",loarr:"⇽",lobrk:"⟦",longleftarrow:"⟵",LongLeftArrow:"⟵",Longleftarrow:"⟸",longleftrightarrow:"⟷",LongLeftRightArrow:"⟷",Longleftrightarrow:"⟺",longmapsto:"⟼",longrightarrow:"⟶",LongRightArrow:"⟶",Longrightarrow:"⟹",looparrowleft:"↫",looparrowright:"↬",lopar:"⦅",Lopf:"𝕃",lopf:"𝕝",loplus:"⨭",lotimes:"⨴",lowast:"∗",lowbar:"_",LowerLeftArrow:"↙",LowerRightArrow:"↘",loz:"◊",lozenge:"◊",lozf:"⧫",lpar:"(",lparlt:"⦓",lrarr:"⇆",lrcorner:"⌟",lrhar:"⇋",lrhard:"⥭",lrm:"‎",lrtri:"⊿",lsaquo:"‹",lscr:"𝓁",Lscr:"ℒ",lsh:"↰",Lsh:"↰",lsim:"≲",lsime:"⪍",lsimg:"⪏",lsqb:"[",lsquo:"‘",lsquor:"‚",Lstrok:"Ł",lstrok:"ł",ltcc:"⪦",ltcir:"⩹",lt:"<",LT:"<",Lt:"≪",ltdot:"⋖",lthree:"⋋",ltimes:"⋉",ltlarr:"⥶",ltquest:"⩻",ltri:"◃",ltrie:"⊴",ltrif:"◂",ltrPar:"⦖",lurdshar:"⥊",luruhar:"⥦",lvertneqq:"≨︀",lvnE:"≨︀",macr:"¯",male:"♂",malt:"✠",maltese:"✠",Map:"⤅",map:"↦",mapsto:"↦",mapstodown:"↧",mapstoleft:"↤",mapstoup:"↥",marker:"▮",mcomma:"⨩",Mcy:"М",mcy:"м",mdash:"—",mDDot:"∺",measuredangle:"∡",MediumSpace:" ",Mellintrf:"ℳ",Mfr:"𝔐",mfr:"𝔪",mho:"℧",micro:"µ",midast:"*",midcir:"⫰",mid:"∣",middot:"·",minusb:"⊟",minus:"−",minusd:"∸",minusdu:"⨪",MinusPlus:"∓",mlcp:"⫛",mldr:"…",mnplus:"∓",models:"⊧",Mopf:"𝕄",mopf:"𝕞",mp:"∓",mscr:"𝓂",Mscr:"ℳ",mstpos:"∾",Mu:"Μ",mu:"μ",multimap:"⊸",mumap:"⊸",nabla:"∇",Nacute:"Ń",nacute:"ń",nang:"∠⃒",nap:"≉",napE:"⩰̸",napid:"≋̸",napos:"ŉ",napprox:"≉",natural:"♮",naturals:"ℕ",natur:"♮",nbsp:" ",nbump:"≎̸",nbumpe:"≏̸",ncap:"⩃",Ncaron:"Ň",ncaron:"ň",Ncedil:"Ņ",ncedil:"ņ",ncong:"≇",ncongdot:"⩭̸",ncup:"⩂",Ncy:"Н",ncy:"н",ndash:"–",nearhk:"⤤",nearr:"↗",neArr:"⇗",nearrow:"↗",ne:"≠",nedot:"≐̸",NegativeMediumSpace:"​",NegativeThickSpace:"​",NegativeThinSpace:"​",NegativeVeryThinSpace:"​",nequiv:"≢",nesear:"⤨",nesim:"≂̸",NestedGreaterGreater:"≫",NestedLessLess:"≪",NewLine:"\n",nexist:"∄",nexists:"∄",Nfr:"𝔑",nfr:"𝔫",ngE:"≧̸",nge:"≱",ngeq:"≱",ngeqq:"≧̸",ngeqslant:"⩾̸",nges:"⩾̸",nGg:"⋙̸",ngsim:"≵",nGt:"≫⃒",ngt:"≯",ngtr:"≯",nGtv:"≫̸",nharr:"↮",nhArr:"⇎",nhpar:"⫲",ni:"∋",nis:"⋼",nisd:"⋺",niv:"∋",NJcy:"Њ",njcy:"њ",nlarr:"↚",nlArr:"⇍",nldr:"‥",nlE:"≦̸",nle:"≰",nleftarrow:"↚",nLeftarrow:"⇍",nleftrightarrow:"↮",nLeftrightarrow:"⇎",nleq:"≰",nleqq:"≦̸",nleqslant:"⩽̸",nles:"⩽̸",nless:"≮",nLl:"⋘̸",nlsim:"≴",nLt:"≪⃒",nlt:"≮",nltri:"⋪",nltrie:"⋬",nLtv:"≪̸",nmid:"∤",NoBreak:"⁠",NonBreakingSpace:" ",nopf:"𝕟",Nopf:"ℕ",Not:"⫬",not:"¬",NotCongruent:"≢",NotCupCap:"≭",NotDoubleVerticalBar:"∦",NotElement:"∉",NotEqual:"≠",NotEqualTilde:"≂̸",NotExists:"∄",NotGreater:"≯",NotGreaterEqual:"≱",NotGreaterFullEqual:"≧̸",NotGreaterGreater:"≫̸",NotGreaterLess:"≹",NotGreaterSlantEqual:"⩾̸",NotGreaterTilde:"≵",NotHumpDownHump:"≎̸",NotHumpEqual:"≏̸",notin:"∉",notindot:"⋵̸",notinE:"⋹̸",notinva:"∉",notinvb:"⋷",notinvc:"⋶",NotLeftTriangleBar:"⧏̸",NotLeftTriangle:"⋪",NotLeftTriangleEqual:"⋬",NotLess:"≮",NotLessEqual:"≰",NotLessGreater:"≸",NotLessLess:"≪̸",NotLessSlantEqual:"⩽̸",NotLessTilde:"≴",NotNestedGreaterGreater:"⪢̸",NotNestedLessLess:"⪡̸",notni:"∌",notniva:"∌",notnivb:"⋾",notnivc:"⋽",NotPrecedes:"⊀",NotPrecedesEqual:"⪯̸",NotPrecedesSlantEqual:"⋠",NotReverseElement:"∌",NotRightTriangleBar:"⧐̸",NotRightTriangle:"⋫",NotRightTriangleEqual:"⋭",NotSquareSubset:"⊏̸",NotSquareSubsetEqual:"⋢",NotSquareSuperset:"⊐̸",NotSquareSupersetEqual:"⋣",NotSubset:"⊂⃒",NotSubsetEqual:"⊈",NotSucceeds:"⊁",NotSucceedsEqual:"⪰̸",NotSucceedsSlantEqual:"⋡",NotSucceedsTilde:"≿̸",NotSuperset:"⊃⃒",NotSupersetEqual:"⊉",NotTilde:"≁",NotTildeEqual:"≄",NotTildeFullEqual:"≇",NotTildeTilde:"≉",NotVerticalBar:"∤",nparallel:"∦",npar:"∦",nparsl:"⫽⃥",npart:"∂̸",npolint:"⨔",npr:"⊀",nprcue:"⋠",nprec:"⊀",npreceq:"⪯̸",npre:"⪯̸",nrarrc:"⤳̸",nrarr:"↛",nrArr:"⇏",nrarrw:"↝̸",nrightarrow:"↛",nRightarrow:"⇏",nrtri:"⋫",nrtrie:"⋭",nsc:"⊁",nsccue:"⋡",nsce:"⪰̸",Nscr:"𝒩",nscr:"𝓃",nshortmid:"∤",nshortparallel:"∦",nsim:"≁",nsime:"≄",nsimeq:"≄",nsmid:"∤",nspar:"∦",nsqsube:"⋢",nsqsupe:"⋣",nsub:"⊄",nsubE:"⫅̸",nsube:"⊈",nsubset:"⊂⃒",nsubseteq:"⊈",nsubseteqq:"⫅̸",nsucc:"⊁",nsucceq:"⪰̸",nsup:"⊅",nsupE:"⫆̸",nsupe:"⊉",nsupset:"⊃⃒",nsupseteq:"⊉",nsupseteqq:"⫆̸",ntgl:"≹",Ntilde:"Ñ",ntilde:"ñ",ntlg:"≸",ntriangleleft:"⋪",ntrianglelefteq:"⋬",ntriangleright:"⋫",ntrianglerighteq:"⋭",Nu:"Ν",nu:"ν",num:"#",numero:"№",numsp:" ",nvap:"≍⃒",nvdash:"⊬",nvDash:"⊭",nVdash:"⊮",nVDash:"⊯",nvge:"≥⃒",nvgt:">⃒",nvHarr:"⤄",nvinfin:"⧞",nvlArr:"⤂",nvle:"≤⃒",nvlt:"<⃒",nvltrie:"⊴⃒",nvrArr:"⤃",nvrtrie:"⊵⃒",nvsim:"∼⃒",nwarhk:"⤣",nwarr:"↖",nwArr:"⇖",nwarrow:"↖",nwnear:"⤧",Oacute:"Ó",oacute:"ó",oast:"⊛",Ocirc:"Ô",ocirc:"ô",ocir:"⊚",Ocy:"О",ocy:"о",odash:"⊝",Odblac:"Ő",odblac:"ő",odiv:"⨸",odot:"⊙",odsold:"⦼",OElig:"Œ",oelig:"œ",ofcir:"⦿",Ofr:"𝔒",ofr:"𝔬",ogon:"˛",Ograve:"Ò",ograve:"ò",ogt:"⧁",ohbar:"⦵",ohm:"Ω",oint:"∮",olarr:"↺",olcir:"⦾",olcross:"⦻",oline:"‾",olt:"⧀",Omacr:"Ō",omacr:"ō",Omega:"Ω",omega:"ω",Omicron:"Ο",omicron:"ο",omid:"⦶",ominus:"⊖",Oopf:"𝕆",oopf:"𝕠",opar:"⦷",OpenCurlyDoubleQuote:"“",OpenCurlyQuote:"‘",operp:"⦹",oplus:"⊕",orarr:"↻",Or:"⩔",or:"∨",ord:"⩝",order:"ℴ",orderof:"ℴ",ordf:"ª",ordm:"º",origof:"⊶",oror:"⩖",orslope:"⩗",orv:"⩛",oS:"Ⓢ",Oscr:"𝒪",oscr:"ℴ",Oslash:"Ø",oslash:"ø",osol:"⊘",Otilde:"Õ",otilde:"õ",otimesas:"⨶",Otimes:"⨷",otimes:"⊗",Ouml:"Ö",ouml:"ö",ovbar:"⌽",OverBar:"‾",OverBrace:"⏞",OverBracket:"⎴",OverParenthesis:"⏜",para:"¶",parallel:"∥",par:"∥",parsim:"⫳",parsl:"⫽",part:"∂",PartialD:"∂",Pcy:"П",pcy:"п",percnt:"%",period:".",permil:"‰",perp:"⊥",pertenk:"‱",Pfr:"𝔓",pfr:"𝔭",Phi:"Φ",phi:"φ",phiv:"ϕ",phmmat:"ℳ",phone:"☎",Pi:"Π",pi:"π",pitchfork:"⋔",piv:"ϖ",planck:"ℏ",planckh:"ℎ",plankv:"ℏ",plusacir:"⨣",plusb:"⊞",pluscir:"⨢",plus:"+",plusdo:"∔",plusdu:"⨥",pluse:"⩲",PlusMinus:"±",plusmn:"±",plussim:"⨦",plustwo:"⨧",pm:"±",Poincareplane:"ℌ",pointint:"⨕",popf:"𝕡",Popf:"ℙ",pound:"£",prap:"⪷",Pr:"⪻",pr:"≺",prcue:"≼",precapprox:"⪷",prec:"≺",preccurlyeq:"≼",Precedes:"≺",PrecedesEqual:"⪯",PrecedesSlantEqual:"≼",PrecedesTilde:"≾",preceq:"⪯",precnapprox:"⪹",precneqq:"⪵",precnsim:"⋨",pre:"⪯",prE:"⪳",precsim:"≾",prime:"′",Prime:"″",primes:"ℙ",prnap:"⪹",prnE:"⪵",prnsim:"⋨",prod:"∏",Product:"∏",profalar:"⌮",profline:"⌒",profsurf:"⌓",prop:"∝",Proportional:"∝",Proportion:"∷",propto:"∝",prsim:"≾",prurel:"⊰",Pscr:"𝒫",pscr:"𝓅",Psi:"Ψ",psi:"ψ",puncsp:" ",Qfr:"𝔔",qfr:"𝔮",qint:"⨌",qopf:"𝕢",Qopf:"ℚ",qprime:"⁗",Qscr:"𝒬",qscr:"𝓆",quaternions:"ℍ",quatint:"⨖",quest:"?",questeq:"≟",quot:'"',QUOT:'"',rAarr:"⇛",race:"∽̱",Racute:"Ŕ",racute:"ŕ",radic:"√",raemptyv:"⦳",rang:"⟩",Rang:"⟫",rangd:"⦒",range:"⦥",rangle:"⟩",raquo:"»",rarrap:"⥵",rarrb:"⇥",rarrbfs:"⤠",rarrc:"⤳",rarr:"→",Rarr:"↠",rArr:"⇒",rarrfs:"⤞",rarrhk:"↪",rarrlp:"↬",rarrpl:"⥅",rarrsim:"⥴",Rarrtl:"⤖",rarrtl:"↣",rarrw:"↝",ratail:"⤚",rAtail:"⤜",ratio:"∶",rationals:"ℚ",rbarr:"⤍",rBarr:"⤏",RBarr:"⤐",rbbrk:"❳",rbrace:"}",rbrack:"]",rbrke:"⦌",rbrksld:"⦎",rbrkslu:"⦐",Rcaron:"Ř",rcaron:"ř",Rcedil:"Ŗ",rcedil:"ŗ",rceil:"⌉",rcub:"}",Rcy:"Р",rcy:"р",rdca:"⤷",rdldhar:"⥩",rdquo:"”",rdquor:"”",rdsh:"↳",real:"ℜ",realine:"ℛ",realpart:"ℜ",reals:"ℝ",Re:"ℜ",rect:"▭",reg:"®",REG:"®",ReverseElement:"∋",ReverseEquilibrium:"⇋",ReverseUpEquilibrium:"⥯",rfisht:"⥽",rfloor:"⌋",rfr:"𝔯",Rfr:"ℜ",rHar:"⥤",rhard:"⇁",rharu:"⇀",rharul:"⥬",Rho:"Ρ",rho:"ρ",rhov:"ϱ",RightAngleBracket:"⟩",RightArrowBar:"⇥",rightarrow:"→",RightArrow:"→",Rightarrow:"⇒",RightArrowLeftArrow:"⇄",rightarrowtail:"↣",RightCeiling:"⌉",RightDoubleBracket:"⟧",RightDownTeeVector:"⥝",RightDownVectorBar:"⥕",RightDownVector:"⇂",RightFloor:"⌋",rightharpoondown:"⇁",rightharpoonup:"⇀",rightleftarrows:"⇄",rightleftharpoons:"⇌",rightrightarrows:"⇉",rightsquigarrow:"↝",RightTeeArrow:"↦",RightTee:"⊢",RightTeeVector:"⥛",rightthreetimes:"⋌",RightTriangleBar:"⧐",RightTriangle:"⊳",RightTriangleEqual:"⊵",RightUpDownVector:"⥏",RightUpTeeVector:"⥜",RightUpVectorBar:"⥔",RightUpVector:"↾",RightVectorBar:"⥓",RightVector:"⇀",ring:"˚",risingdotseq:"≓",rlarr:"⇄",rlhar:"⇌",rlm:"‏",rmoustache:"⎱",rmoust:"⎱",rnmid:"⫮",roang:"⟭",roarr:"⇾",robrk:"⟧",ropar:"⦆",ropf:"𝕣",Ropf:"ℝ",roplus:"⨮",rotimes:"⨵",RoundImplies:"⥰",rpar:")",rpargt:"⦔",rppolint:"⨒",rrarr:"⇉",Rrightarrow:"⇛",rsaquo:"›",rscr:"𝓇",Rscr:"ℛ",rsh:"↱",Rsh:"↱",rsqb:"]",rsquo:"’",rsquor:"’",rthree:"⋌",rtimes:"⋊",rtri:"▹",rtrie:"⊵",rtrif:"▸",rtriltri:"⧎",RuleDelayed:"⧴",ruluhar:"⥨",rx:"℞",Sacute:"Ś",sacute:"ś",sbquo:"‚",scap:"⪸",Scaron:"Š",scaron:"š",Sc:"⪼",sc:"≻",sccue:"≽",sce:"⪰",scE:"⪴",Scedil:"Ş",scedil:"ş",Scirc:"Ŝ",scirc:"ŝ",scnap:"⪺",scnE:"⪶",scnsim:"⋩",scpolint:"⨓",scsim:"≿",Scy:"С",scy:"с",sdotb:"⊡",sdot:"⋅",sdote:"⩦",searhk:"⤥",searr:"↘",seArr:"⇘",searrow:"↘",sect:"§",semi:";",seswar:"⤩",setminus:"∖",setmn:"∖",sext:"✶",Sfr:"𝔖",sfr:"𝔰",sfrown:"⌢",sharp:"♯",SHCHcy:"Щ",shchcy:"щ",SHcy:"Ш",shcy:"ш",ShortDownArrow:"↓",ShortLeftArrow:"←",shortmid:"∣",shortparallel:"∥",ShortRightArrow:"→",ShortUpArrow:"↑",shy:"­",Sigma:"Σ",sigma:"σ",sigmaf:"ς",sigmav:"ς",sim:"∼",simdot:"⩪",sime:"≃",simeq:"≃",simg:"⪞",simgE:"⪠",siml:"⪝",simlE:"⪟",simne:"≆",simplus:"⨤",simrarr:"⥲",slarr:"←",SmallCircle:"∘",smallsetminus:"∖",smashp:"⨳",smeparsl:"⧤",smid:"∣",smile:"⌣",smt:"⪪",smte:"⪬",smtes:"⪬︀",SOFTcy:"Ь",softcy:"ь",solbar:"⌿",solb:"⧄",sol:"/",Sopf:"𝕊",sopf:"𝕤",spades:"♠",spadesuit:"♠",spar:"∥",sqcap:"⊓",sqcaps:"⊓︀",sqcup:"⊔",sqcups:"⊔︀",Sqrt:"√",sqsub:"⊏",sqsube:"⊑",sqsubset:"⊏",sqsubseteq:"⊑",sqsup:"⊐",sqsupe:"⊒",sqsupset:"⊐",sqsupseteq:"⊒",square:"□",Square:"□",SquareIntersection:"⊓",SquareSubset:"⊏",SquareSubsetEqual:"⊑",SquareSuperset:"⊐",SquareSupersetEqual:"⊒",SquareUnion:"⊔",squarf:"▪",squ:"□",squf:"▪",srarr:"→",Sscr:"𝒮",sscr:"𝓈",ssetmn:"∖",ssmile:"⌣",sstarf:"⋆",Star:"⋆",star:"☆",starf:"★",straightepsilon:"ϵ",straightphi:"ϕ",strns:"¯",sub:"⊂",Sub:"⋐",subdot:"⪽",subE:"⫅",sube:"⊆",subedot:"⫃",submult:"⫁",subnE:"⫋",subne:"⊊",subplus:"⪿",subrarr:"⥹",subset:"⊂",Subset:"⋐",subseteq:"⊆",subseteqq:"⫅",SubsetEqual:"⊆",subsetneq:"⊊",subsetneqq:"⫋",subsim:"⫇",subsub:"⫕",subsup:"⫓",succapprox:"⪸",succ:"≻",succcurlyeq:"≽",Succeeds:"≻",SucceedsEqual:"⪰",SucceedsSlantEqual:"≽",SucceedsTilde:"≿",succeq:"⪰",succnapprox:"⪺",succneqq:"⪶",succnsim:"⋩",succsim:"≿",SuchThat:"∋",sum:"∑",Sum:"∑",sung:"♪",sup1:"¹",sup2:"²",sup3:"³",sup:"⊃",Sup:"⋑",supdot:"⪾",supdsub:"⫘",supE:"⫆",supe:"⊇",supedot:"⫄",Superset:"⊃",SupersetEqual:"⊇",suphsol:"⟉",suphsub:"⫗",suplarr:"⥻",supmult:"⫂",supnE:"⫌",supne:"⊋",supplus:"⫀",supset:"⊃",Supset:"⋑",supseteq:"⊇",supseteqq:"⫆",supsetneq:"⊋",supsetneqq:"⫌",supsim:"⫈",supsub:"⫔",supsup:"⫖",swarhk:"⤦",swarr:"↙",swArr:"⇙",swarrow:"↙",swnwar:"⤪",szlig:"ß",Tab:"\t",target:"⌖",Tau:"Τ",tau:"τ",tbrk:"⎴",Tcaron:"Ť",tcaron:"ť",Tcedil:"Ţ",tcedil:"ţ",Tcy:"Т",tcy:"т",tdot:"⃛",telrec:"⌕",Tfr:"𝔗",tfr:"𝔱",there4:"∴",therefore:"∴",Therefore:"∴",Theta:"Θ",theta:"θ",thetasym:"ϑ",thetav:"ϑ",thickapprox:"≈",thicksim:"∼",ThickSpace:"  ",ThinSpace:" ",thinsp:" ",thkap:"≈",thksim:"∼",THORN:"Þ",thorn:"þ",tilde:"˜",Tilde:"∼",TildeEqual:"≃",TildeFullEqual:"≅",TildeTilde:"≈",timesbar:"⨱",timesb:"⊠",times:"×",timesd:"⨰",tint:"∭",toea:"⤨",topbot:"⌶",topcir:"⫱",top:"⊤",Topf:"𝕋",topf:"𝕥",topfork:"⫚",tosa:"⤩",tprime:"‴",trade:"™",TRADE:"™",triangle:"▵",triangledown:"▿",triangleleft:"◃",trianglelefteq:"⊴",triangleq:"≜",triangleright:"▹",trianglerighteq:"⊵",tridot:"◬",trie:"≜",triminus:"⨺",TripleDot:"⃛",triplus:"⨹",trisb:"⧍",tritime:"⨻",trpezium:"⏢",Tscr:"𝒯",tscr:"𝓉",TScy:"Ц",tscy:"ц",TSHcy:"Ћ",tshcy:"ћ",Tstrok:"Ŧ",tstrok:"ŧ",twixt:"≬",twoheadleftarrow:"↞",twoheadrightarrow:"↠",Uacute:"Ú",uacute:"ú",uarr:"↑",Uarr:"↟",uArr:"⇑",Uarrocir:"⥉",Ubrcy:"Ў",ubrcy:"ў",Ubreve:"Ŭ",ubreve:"ŭ",Ucirc:"Û",ucirc:"û",Ucy:"У",ucy:"у",udarr:"⇅",Udblac:"Ű",udblac:"ű",udhar:"⥮",ufisht:"⥾",Ufr:"𝔘",ufr:"𝔲",Ugrave:"Ù",ugrave:"ù",uHar:"⥣",uharl:"↿",uharr:"↾",uhblk:"▀",ulcorn:"⌜",ulcorner:"⌜",ulcrop:"⌏",ultri:"◸",Umacr:"Ū",umacr:"ū",uml:"¨",UnderBar:"_",UnderBrace:"⏟",UnderBracket:"⎵",UnderParenthesis:"⏝",Union:"⋃",UnionPlus:"⊎",Uogon:"Ų",uogon:"ų",Uopf:"𝕌",uopf:"𝕦",UpArrowBar:"⤒",uparrow:"↑",UpArrow:"↑",Uparrow:"⇑",UpArrowDownArrow:"⇅",updownarrow:"↕",UpDownArrow:"↕",Updownarrow:"⇕",UpEquilibrium:"⥮",upharpoonleft:"↿",upharpoonright:"↾",uplus:"⊎",UpperLeftArrow:"↖",UpperRightArrow:"↗",upsi:"υ",Upsi:"ϒ",upsih:"ϒ",Upsilon:"Υ",upsilon:"υ",UpTeeArrow:"↥",UpTee:"⊥",upuparrows:"⇈",urcorn:"⌝",urcorner:"⌝",urcrop:"⌎",Uring:"Ů",uring:"ů",urtri:"◹",Uscr:"𝒰",uscr:"𝓊",utdot:"⋰",Utilde:"Ũ",utilde:"ũ",utri:"▵",utrif:"▴",uuarr:"⇈",Uuml:"Ü",uuml:"ü",uwangle:"⦧",vangrt:"⦜",varepsilon:"ϵ",varkappa:"ϰ",varnothing:"∅",varphi:"ϕ",varpi:"ϖ",varpropto:"∝",varr:"↕",vArr:"⇕",varrho:"ϱ",varsigma:"ς",varsubsetneq:"⊊︀",varsubsetneqq:"⫋︀",varsupsetneq:"⊋︀",varsupsetneqq:"⫌︀",vartheta:"ϑ",vartriangleleft:"⊲",vartriangleright:"⊳",vBar:"⫨",Vbar:"⫫",vBarv:"⫩",Vcy:"В",vcy:"в",vdash:"⊢",vDash:"⊨",Vdash:"⊩",VDash:"⊫",Vdashl:"⫦",veebar:"⊻",vee:"∨",Vee:"⋁",veeeq:"≚",vellip:"⋮",verbar:"|",Verbar:"‖",vert:"|",Vert:"‖",VerticalBar:"∣",VerticalLine:"|",VerticalSeparator:"❘",VerticalTilde:"≀",VeryThinSpace:" ",Vfr:"𝔙",vfr:"𝔳",vltri:"⊲",vnsub:"⊂⃒",vnsup:"⊃⃒",Vopf:"𝕍",vopf:"𝕧",vprop:"∝",vrtri:"⊳",Vscr:"𝒱",vscr:"𝓋",vsubnE:"⫋︀",vsubne:"⊊︀",vsupnE:"⫌︀",vsupne:"⊋︀",Vvdash:"⊪",vzigzag:"⦚",Wcirc:"Ŵ",wcirc:"ŵ",wedbar:"⩟",wedge:"∧",Wedge:"⋀",wedgeq:"≙",weierp:"℘",Wfr:"𝔚",wfr:"𝔴",Wopf:"𝕎",wopf:"𝕨",wp:"℘",wr:"≀",wreath:"≀",Wscr:"𝒲",wscr:"𝓌",xcap:"⋂",xcirc:"◯",xcup:"⋃",xdtri:"▽",Xfr:"𝔛",xfr:"𝔵",xharr:"⟷",xhArr:"⟺",Xi:"Ξ",xi:"ξ",xlarr:"⟵",xlArr:"⟸",xmap:"⟼",xnis:"⋻",xodot:"⨀",Xopf:"𝕏",xopf:"𝕩",xoplus:"⨁",xotime:"⨂",xrarr:"⟶",xrArr:"⟹",Xscr:"𝒳",xscr:"𝓍",xsqcup:"⨆",xuplus:"⨄",xutri:"△",xvee:"⋁",xwedge:"⋀",Yacute:"Ý",yacute:"ý",YAcy:"Я",yacy:"я",Ycirc:"Ŷ",ycirc:"ŷ",Ycy:"Ы",ycy:"ы",yen:"¥",Yfr:"𝔜",yfr:"𝔶",YIcy:"Ї",yicy:"ї",Yopf:"𝕐",yopf:"𝕪",Yscr:"𝒴",yscr:"𝓎",YUcy:"Ю",yucy:"ю",yuml:"ÿ",Yuml:"Ÿ",Zacute:"Ź",zacute:"ź",Zcaron:"Ž",zcaron:"ž",Zcy:"З",zcy:"з",Zdot:"Ż",zdot:"ż",zeetrf:"ℨ",ZeroWidthSpace:"​",Zeta:"Ζ",zeta:"ζ",zfr:"𝔷",Zfr:"ℨ",ZHcy:"Ж",zhcy:"ж",zigrarr:"⇝",zopf:"𝕫",Zopf:"ℤ",Zscr:"𝒵",zscr:"𝓏",zwj:"‍",zwnj:"‌"}},function(t,e){t.exports={Aacute:"Á",aacute:"á",Acirc:"Â",acirc:"â",acute:"´",AElig:"Æ",aelig:"æ",Agrave:"À",agrave:"à",amp:"&",AMP:"&",Aring:"Å",aring:"å",Atilde:"Ã",atilde:"ã",Auml:"Ä",auml:"ä",brvbar:"¦",Ccedil:"Ç",ccedil:"ç",cedil:"¸",cent:"¢",copy:"©",COPY:"©",curren:"¤",deg:"°",divide:"÷",Eacute:"É",eacute:"é",Ecirc:"Ê",ecirc:"ê",Egrave:"È",egrave:"è",ETH:"Ð",eth:"ð",Euml:"Ë",euml:"ë",frac12:"½",frac14:"¼",frac34:"¾",gt:">",GT:">",Iacute:"Í",iacute:"í",Icirc:"Î",icirc:"î",iexcl:"¡",Igrave:"Ì",igrave:"ì",iquest:"¿",Iuml:"Ï",iuml:"ï",laquo:"«",lt:"<",LT:"<",macr:"¯",micro:"µ",middot:"·",nbsp:" ",not:"¬",Ntilde:"Ñ",ntilde:"ñ",Oacute:"Ó",oacute:"ó",Ocirc:"Ô",ocirc:"ô",Ograve:"Ò",ograve:"ò",ordf:"ª",ordm:"º",Oslash:"Ø",oslash:"ø",Otilde:"Õ",otilde:"õ",Ouml:"Ö",ouml:"ö",para:"¶",plusmn:"±",pound:"£",quot:'"',QUOT:'"',raquo:"»",reg:"®",REG:"®",sect:"§",shy:"­",sup1:"¹",sup2:"²",sup3:"³",szlig:"ß",THORN:"Þ",thorn:"þ",times:"×",Uacute:"Ú",uacute:"ú",Ucirc:"Û",ucirc:"û",Ugrave:"Ù",ugrave:"ù",uml:"¨",Uuml:"Ü",uuml:"ü",Yacute:"Ý",yacute:"ý",yen:"¥",yuml:"ÿ"}},function(t,e){t.exports={amp:"&",apos:"'",gt:">",lt:"<",quot:'"'}},function(t,e){"function"==typeof Object.create?t.exports=function(t,e){t.super_=e,t.prototype=Object.create(e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}})}:t.exports=function(t,e){t.super_=e;var r=function(){};r.prototype=e.prototype,t.prototype=new r,t.prototype.constructor=t}},function(t,e){function r(t){return(r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}function s(){this._events=this._events||{},this._maxListeners=this._maxListeners||void 0}function i(t){return"function"==typeof t}function o(t){return"object"===r(t)&&null!==t}function n(t){return void 0===t}t.exports=s,s.EventEmitter=s,s.prototype._events=void 0,s.prototype._maxListeners=void 0,s.defaultMaxListeners=10,s.prototype.setMaxListeners=function(t){if("number"!=typeof t||t<0||isNaN(t))throw TypeError("n must be a positive number");return this._maxListeners=t,this},s.prototype.emit=function(t){var e,r,s,a,c,u;if(this._events||(this._events={}),"error"===t&&(!this._events.error||o(this._events.error)&&!this._events.error.length)){if((e=arguments[1])instanceof Error)throw e;var l=new Error('Uncaught, unspecified "error" event. ('+e+")");throw l.context=e,l}if(n(r=this._events[t]))return!1;if(i(r))switch(arguments.length){case 1:r.call(this);break;case 2:r.call(this,arguments[1]);break;case 3:r.call(this,arguments[1],arguments[2]);break;default:a=Array.prototype.slice.call(arguments,1),r.apply(this,a)}else if(o(r))for(a=Array.prototype.slice.call(arguments,1),s=(u=r.slice()).length,c=0;c<s;c++)u[c].apply(this,a);return!0},s.prototype.addListener=function(t,e){var r;if(!i(e))throw TypeError("listener must be a function");return this._events||(this._events={}),this._events.newListener&&this.emit("newListener",t,i(e.listener)?e.listener:e),this._events[t]?o(this._events[t])?this._events[t].push(e):this._events[t]=[this._events[t],e]:this._events[t]=e,o(this._events[t])&&!this._events[t].warned&&(r=n(this._maxListeners)?s.defaultMaxListeners:this._maxListeners)&&r>0&&this._events[t].length>r&&(this._events[t].warned=!0,console.error("(node) warning: possible EventEmitter memory leak detected. %d listeners added. Use emitter.setMaxListeners() to increase limit.",this._events[t].length),"function"==typeof console.trace&&console.trace()),this},s.prototype.on=s.prototype.addListener,s.prototype.once=function(t,e){if(!i(e))throw TypeError("listener must be a function");var r=!1;function s(){this.removeListener(t,s),r||(r=!0,e.apply(this,arguments))}return s.listener=e,this.on(t,s),this},s.prototype.removeListener=function(t,e){var r,s,n,a;if(!i(e))throw TypeError("listener must be a function");if(!this._events||!this._events[t])return this;if(n=(r=this._events[t]).length,s=-1,r===e||i(r.listener)&&r.listener===e)delete this._events[t],this._events.removeListener&&this.emit("removeListener",t,e);else if(o(r)){for(a=n;a-- >0;)if(r[a]===e||r[a].listener&&r[a].listener===e){s=a;break}if(s<0)return this;1===r.length?(r.length=0,delete this._events[t]):r.splice(s,1),this._events.removeListener&&this.emit("removeListener",t,e)}return this},s.prototype.removeAllListeners=function(t){var e,r;if(!this._events)return this;if(!this._events.removeListener)return 0===arguments.length?this._events={}:this._events[t]&&delete this._events[t],this;if(0===arguments.length){for(e in this._events)"removeListener"!==e&&this.removeAllListeners(e);return this.removeAllListeners("removeListener"),this._events={},this}if(i(r=this._events[t]))this.removeListener(t,r);else if(r)for(;r.length;)this.removeListener(t,r[r.length-1]);return delete this._events[t],this},s.prototype.listeners=function(t){return this._events&&this._events[t]?i(this._events[t])?[this._events[t]]:this._events[t].slice():[]},s.prototype.listenerCount=function(t){if(this._events){var e=this._events[t];if(i(e))return 1;if(e)return e.length}return 0},s.listenerCount=function(t,e){return t.listenerCount(e)}},function(t,e,r){"use strict";function s(t){return(s="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}var i=r(73);t.exports=function(t){return null!=t&&"object"===s(t)&&!1===i(t)}},function(t,e){var r={}.toString;t.exports=Array.isArray||function(t){return"[object Array]"==r.call(t)}},function(t,e,r){"use strict";var s=Object.getOwnPropertySymbols,i=Object.prototype.hasOwnProperty,o=Object.prototype.propertyIsEnumerable;t.exports=function(){try{if(!Object.assign)return!1;var t=new String("abc");if(t[5]="de","5"===Object.getOwnPropertyNames(t)[0])return!1;for(var e={},r=0;r<10;r++)e["_"+String.fromCharCode(r)]=r;if("0123456789"!==Object.getOwnPropertyNames(e).map(function(t){return e[t]}).join(""))return!1;var s={};return"abcdefghijklmnopqrst".split("").forEach(function(t){s[t]=t}),"abcdefghijklmnopqrst"===Object.keys(Object.assign({},s)).join("")}catch(t){return!1}}()?Object.assign:function(t,e){for(var r,n,a=function(t){if(null===t||void 0===t)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(t)}(t),c=1;c<arguments.length;c++){for(var u in r=Object(arguments[c]))i.call(r,u)&&(a[u]=r[u]);if(s){n=s(r);for(var l=0;l<n.length;l++)o.call(r,n[l])&&(a[n[l]]=r[n[l]])}}return a}}]); 
 			}); 
		define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([31],{13:function(e,n,t){t(44)},44:function(e,n,t){"use strict";var a=t(4),o=t(3);App({globalData:{},onLaunch:function(){var e=(arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}).scene;this.globalData||(this.globalData={}),this.globalData.scene=e,this.updateWechatScene(e,!0);var n=wx.getSystemInfoSync(),t=/iPhone X/.test(n.model)?20:0;Object.assign(this.globalData,{systemInfo:n,safeAreaInsetValue:t}),this.authRequired()},onShow:function(){var e=(arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}).scene;this.updateWechatScene(e)},updateWechatScene:function(e,n){e===a.WechatScene.THIRD_PARTY_APP_SHARE_CARD?wx.setStorageSync("CAN_OPEN_APP",1):n&&e!==a.WechatScene.THIRD_PARTY_APP_SHARE_CARD?wx.removeStorageSync("CAN_OPEN_APP"):e!==a.WechatScene.PULL_DOWN_PANEL&&e!==a.WechatScene.LONG_PRESS_HOME&&wx.removeStorageSync("CAN_OPEN_APP")},getUserInfo:function(){var e=this;if(this.globalData&&this.globalData.userInfo)return this.globalData.userInfo;wx.getUserInfo({lang:"zh_CN",success:function(n){e.globalData.userInfo=n.userInfo}})},sessionRequired:function(e){return function(){wx.getStorageSync("sessionKey")?wx.checkSession({success:e,fail:function(){(0,o.getSessionKeyOnce)().then(e)}}):(0,o.getSessionKeyOnce)().then(e)}},authRequired:function(){var e=this,n=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];return new Promise(function(t,a){var s=function(){n&&(0,o.getSessionKeyOnce)().then(function(){return t(e.authRequired(!1))},a)};e.sessionRequired(function(){var e=(0,o.getAuthorizationStatus)(),n=e.token,c=e.status;c===o.LOGIN_STATUS.LOGGED_IN&&n?t(n):c===o.LOGIN_STATUS.NEED_REFRESH&&n?(0,o.getAuthorization)(o.LoginType.refresh).catch(s).then(t,a):n&&c!==o.LOGIN_STATUS.NOT_LOGGED_IN?a(new Error("Reached unreachable: LOGIN_STATUS not processed: ".concat(c))):(0,o.getAuthorization)(o.LoginType.login).then(t,a)})()})}})}},[13]); 
 			}); 	require("app.js");
 		__wxRoute = '_/_node_modules_/@wxa/ztext/lib/ui-codeblock';__wxRouteBegin = true; 	__wxAppCurrentFile__ = '_/_node_modules_/@wxa/ztext/lib/ui-codeblock.js';	define("_/_node_modules_/@wxa/ztext/lib/ui-codeblock.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../../../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([9],{88:function(e,n,o){o(89)},89:function(e,n){Component({externalClasses:["block-class"],properties:{node:Object}})}},[88]); 
 			}); 	require("_/_node_modules_/@wxa/ztext/lib/ui-codeblock.js");
 		__wxRoute = '_/_node_modules_/@wxa/ztext/lib/ui-gif';__wxRouteBegin = true; 	__wxAppCurrentFile__ = '_/_node_modules_/@wxa/ztext/lib/ui-gif.js';	define("_/_node_modules_/@wxa/ztext/lib/ui-gif.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../../../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([8],{90:function(t,a,s){s(91)},91:function(t,a){Component({externalClasses:["block-class"],data:{showGif:!1,isLoading:!1,status:"normal"},properties:{node:Object},attached:function(){var t=this.data.node;this.setData(function(t){var a=t.children.find(function(t){return"img"===t.name}),s=t.children.filter(function(t){return t!==a});return{src:a.attrs["data-actualsrc"],poster:a.attrs["data-thumbnail"],width:a.attrs["data-rawwidth"]||a.attrs.width,height:a.attrs["data-rawheight"]||a.attrs.height,class:a.attrs.class,restNodes:s}}(t))},methods:{handleTap:function(){this.loadGif()},loadGif:function(){"loading"===this.data.status||this.data.showGif||this.setData({showGif:!0,status:"loading"})},handleGifLoad:function(){this.setData({status:"loaded"})},handleGifError:function(){this.setData({showGif:!1,status:"error"})}}})}},[90]); 
 			}); 	require("_/_node_modules_/@wxa/ztext/lib/ui-gif.js");
 		__wxRoute = '_/_node_modules_/@wxa/ztext/lib/ui-image';__wxRouteBegin = true; 	__wxAppCurrentFile__ = '_/_node_modules_/@wxa/ztext/lib/ui-image.js';	define("_/_node_modules_/@wxa/ztext/lib/ui-image.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../../../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([7],{92:function(t,r,a){a(93)},93:function(t,r){Component({externalClasses:["block-class"],data:{},properties:{node:Object,previewUrls:Array},attached:function(){var t=this.data.node;this.setData(function(t){var r=t.children.find(function(t){return"img"===t.name}),a=t.children.filter(function(t){return t!==r});t.children.find(function(r){return"div"===r.name&&"figcaption"===t.attrs.class});return{src:r.attrs.src,width:r.attrs["data-rawwidth"]||r.attrs.width,height:r.attrs["data-rawheight"]||r.attrs.height,restNodes:a,class:r.attrs.class}}(t))},methods:{handleTap:function(t){var r=t.currentTarget.dataset.src;wx.previewImage({current:r,urls:this.data.previewUrls})}}})}},[92]); 
 			}); 	require("_/_node_modules_/@wxa/ztext/lib/ui-image.js");
 		__wxRoute = '_/_node_modules_/@wxa/ztext/lib/ui-video';__wxRouteBegin = true; 	__wxAppCurrentFile__ = '_/_node_modules_/@wxa/ztext/lib/ui-video.js';	define("_/_node_modules_/@wxa/ztext/lib/ui-video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../../../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([3],{94:function(e,t,a){a(95)},95:function(e,t,a){"use strict";var n,i=(n=a(96))&&n.__esModule?n:{default:n};Component({externalClasses:["block-class"],data:{video:null,isLoading:!1,lastPlayTime:0},properties:{lensId:String,poster:String,node:Object,useFullscreenVideo:Boolean},attached:function(){var e=this.data.node;e&&this.setData(function(e){return{lensId:e.attrs["data-lens-id"],poster:e.attrs["data-poster"]}}(e)),this.recordPlayTime=0},methods:{handleTap:function(){this.fetchVideoInfo()},fetchVideoInfo:function(){var e=this;this.data.isLoading||(this.setData({isLoading:!0}),(0,i.default)(wx.request)({url:"https://lens.zhihu.com/api/videos/".concat(this.data.lensId),header:{authorization:"oauth c3cef7c66a1843f8b3a9e6a1e3160e20"}}).then(function(t){e.setData({isLoading:!1}),t.data&&e.setData({video:t.data})}).then(function(){e.data.useFullscreenVideo&&(e.videoContext=wx.createVideoContext("myVideo",e),e.videoContext.requestFullScreen({direction:0}))}).catch(function(){e.setData({isLoading:!1})}))},handleTimeUpdate:function(e){var t=e.detail,a=t.currentTime;t.duration;this.recordPlayTime=a},handleFullScreenChange:function(e){var t=e.detail.fullScreen;this.data.useFullscreenVideo&&!t&&this.setData({lastPlayTime:this.recordPlayTime,video:null})}}})},96:function(e,t,a){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n=function(e){return function(t){return new Promise(function(a,n){e(Object.assign({},t,{success:function(e){a(e)},fail:function(e){n(e)}}))})}};t.default=n}},[94]); 
 			}); 	require("_/_node_modules_/@wxa/ztext/lib/ui-video.js");
 		__wxRoute = '_/_node_modules_/@wxa/ztext/lib/ztext-auto';__wxRouteBegin = true; 	__wxAppCurrentFile__ = '_/_node_modules_/@wxa/ztext/lib/ztext-auto.js';	define("_/_node_modules_/@wxa/ztext/lib/ztext-auto.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../../../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([6],{82:function(t,e,a){a(83)},83:function(t,e,a){var n=a(9);Component({properties:{tree:Array,html:String},attached:function(){var t=this.data,e=t.html,a=t.tree;this.setData({tree:e?n(e):a})}})}},[82]); 
 			}); 	require("_/_node_modules_/@wxa/ztext/lib/ztext-auto.js");
 		__wxRoute = '_/_node_modules_/@wxa/ztext/lib/ztext';__wxRouteBegin = true; 	__wxAppCurrentFile__ = '_/_node_modules_/@wxa/ztext/lib/ztext.js';	define("_/_node_modules_/@wxa/ztext/lib/ztext.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../../../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([0],{84:function(t,r,e){e(85)},85:function(t,r,e){"use strict";var n=a(e(8)),o=a(e(86));function a(t){return t&&t.__esModule?t:{default:t}}var u={codeblock:{name:"div",attrs:{class:/\bhighlight\b/}},video:{name:"a",attrs:{class:/\bvideo-box\b/}},gif:{name:"div",attrs:{class:"figure"},children:[{name:"img",attrs:{"data-actualsrc":/\.gif$/}}]},image:{name:"div",attrs:{class:"figure"}}};Component({properties:{tree:Array,html:String,useFullscreenVideo:Boolean},attached:function(){var t=this.data,r=t.html,e=t.tree;if(!r&&e.length){var a=(0,o.default)((0,n.default)(e),u),i=function(t){var r,e=[],n=!0,o=!1,a=void 0;try{for(var u,i=t[Symbol.iterator]();!(n=(u=i.next()).done);n=!0){var l=u.value,f=l.type,c=l.node;"image"===f&&e.push((r=c.children.find(function(t){return"img"===t.name})).attrs&&r.attrs.src)}}catch(t){o=!0,a=t}finally{try{n||null==i.return||i.return()}finally{if(o)throw a}}return e.filter(Boolean)}(a);this.setData({list:a,previewUrls:i})}}})},86:function(t,r,e){"use strict";Object.defineProperty(r,"__esModule",{value:!0}),r.default=void 0;var n,o=(n=e(87))&&n.__esModule?n:{default:n};function a(t,r){if(Array.isArray(t))return t;if(Symbol.iterator in Object(t))return function(t,r){var e=[],n=!0,o=!1,a=void 0;try{for(var u,i=t[Symbol.iterator]();!(n=(u=i.next()).done)&&(e.push(u.value),!r||e.length!==r);n=!0);}catch(t){o=!0,a=t}finally{try{n||null==i.return||i.return()}finally{if(o)throw a}}return e}(t,r);throw new TypeError("Invalid attempt to destructure non-iterable instance")}var u=function(t,r){var e,n=(e=r,Object.keys(e).map(function(t){return[t,e[t]]}));return t.reduce(function(t,r){var e,u=t[t.length-1],i=function(t){var r=!0,e=!1,u=void 0;try{for(var i,l=n[Symbol.iterator]();!(r=(i=l.next()).done);r=!0){var f=a(i.value,2),c=f[0],s=f[1];if((0,o.default)(s,t))return{type:c,node:t}}}catch(t){e=!0,u=t}finally{try{r||null==l.return||l.return()}finally{if(e)throw u}}return{type:null,tree:[t]}}(r);return u&&null===u.type&&null===i.type?(e=u.tree).push.apply(e,function(t){if(Array.isArray(t)){for(var r=0,e=new Array(t.length);r<t.length;r++)e[r]=t[r];return e}return Array.from(t)}(i.tree)):t.push(i),t},[])};r.default=u},87:function(t,r,e){"use strict";function n(t){return(n="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}Object.defineProperty(r,"__esModule",{value:!0}),r.default=void 0;var o=function t(r,e){if(r instanceof RegExp){if("object"===n(e))return!1;if("string"==typeof e)return r.test(e)}return n(r)===n(e)&&("object"!==n(r)||null===r?r===e:Array.isArray(r)?r.every(function(r){return[].some.call(e,function(e){return t(r,e)})}):Object.keys(r).every(function(o){var a=e[o],u=r[o];return"object"===n(u)&&null!==u&&null!==a?t(u,a):"boolean"==typeof u?u!==(null==a):a===u}))};r.default=o}},[84]); 
 			}); 	require("_/_node_modules_/@wxa/ztext/lib/ztext.js");
 		__wxRoute = 'components/HotRecommandsItem';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'components/HotRecommandsItem.js';	define("components/HotRecommandsItem.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([30],{107:function(e,o,t){t(108)},108:function(e,o,t){"use strict";var c,n=(c=t(2))&&c.__esModule?c:{default:c};Component({properties:{recommand:Object},data:{},methods:{handleTap:function(){var e=this.data.recommand,o="/zhihu/".concat(e.content_type,"?id=").concat(e.url_token,"&source=").concat(e.source);wx.reportAnalytics("hot_recommend_click",{type:e.content_type,source:e.source}),(0,n.default)({url:o})}}})}},[107]); 
 			}); 	require("components/HotRecommandsItem.js");
 		__wxRoute = 'components/OffscreenMeasure';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'components/OffscreenMeasure.js';	define("components/OffscreenMeasure.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([29],{123:function(e,n,t){t(124)},124:function(e,n){Component({properties:{fontSize:{type:String,value:15}},ready:function(){var e=this,n=this.createSelectorQuery();n.select(".offscreen").boundingClientRect(),n.exec(function(n){var t=n[0].height/e.data.fontSize;e.triggerEvent("measure",{lines:t})})}})}},[123]); 
 			}); 	require("components/OffscreenMeasure.js");
 		__wxRoute = 'components/OpenInApp';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'components/OpenInApp.js';	define("components/OpenInApp.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([28],{100:function(t,e,n){"use strict";var a=n(10),r={utm_source:"wechat_app",utm_content:"app_jumping"};Component({methods:{launchAppError:function(t){console.error("无法打开知乎，错误原因：",t),this.setData({shown:!1}),wx.showModal({title:"无法打开知乎",content:"请前往应用商店下载最新版知乎 App，发现更大的世界"})},handleTap:function(){}},data:{parameter:JSON.stringify({url:(0,a.addQuery)("zhihu://feed",r)}),shown:!1},ready:function(){var t=wx.getStorageSync("CAN_OPEN_APP");this.setData({shown:t})},properties:{url:{type:String,value:"/",observer:function(t){this.setData({parameter:JSON.stringify({url:(0,a.addQuery)("zhihu://".concat(t),r)})})}}}})},99:function(t,e,n){n(100)}},[99]); 
 			}); 	require("components/OpenInApp.js");
 		__wxRoute = 'components/SafeAreaInset';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'components/SafeAreaInset.js';	define("components/SafeAreaInset.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([27],{97:function(a,e,n){n(98)},98:function(a,e){Component({data:{safeAreaInsetValue:getApp().globalData.safeAreaInsetValue}})}},[97]); 
 			}); 	require("components/SafeAreaInset.js");
 		__wxRoute = 'components/Spinner';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'components/Spinner.js';	define("components/Spinner.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([26],{76:function(n,o,p){p(77)},77:function(n,o){Component({})}},[76]); 
 			}); 	require("components/Spinner.js");
 		__wxRoute = 'components/TabNav';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'components/TabNav.js';	define("components/TabNav.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([25],{50:function(e,t,r){r(51)},51:function(e,t,r){"use strict";var n=r(4);var a={properties:{activeNav:{type:Number,value:0},searchIconOpacity:{type:Number,value:1},defaultOffset:{type:Number,value:0}},data:{list:[{text:"热榜",url:"/pages/index/index",identifier:n.NavIdentifier.hot},{text:"为你推荐",url:"/pages/index/recommend",identifier:n.NavIdentifier.recommendation}],scrollTopMap:{}},methods:{handleNavItemTap:function(e){var t=this,r=e.currentTarget.dataset.navIdentifier;r!==this.data.activeNav&&this.memoizeScrollTop().then(function(){t.triggerEvent("tabchange",{nextNavIdentifier:r,previousNavIdentifier:t.data.activeNav})}).then(function(){return t.recoverScrollTop(r)}).then(function(){return t.triggerEvent("scrollpositionrestored")})},memoizeScrollTop:function(){var e=this,t=this.data.activeNav,r="scrollTopMap[".concat(t,"]");return new Promise(function(t){wx.createSelectorQuery().selectViewport().scrollOffset(function(n){var a,o,i;e.setData((a={},o=r,i=n.scrollTop,o in a?Object.defineProperty(a,o,{value:i,enumerable:!0,configurable:!0,writable:!0}):a[o]=i,a),t)}).exec()})},recoverScrollTop:function(e){var t=this;return new Promise(function(r){setTimeout(function(){wx.pageScrollTo({scrollTop:t.data.scrollTopMap[e]||t.data.defaultOffset,duration:1}),r()},1)})},handleSearchIconTap:function(){this.triggerEvent("searchIconTap")}}};Component(a)}},[50]); 
 			}); 	require("components/TabNav.js");
 		__wxRoute = 'components/TopToast';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'components/TopToast.js';	define("components/TopToast.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([24],{52:function(t,n,e){e(53)},53:function(t,n){var e=function(t){return new Promise(function(n){return setTimeout(n,t)})};Component({properties:{offset:{type:String,value:"0"},text:{type:String,value:""}},data:{mount:!1,status:""},attached:function(){this.triggerEvent("onref",this)},detached:function(){this.triggerEvent("onref",null)},methods:{show:function(t){var n=this,r=Object.assign({delay:0,duration:1500},this.data,t);e(r.delay).then(function(){return n.setState({mount:!0,status:"active",text:r.text})}).then(function(){return e(300+r.duration)}).then(function(){return n.setState({status:"leave"})}).then(function(){return e(300)}).then(function(){return n.setState({mount:!1})})},setState:function(t){var n=this;return new Promise(function(e){return n.setData(t,e)})}}})}},[52]); 
 			}); 	require("components/TopToast.js");
 		__wxRoute = 'components/VideoThumbnail';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'components/VideoThumbnail.js';	define("components/VideoThumbnail.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([5],{111:function(e,t,n){n(112)},112:function(e,t,n){"use strict";var a,o=(a=n(113))&&a.__esModule?a:{default:a};Component({data:{video:null},properties:{videoId:{type:String,observer:function(e){var t=this;e&&(this.setData({newId:e}),(0,o.default)(e).then(function(e){e.data&&t.setData({video:e.data})}))}}},methods:{handleLoadMoreTap:function(){this.triggerEvent("expand",{})}}})},113:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var a=n(0);t.default=function(e){return a.default("https://lens.zhihu.com/api/videos/"+e)}}},[111]); 
 			}); 	require("components/VideoThumbnail.js");
 		__wxRoute = 'pages/index/uiHotItem';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/uiHotItem.js';	define("pages/index/uiHotItem.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([22],{56:function(e,n,o){o(57)},57:function(e,n){Component({properties:{item:Object,index:Number},methods:{handleTap:function(){}}})}},[56]); 
 			}); 	require("pages/index/uiHotItem.js");
 		__wxRoute = 'pages/index/uiRecommendItem';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/uiRecommendItem.js';	define("pages/index/uiRecommendItem.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([21],{58:function(e,t,o){o(59)},59:function(e,t,o){"use strict";var n,c=(n=o(2))&&n.__esModule?n:{default:n};Component({properties:{item:Object},methods:{handleTap:function(){var e=this.data.item,t="/zhihu/".concat(e.type,"?id=").concat(e.urltoken,"&source=recommend");(0,c.default)({url:t})}}})}},[58]); 
 			}); 	require("pages/index/uiRecommendItem.js");
 		__wxRoute = 'pages/index/uiSubscription';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/uiSubscription.js';	define("pages/index/uiSubscription.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([20],{54:function(o,e,n){n(55)},55:function(o,e){Component({properties:{isVisible:Boolean,showButton:Boolean},methods:{handleSubscribe:function(){this.triggerEvent("subcribe")}}})}},[54]); 
 			}); 	require("pages/index/uiSubscription.js");
 		__wxRoute = 'zhihu/AbstractComment';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/AbstractComment.js';	define("zhihu/AbstractComment.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([19],{101:function(t,n,e){e(102)},102:function(t,n,e){"use strict";var a,o=(a=e(0))&&a.__esModule?a:{default:a};Component({properties:{entryId:String,entryType:String,commentCount:Number},data:{entryId:"",abstractComments:null},attached:function(){var t=this,n=this.data.entryId,e="https://www.zhihu.com/api/v4/answers/".concat(n,"/abstract_comments?include=data[*].author,vote_count,voting");(0,o.default)(e).then(function(n){var e=n.data.data;t.setData({abstractComments:e})})},methods:{onViewAllTap:function(){this.triggerEvent("openCommentPanel",{})}}})}},[101]); 
 			}); 	require("zhihu/AbstractComment.js");
 		__wxRoute = 'zhihu/CommentItem';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/CommentItem.js';	define("zhihu/CommentItem.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([18],{103:function(t,e,n){n(104)},104:function(t,e,n){"use strict";var o,c=(o=n(0))&&o.__esModule?o:{default:o},i=n(3);Component({properties:{entryId:String,entryType:String,comment:Object},data:{},ready:function(){this.tryRegisterTime=0},methods:{handleVoteUpClick:function(t){var e=this,n=t.currentTarget,o=n.dataset.id,a=this.data.comment,r=a.voting,u="https://www.zhihu.com/api/v4/comments/".concat(o,"/actions/like");getApp().authRequired().then(function(){return(0,c.default)(u,{method:r?"DELETE":"POST"}).then(function(t){a.vote_count=t.data.vote_count,a.voting=!a.voting,e.setData({comment:a})})}).catch(function(t){(0,i.createZhihuAccountOnce)(t).then(function(){e.tryRegisterTime<2&&e.handleVoteUpClick({currentTarget:n})})})}}})}},[103]); 
 			}); 	require("zhihu/CommentItem.js");
 		__wxRoute = 'zhihu/CommentPanel';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/CommentPanel.js';	define("zhihu/CommentPanel.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([17],{114:function(t,a,e){e(115)},115:function(t,a,e){"use strict";var n,o=(n=e(0))&&n.__esModule?n:{default:n};function i(t){if(Array.isArray(t)){for(var a=0,e=new Array(t.length);a<t.length;a++)e[a]=t[a];return e}return Array.from(t)}Component({properties:{entryId:String,entryType:String},data:{isLoadingMore:!1,isEnd:!1},attached:function(){this.loadComments()},methods:{loadComments:function(){var t=this,a=this.data,e=a.entryId,n=a.commentsData,s=(n=void 0===n?{}:n).data,r=void 0===s?[]:s,c=a.offset,d=void 0===c?0:c,m=a.isLoadingMore,u=a.isEnd,f=a.entryType;if(!u&&!m){var l="";if("answer"===f){var h=["data[*].author","vote_count","voting","child_comments[*].author","vote_count"].join(",");l="https://api.zhihu.com/answers/".concat(e,"/root_comments?include=").concat(h,"&offset=").concat(d,"&limit=").concat(10)}else if("article"===f){var p=["data[*].author"].join(",");l="https://api.zhihu.com/articles/".concat(e,"/comments?include=").concat(p,"&offset=").concat(d,"&limit=").concat(10,"&status=open&reverse_order=0")}this.setData({isLoadingMore:!0}),(0,o.default)(l).then(function(a){var e=a.data.featured_counts,n=i(r).concat(i(a.data.data)),o=n.slice(0,e),s=n.slice(e);t.setData({commentsData:Object.assign({},a.data,{data:n}),featuredComments:o,commonComments:s,offset:d+10,isLoadingMore:!1,isEnd:a.data.paging.is_end||a.data.data.length<10})})}},closeCommentPanel:function(){this.triggerEvent("closeCommentPanel",{})}}})}},[114]); 
 			}); 	require("zhihu/CommentPanel.js");
 		__wxRoute = 'zhihu/HotRecommand';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/HotRecommand.js';	define("zhihu/HotRecommand.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([16],{105:function(e,n,o){o(106)},106:function(e,n){Component({properties:{recommands:Array,loading:Boolean,end:Boolean},data:{},methods:{handleTap:function(){wx.reLaunch?wx.reLaunch({url:"/pages/index/index"}):wx.redirectTo({url:"/pages/index/index"})}}})}},[105]); 
 			}); 	require("zhihu/HotRecommand.js");
 		__wxRoute = 'zhihu/ToolBar';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/ToolBar.js';	define("zhihu/ToolBar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([15],{109:function(t,e,n){n(110)},110:function(t,e,n){"use strict";var r,o=(r=n(0))&&r.__esModule?r:{default:r},a=n(3);function i(t,e){if(Array.isArray(t))return t;if(Symbol.iterator in Object(t))return function(t,e){var n=[],r=!0,o=!1,a=void 0;try{for(var i,u=t[Symbol.iterator]();!(r=(i=u.next()).done)&&(n.push(i.value),!e||n.length!==e);r=!0);}catch(t){o=!0,a=t}finally{try{r||null==u.return||u.return()}finally{if(o)throw a}}return n}(t,e);throw new TypeError("Invalid attempt to destructure non-iterable instance")}Component({properties:{entryId:String,commentCount:Number,voteupCount:Number,voting:Number,isToolBarShown:Boolean,type:String},data:{entity_id:"",current_page:"",isToolBarShown:!0},ready:function(){var t=getCurrentPages(),e=t[t.length-1]||{},n=e.route,r=e.options,o=i(n.match(/\/(\w+)$/)||[],2),a=(o[0],o[1]),u=r.id,c="iPhone X"===getApp().globalData.systemInfo.model;this.setData({id:u,pageName:a,isIphoneX:c}),this.tryRegisterTime=0},methods:{handleShareButtonTap:function(){var t=this.data,e=t.id,n=t.pageName;wx.reportAnalytics("share_to_friend",{entity_id:e,current_page:n})},handleAnswerVote:function(t){var e=this,n=t.currentTarget,r=n.dataset.voteType,i=this.data,u=i.entryId,c=i.voting,s="https://www.zhihu.com/api/v4/answers/".concat(u,"/voters"),h={"-1":"down",0:"neutral",1:"up"},p=(c="up"===r?1!==c?1:0:-1!==c?-1:0).toString();getApp().authRequired().then(function(){return(0,o.default)(s,{method:"POST",data:{type:h[p]}}).then(function(t){var n=t.data,r=n.voteup_count,o=n.voting;e.setData({voteupCount:r,voting:o}),-1===o&&wx.showToast({title:"已反对",icon:"none",duration:2e3})})}).catch(function(t){e.tryRegisterTime++,(0,a.createZhihuAccountOnce)(t).then(function(){e.tryRegisterTime++<2&&e.handleAnswerVote({currentTarget:n})})})},handleArticleVote:function(t){var e=this,n=t.currentTarget,r=(n.dataset.voteType,this.data),i=r.entryId,u=r.voting,c="https://www.zhihu.com/api/v4/articles/".concat(i,"/likers");getApp().authRequired().then(function(){return(0,o.default)(c,{method:u?"DELETE":"POST"}).then(function(t){var n=t.data.likes_count;e.setData({voteupCount:n,voting:u?0:1})})}).catch(function(t){e.tryRegisterTime++,(0,a.createZhihuAccountOnce)(t).then(function(){e.tryRegisterTime++<2&&e.handleAnswerVote({currentTarget:n})})})},onCommentTap:function(){this.data.type;this.triggerEvent("openCommentPanel",{})}}})}},[109]); 
 			}); 	require("zhihu/ToolBar.js");
 		__wxRoute = 'zhihu/uiFooter';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/uiFooter.js';	define("zhihu/uiFooter.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([12],{119:function(t,e,r){r(120)},120:function(t,e){function r(t,e){if(Array.isArray(t))return t;if(Symbol.iterator in Object(t))return function(t,e){var r=[],n=!0,a=!1,i=void 0;try{for(var o,p=t[Symbol.iterator]();!(n=(o=p.next()).done)&&(r.push(o.value),!e||r.length!==e);n=!0);}catch(t){a=!0,i=t}finally{try{n||null==p.return||p.return()}finally{if(a)throw i}}return r}(t,e);throw new TypeError("Invalid attempt to destructure non-iterable instance")}Component({properties:{entryId:String,entryType:String,title:String,excerpt:String},data:{entity_id:"",current_page:""},ready:function(){var t=getCurrentPages(),e=t[t.length-1]||{},n=e.route,a=e.options,i=r(n.match(/\/(\w+)$/)||[],2),o=(i[0],i[1]),p=a.id;this.setData({id:p,pageName:o})},methods:{handleIndexButtonTap:function(){var t=this.data,e=t.id,r=t.pageName;wx.reportAnalytics("back_to_index",{entity_id:e,current_page:r})},handleShareButtonTap:function(){var t=this.data,e=t.id,r=t.pageName;wx.reportAnalytics("share_to_friend",{entity_id:e,current_page:r})}}})}},[119]); 
 			}); 	require("zhihu/uiFooter.js");
 		__wxRoute = 'zhihu/uiSummary';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/uiSummary.js';	define("zhihu/uiSummary.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([11],{121:function(t,a,e){e(122)},122:function(t,a){var e=function(t){return t.replace(/<.+?>/g,"")};Component({options:{multipleSlots:!0},properties:{excerpt:String,detail:String},data:{expanded:!1,canExpand:!1},attached:function(){var t=this.data,a=t.excerpt,n=t.detail,p=e(a),i=p!==e(n);this.setData({canExpand:i,excerptText:p})},methods:{handleTap:function(){this.data.canExpand&&this.setData({expanded:!0})},handleExcerptMeasure:function(t){t.detail.lines>2&&this.setData({canExpand:!0})}}})}},[121]); 
 			}); 	require("zhihu/uiSummary.js");
 		__wxRoute = 'zhihu/uiThumbnailInfo';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/uiThumbnailInfo.js';	define("zhihu/uiThumbnailInfo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([10],{125:function(n,o,e){e(126)},126:function(n,o){Component({externalClasses:["thumbnails-class"],properties:{info:Object},methods:{stopPropagation:function(){}}})}},[125]); 
 			}); 	require("zhihu/uiThumbnailInfo.js");
 		__wxRoute = 'pages/index/index';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/index.js';	define("pages/index/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([2],{46:function(t,e,a){a(47)},47:function(t,e,a){"use strict";var n=a(4),r=d(a(1)),o=d(a(0)),i=d(a(2)),s=d(a(48)),c=a(49),u=a(3),h=a(7);function d(t){return t&&t.__esModule?t:{default:t}}function f(t,e,a){return e in t?Object.defineProperty(t,e,{value:a,enumerable:!0,configurable:!0,writable:!0}):t[e]=a,t}function l(){return(l=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var a=arguments[e];for(var n in a)Object.prototype.hasOwnProperty.call(a,n)&&(t[n]=a[n])}return t}).apply(this,arguments)}var g=getApp(),p=function(t){return t.target&&("answer"===t.target.type||"article"===t.target.type)},m=function(t){return l({},t.target,{id:String(t.target.id),attachedInfo:t.attached_info,title:t.target.question?t.target.question.title:t.target.title,urltoken:String(t.target.id),image:t.target.thumbnail||t.target.image_url})};Page({data:{hotList:[],showFreshBanner:!1,showSubscription:!1,isSubscriptionButtonVisible:!0,pageType:"home",currentNav:n.NavIdentifier.hot,navIdentifiers:(0,s.default)(n.NavIdentifier),recommendList:[],recommendPaging:null,scrollPositionRestored:!0,searchIconHidden:1},willShowSearchWhenTouchEnd:!1,willHideSearchWhenTouchEnd:!1,onLoad:function(){var t=this;this.getHotData().then(function(){t.getRecommendData()}),g.authRequired().then(function(e){t.checkSubscription().then(function(){return t.logUserAccess()}).then(function(){t.getRecommendData(!0,!0),t.handleRefresh(!0)})})},onPullDownRefresh:function(){wx.vibrateShort&&wx.vibrateShort(),this.handleRefresh(!0)},onShow:function(){var t=this.data,e=t.hotList,a=t.currentNav;e.length&&a===n.NavIdentifier.hot&&this.handleRefresh(!1),this.showPresetWords()},onShareAppMessage:function(){var t=(g.globalData.userInfo||{}).nickName,e=void 0===t?"":t;return e?{title:"".concat(e," 和你分享了热门榜单")}:{title:""}},onListScroll:function(t){var e=t.detail.scrollTop;e<-40&&!this.shouldRefreshWhenTouchEnd?(wx.vibrateShort&&wx.vibrateShort(),this.shouldRefreshWhenTouchEnd=!0):e>-40&&this.shouldRefreshWhenTouchEnd&&(this.shouldRefreshWhenTouchEnd=!1),this.setData({searchIconOpacity:Math.min(.025*e,1)})},onReachBottom:function(){this.handleScrollBottom()},showSearchBar:function(t){wx.pageScrollTo({scrollTop:0,duration:t||1}),this.setData({searchIconHidden:!0})},handleScrollBottom:function(){var t=this,e=this.data,a=e.isBottomLoading,n=e.recommendPaging,r=n&&n.is_end;if(!a&&!r){this.setData({isBottomLoading:!0});var o=function(){return t.setData({isBottomLoading:!1})};this.getRecommendData().then(o,o)}},handleTabChange:function(t){this.setData({currentNav:t.detail.nextNavIdentifier,scrollPositionRestored:!1})},handleTabScrollPositionRestored:function(t){this.setData({scrollPositionRestored:!0})},getHotData:function(){var t=this;return(0,o.default)("".concat(r.default.dataBaseUrl,"/api/v3/feed/topstory/hot-list-wx?limit=50")).then(function(e){return t.setData({hotList:e.data.data.map(t.normalizeHotItemData)}),e})},getRecommendData:function(t,e){var a=this,n=this.data,i=n.recommendPaging,s=n.recommendList;return function(t){return(0,o.default)(t).then(function(t){return{data:t.data.data.filter(p).map(m),paging:t.data.paging,freshText:t.data.fresh_text}})}(!e&&i?i.next:(0,u.isLoggedIn)()?"".concat(r.default.dataBaseUrl,"/api/v3/feed/topstory"):"".concat(r.default.dataBaseUrl,"/api/v3/feed/topstory/hot-lite")).then(function(e){return a.setData({recommendList:t?e.data:(0,c.uniqueById)(s.concat(e.data)),recommendPaging:e.paging}),e})},checkSubscription:function(){var t=this;return(0,o.default)("".concat(r.default.apiBaseUrl,"/user-push-switch")).then(function(e){e.data.status||t.openSubscriptHeader()})},logUserAccess:function(){return(0,o.default)("".concat(r.default.apiBaseUrl,"/access-time"),{method:"PUT"})},handleHotItemTap:function(t){var e=t.target.dataset,a=e.urltoken,n=e.type;this.shouldSendFormId()&&(0,o.default)("".concat(r.default.apiBaseUrl,"/user-formid"),{method:"POST",data:{formid:t.detail.formId}}).then(function(){var e=(new Date).toDateString(),a=wx.getStorageSync("formIdLists");if(a&&a[e]){var n=a[e];wx.setStorageSync("formIdLists",f({},e,n.concat([t.detail.formId])))}else wx.setStorageSync("formIdLists",f({},e,[t.detail.formId]))}),(0,i.default)({url:"/zhihu/".concat(n,"?id=").concat(a,"&source=hotList")})},shouldSendFormId:function(){var t=(new Date).toDateString(),e=wx.getStorageSync("formIdLists");if(!e)return!0;var a=e[t];return!a||!(a.length>=7)},handleSubscribe:function(){var t=this;(0,o.default)("".concat(r.default.apiBaseUrl,"/user-push-switch"),{method:"PUT",data:{status:!0}}).then(function(){t.setData({isSubscriptionButtonVisible:!1}),setTimeout(function(){t.closeSubscriptHeader()},700)},function(){t.showNetworkErrorToast()})},normalizeHotItemData:function(t,e){var a=t.target.link.url,n=a.match(/\/(\d+)+/)[1],r=-1!==a.indexOf("/question")?"question":"article",o=t.target.metrics_area.text,i=t.target.title_area.text,s=i.length>12?"":t.target.excerpt_area&&t.target.excerpt_area.text;return l({id:t.id,attachedInfo:t.attached_info,title:i,excerpt:s,image:t.target.image_area&&t.target.image_area.url,link:a,metrics:o,type:r,urltoken:n,indexColor:e<=2?"red":"gold"},t.feed_specific)},openSubscriptHeader:function(){this.setData({showSubscription:!0})},closeSubscriptHeader:function(){this.setData({showSubscription:!1})},handleRefresh:function(t){var e=this;(this.data.currentNav===n.NavIdentifier.hot?this.getHotData():this.getRecommendData(!0)).then(function(a){if(wx.stopPullDownRefresh(),t&&e.topToast){var n={delay:500,duration:1e3};a.freshText&&(n.text=a.freshText),e.topToast.show(n)}})},handleTopToastRef:function(t){this.topToast=t.detail},showToast:function(t){this.setData({networkErrorToast:t})},hideToast:function(){this.setData({networkErrorToast:""})},showNetworkErrorToast:function(){var t=this;this.showToast("好像哪里出错了，稍后再试"),setTimeout(function(){t.hideToast()},1500)},handleTestButtonTap:function(){wx.scanCode({success:function(t){var e=t.path;(0,i.default)({url:"/".concat(e)})}})},navigateToSearchPage:function(){var t=this.data.presetWord,e=t?t.query:"",a=this;(0,i.default)({url:"/pages/search/index?preset=".concat(e),success:function(){setTimeout(function(){return a.showPresetWords()},1e3)}})},handleSearchIconTap:function(){this.navigateToSearchPage()},handleFakeInputTap:function(){this.navigateToSearchPage()},handleChangeTapBySwipe:function(t){var e=t.detail.current;this.setData({currentNav:e})},handlePageTouchEnd:function(){this.shouldRefreshWhenTouchEnd&&(wx.vibrateShort&&wx.vibrateShort(),this.handleRefresh(!0),this.shouldRefreshWhenTouchEnd=!1)},showPresetWords:function(){var t=this;(0,h.getPresetWord)().then(function(e){return t.setData({presetWord:e})})}})},48:function(t,e,a){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=function(t){return JSON.parse(JSON.stringify(t))}},49:function(t,e,a){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.uniqueBy=function(t,e){var a=t.map(e);return t.filter(function(t,e){return a.indexOf(a[e])===e})},e.uniqueById=function(t){return e.uniqueBy(t,function(t){return t.id})}}},[46]); 
 			}); 	require("pages/index/index.js");
 		__wxRoute = 'pages/search/index';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/search/index.js';	define("pages/search/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([1],{60:function(t,e,a){a(61)},61:function(t,e,a){"use strict";var r=h(a(1)),s=h(a(0)),n=h(a(62)),o=h(a(2)),i=a(10),c=a(75),u=a(7);function h(t){return t&&t.__esModule?t:{default:t}}function d(t){if(Array.isArray(t)){for(var e=0,a=new Array(t.length);e<t.length;e++)a[e]=t[e];return a}return Array.from(t)}function l(){return(l=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var a=arguments[e];for(var r in a)Object.prototype.hasOwnProperty.call(a,r)&&(t[r]=a[r])}return t}).apply(this,arguments)}var f="".concat(r.default.apiHost,"/search/top_search"),g="".concat(r.default.apiHost,"/search/suggest");Page({data:{searchInputText:"",searchText:"",topSearchWords:[],historySearchWords:[],suggestSearchWords:[],isSearchInputFocus:!0,isLoadingResult:!1},onLoad:function(t){var e=this,a=t.preset;(0,s.default)(f).then(function(t){var a=wx.getStorageSync("historySearchWords");e.setData({topSearchWords:t.data.top_search.words,historySearchWords:a})}),this.showPresetWords(a)},onShow:function(){},onReachBottom:function(){var t=this.data,e=t.result,a=t.searchText,r=t.isLoadingResult;if(e&&a&&!r){var s=e.paging;s.is_end||this.getSearchResult(l({},(0,i.getQuery)(s.next)),!0)}},onUnload:function(){this.saveHistorySearchWordsToLocal()},onHide:function(){this.saveHistorySearchWordsToLocal()},saveHistorySearchWordsToLocal:function(){var t=this.data.historySearchWords;wx.setStorage({key:"historySearchWords",data:t})},handleSearchCancel:function(){wx.navigateBack({})},handleSearchClear:function(){this.setData({searchText:"",searchInputText:"",isLoadingResult:!1,result:null})},updateSearchHistory:function(t){this.setData({historySearchWords:t})},handleSearchInput:function(t){var e=t.detail.value,a=e.trim();this.setData({searchInputText:e,searchText:a}),(0,c.debounce)(this.updateSuggestSearchWords,200)},updateSuggestSearchWords:function(){var t=this,e=this.data.searchText;this.suggestRequestCount=this.suggestRequestCount?this.suggestRequestCount+1:1;var a,r=this.suggestRequestCount;e&&(a=e,(0,s.default)("".concat(g,"?q=").concat(a))).then(function(a){if(r===t.suggestRequestCount){var s=a.data.suggest.map(function(t){var a=t.query;return 0===a.indexOf(e)?{query:a,matching:e,mismatching:a.replace(e,"")}:{query:a,matching:"",mismatching:a}});t.setData({suggestSearchWords:s})}})},handleSearchFocus:function(){this.setData({isSearchInputFocus:!0})},searchConfirm:function(t){var e=this.data.historySearchWords,a=d(new Set([t].concat(d(e))));t&&this.updateSearchHistory(a),wx.pageScrollTo({scrollTop:0,duration:1}),this.setData({isLoadingResult:!0,isSearchInputFocus:!1,suggestSearchWords:[]}),this.getSearchResult({q:t}).then(function(){})},getSearchResult:function(t){var e=this,a=arguments.length>1&&void 0!==arguments[1]&&arguments[1];return(0,n.default)(t).then(function(t){e.setData({result:a?l({},t,{data:e.data.result.data.concat(t.data)}):t,isLoadingResult:!1})})},handleSearchConfirm:function(){var t=this.data,e=t.searchText,a=t.presetWord;if(e)this.searchConfirm(e);else if(a){var r=a.real_query;this.setData({searchText:r,searchInputText:r}),this.searchConfirm(r)}},handlePresetWordTap:function(t){this.handleRecommendWordTap(t);var e=t.currentTarget.dataset.id;(0,u.markPresetWordInvalid)(e),this.showPresetWords()},handleRecommendWordTap:function(t){var e=t.currentTarget.dataset,a=e.query;e.type;this.setData({searchText:a,searchInputText:a}),this.searchConfirm(a),this.showPresetWords()},handleRemoveHistoryItem:function(t){var e=t.currentTarget.dataset.word,a=this.data.historySearchWords.filter(function(t){return t!=e});this.updateSearchHistory(a)},handleEmptySearchHistory:function(){this.updateSearchHistory([])},handleSearchResultTap:function(t){var e=t.currentTarget;(0,o.default)({url:e.dataset.url})},showPresetWords:function(t){var e=this;if(t){var a=(0,u.getLocalPresetWords)().find(function(e){return e.query===t});this.setData({presetWord:a})}else(0,u.getPresetWord)().then(function(t){return e.setData({presetWord:t})})}})},62:function(t,e,a){"use strict";var r=this&&this.__assign||Object.assign||function(t){for(var e,a=1,r=arguments.length;a<r;a++)for(var s in e=arguments[a])Object.prototype.hasOwnProperty.call(e,s)&&(t[s]=e[s]);return t};Object.defineProperty(e,"__esModule",{value:!0});var s=a(8),n=a(9),o=a(0),i={correction:1,offset:0,advertCount:0,limit:20,excerpt_len:50,t:"general"},c=["answer","question","article"];function u(t){return!!t.object&&("search_result"===t.type&&-1!==c.indexOf(t.object.type))}function h(t){var e=r({},t),a=e.highlight,o=a.title,i=a.description;return e.highlight={title:s.default(n(o)),description:s.default(n(i))},e}function d(t){return r({},t.data,{data:t.data.data.filter(u).map(h)})}e.default=function(t){var e=r({},i,t,{limit:30});return o.default("https://www.zhihu.com/api/v4/search_v3",{header:{"x-api-version":"3.0.91","x-hybrid":1},data:e}).then(d)}},75:function(t,e,a){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.debounce=function(t,e,a){void 0===e&&(e=100),void 0===a&&(a={}),clearTimeout(t.tId),t.tId=setTimeout(function(){t.call(a)},e)}}},[60]); 
 			}); 	require("pages/search/index.js");
 		__wxRoute = 'pages/error/index';__wxRouteBegin = true; 	define("pages/error/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([23],{78:function(e,t,o){o(79)},79:function(e,t){var o={notFound:{notice:"你似乎来到了没有知识存在的荒原…"},unauthorized:{notice:"当前内容暂时无法查看"}};Page({onLoad:function(e){wx.setNavigationBarTitle({title:e.title}),this.setData({errorType:e.type,error:o[e.type]})}})}},[78]); 
 			}); 	require("pages/error/index.js");
 		__wxRoute = 'zhihu/answer';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/answer.js';	define("zhihu/answer.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([14],{80:function(t,e,a){a(81)},81:function(t,e,a){"use strict";var n=s(a(2)),o=s(a(0)),i=a(5);function s(t){return t&&t.__esModule?t:{default:t}}Page({data:{entryId:void 0,source:void 0,showTitleOnNavigationBar:!1,isToolBarShown:!0,hasNext:!0,loading:!1,pageNum:1,recommands:[],recommandsSource:[]},onLoad:function(t){var e=this,a=t.id||(0,i.decodeScene)(t.scene).id,n=t.source,o=t.preview_video_id||null,s=!!o;a&&(this.setData({entryId:a,source:n,shouldShowVideoOnly:s,videoId:o}),this.initialScrollTop=0,(0,i.getShareImage)("answer",a).then(function(t){return e.setData({shareImage:t.friend})}),Promise.all([this.fetchAnswer(a),this.fetchRecommand()]))},onShow:function(){},fetchAnswer:function(t){var e=this,a=["excerpt,","content,","created_time,","updated_time,","comment_count,","voteup_count,","reshipment_settings,","relationship.voting;","author.badge[*].topics;"].join(""),n="https://www.zhihu.com/api/v4/answers/".concat(t,"?include=").concat(encodeURIComponent(a));(0,o.default)(n).then(function(t){var a=t.data;e.setData({answer:a});var n=t.data.question.id;return(0,o.default)("https://www.zhihu.com/api/v4/questions/".concat(n,"?include=answer_count"))}).then(function(t){wx.createSelectorQuery().select(".title").boundingClientRect(function(a){var n=a.height;e.setData({questionAreaHeight:n,answerCount:t.data.answer_count})}).exec()}).catch(function(t){var e=t.statusCode;401===e&&wx.redirectTo({url:"/pages/error/index?title=回答&type=unauthorized"}),404===e&&wx.redirectTo({url:"/pages/error/index?title=回答&type=notFound"})})},handleRedirectBack:function(t){var e=getCurrentPages(),a=e[e.length-2];if(a&&"zhihu/question"===a.route)wx.navigateBack();else{var o=t.currentTarget.dataset.id,i="/".concat("zhihu/question","?id=").concat(o);(0,n.default)({url:i})}},onShareAppMessage:function(){return(0,i.getShareAppMessage)("answer",this.data.entryId,{imageUrl:this.data.shareImage})},openCommentPanel:function(){this.setData({showCommentPanel:!0})},closeCommentPanel:function(){this.setData({showCommentPanel:!1})},onPageScroll:function(t){var e=t.scrollTop,a=this.data,n=a.showTitleOnNavigationBar,o=a.answer,i=a.questionAreaHeight,s=a.isToolBarShown;!n&&e>i&&(this.setData({showTitleOnNavigationBar:!0}),wx.setNavigationBarTitle({title:o.question.title})),n&&e<i&&(this.setData({showTitleOnNavigationBar:!1}),wx.setNavigationBarTitle({title:"回答"})),this.initialScrollTop||(this.initialScrollTop=e),e-this.initialScrollTop<-100&&(this.initialScrollTop=e,s||this.setData({isToolBarShown:!0})),e-this.initialScrollTop>100&&(this.initialScrollTop=e,s&&this.setData({isToolBarShown:!1}))},onReachBottom:function(){this.data.isToolBarShown||this.setData({isToolBarShown:!0}),this.onRecommandScroll()},fetchRecommand:function(){var t=this;(0,o.default)("https://api.zhihu.com/wx-minapp-push/hot_recommendation").then(function(e){var a=e.data.data;t.setData({recommandsSource:a,recommands:a.slice(0,7)})})},onRecommandScroll:function(){var t=this;this.data.hasNext&&!this.data.loading&&(this.setData({loading:!0}),setTimeout(function(){var e=t.data,a=e.pageNum,n=e.recommandsSource,o=7*(a+1);t.setData({loading:!1,pageNum:a+1,recommands:n.slice(0,o),hasNext:o<n.length})},1e3))},handleVideoLoadMore:function(){this.setData({shouldShowVideoOnly:!1})}})}},[80]); 
 			}); 	require("zhihu/answer.js");
 		__wxRoute = 'zhihu/question';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/question.js';	define("zhihu/question.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([4],{116:function(t,n,e){e(117)},117:function(t,n,e){"use strict";var a=e(2),i=s(e(0)),o=s(e(118)),r=e(5);function s(t){return t&&t.__esModule?t:{default:t}}function u(){return(u=Object.assign||function(t){for(var n=1;n<arguments.length;n++){var e=arguments[n];for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&(t[a]=e[a])}return t}).apply(this,arguments)}Page({data:{entryId:void 0,source:void 0,sortBy:"default",openType:"navigate"},onLoad:function(t){var n=this,e=t.id||(0,r.decodeScene)(t.scene).id,o=t.source;if(e){this.setData({entryId:e,source:o,openType:(0,a.getOpenType)()}),(0,r.getShareImage)("question",e).then(function(t){return n.setData({shareImage:t.friend})});var s="https://www.zhihu.com/api/v4/questions/".concat(e,"?include=").concat("excerpt,detail,thumbnail_info,mute_info");(0,i.default)(s).then(function(t){var e=t.data;console.info("question",t),e.mute_info&&""!==e.mute_info.type?wx.redirectTo({url:"/pages/error/index?title=问题&type=unauthorized"}):n.setData({question:e})}).catch(function(t){var n=t.statusCode;401===n&&wx.redirectTo({url:"/pages/error/index?title=问题&type=unauthorized"}),404===n&&wx.redirectTo({url:"/pages/error/index?title=问题&type=notFound"})}),this.initAnswers()}},onShow:function(){},initAnswers:function(){var t=this,n=this.data,e=n.entryId,a=n.sortBy,o=["data[*].voteup_count","excerpt","thumbnail_info.thumbnails[*].data_url"].join(","),r="https://www.zhihu.com/api/v4/questions/".concat(e,"/answers?include=").concat(o,"&sort_by=").concat(a);(0,i.default)(r).then(function(n){var e=n.data.data,a=n.data.paging;console.info("answers",n),t.setData({answers:e,paging:a})})},handleAnswerItemClick:function(){},onReachBottom:function(){var t=this;if(!this.data.isBottomLoading&&!0!==this.data.paging.is_end){this.setData({isBottomLoading:!0});var n=(0,o.default)(this.data.paging.next);(0,i.default)(n).then(function(n){var e,a=n.data;t.setData({isBottomLoading:!1,answers:(e=t.data.answers.concat(a.data),function(t,n){var e=t.map(n);return t.filter(function(t,n){return e.indexOf(e[n])===n})}(e,function(t){return t.id})),paging:u({},t.data.paging,{is_end:a.paging.is_end,next:a.paging.next})})}).catch(function(n){console.info("catch",n),t.setData({isBottomLoading:!1})})}},onShareAppMessage:function(){return(0,r.getShareAppMessage)("question",this.data.entryId,{imageUrl:this.data.shareImage})},handleSwitch:function(){var t=this,n="default"===this.data.sortBy?"created":"default";this.setData({sortBy:n},function(){t.initAnswers()})},handleShowOpenInApp:function(){},handleOpenInApp:function(){}})},118:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0});n.default=function(t){return t.replace(/^http:/,"https:")}}},[116]); 
 			}); 	require("zhihu/question.js");
 		__wxRoute = 'zhihu/article';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'zhihu/article.js';	define("zhihu/article.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
require("../common.js");var webpackJsonp=wx.webpackJsonp;webpackJsonp([13],{127:function(t,o,e){e(128)},128:function(t,o,e){"use strict";var i,n=(i=e(0))&&i.__esModule?i:{default:i},a=e(5);Page({data:{entryId:void 0,source:void 0,showCommentPanel:!1,isToolBarShown:!0},onLoad:function(t){var o=this,e=t.id||(0,a.decodeScene)(t.scene).id,i=t.source,n=t.preview_video_id||null,r=!!n;e&&(this.setData({entryId:e,source:i,shouldShowVideoOnly:r,videoId:n}),this.initialScrollTop=0,(0,a.getShareImage)("article",e).then(function(t){return o.setData({shareImage:t.friend})}),this.fetchPost(e,"article").catch(function(){var t;return(t=console).warn.apply(t,arguments),o.fetchPost(e,"promotion").catch(function(t){var o=t.statusCode;401===o&&wx.redirectTo({url:"/pages/error/index?title=问题&type=unauthorized"}),404===o&&wx.redirectTo({url:"/pages/error/index?title=问题&type=notFound"})})}).catch(console.warn))},onShow:function(){},fetchPost:function(t,o){var e=this,i=["column","content","created","image_height","image_width","voteup_count","comment_count","voting"].join(","),a="article"===o?"https://www.zhihu.com/api/v4/articles/".concat(t,"?include=").concat(i):"https://promotion.zhihu.com/api/promotions/".concat(t);return(0,n.default)(a).then(function(t){var i=t.data;e.setData({post:i,isPromotion:"promotion"===o})}).catch(function(t){if(401!==t.statusCode)throw t;wx.redirectTo({url:"/pages/error/index?title=问题&type=unauthorized"})})},onShareAppMessage:function(){return(0,a.getShareAppMessage)("article",this.data.entryId,{imageUrl:this.data.shareImage})},openCommentPanel:function(){this.setData({showCommentPanel:!0})},closeCommentPanel:function(){this.setData({showCommentPanel:!1})},onPageScroll:function(t){var o=t.scrollTop,e=this.data.isToolBarShown;this.initialScrollTop||(this.initialScrollTop=o),o-this.initialScrollTop<-100&&(this.initialScrollTop=o,e||this.setData({isToolBarShown:!0})),o-this.initialScrollTop>100&&(this.initialScrollTop=o,e&&this.setData({isToolBarShown:!1}))},onReachBottom:function(){this.data.isToolBarShown||this.setData({isToolBarShown:!0})},handleVideoLoadMore:function(){this.setData({shouldShowVideoOnly:!1})}})}},[127]); 
 			}); 	require("zhihu/article.js");
 	