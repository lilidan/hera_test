/**
 * Created by pengguanfa on 2017/10/25.
 * 扩展api配置
 */
window.HeraConf = null
window.HeraConf && window.HeraConf.extApi && (window.HeraExtApiConf = window.HeraConf.extApi)
